package com.des.legendary.orison;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

/**
 * CORE STATE visual: violet crystal reactor on the chest with the three independently rotating rings
 * (GENERATION / HARMONICS / DISCORD). Hidden while any armour form is deployed or assembling (the armour's own
 * reactor and rings take over). Four non-persistent displays per session, removed on destroy.
 */
final class CoreVisual {
    static final int[] MODEL = {7101, 7111, 7112, 7113};
    static final double[] SPIN = {6, 4, -7, 11};      // crystal, generation, harmonics, discord (deg per tick)
    private final Session s;
    private final ItemDisplay[] d = new ItemDisplay[4];

    CoreVisual(Session s) { this.s = s; }

    void tick() {
        boolean want = s.form == Form.CORE && !s.armour.ready && !s.armour.busy && !s.destroyed;
        if (!want) { remove(); return; }
        Location l = s.p.getLocation();
        double yaw = Math.toRadians(l.getYaw());
        Location at = l.clone().add(-Math.sin(yaw) * 0.3, s.p.isSneaking() ? 1.05 : 1.25, Math.cos(yaw) * 0.3);
        double mult = s.od() ? 2.2 : 1.0;
        for (int i = 0; i < 4; i++) {
            if (d[i] == null || !d[i].isValid() || d[i].getWorld() != at.getWorld()) { if (d[i] != null) d[i].remove(); d[i] = spawn(at, MODEL[i], i == 0 ? 0.5f : 0.62f); }
            Location t = at.clone();
            t.setYaw((float) (s.ticks * SPIN[i] * mult));
            t.setPitch(0);
            d[i].teleport(t);
        }
    }

    private ItemDisplay spawn(Location at, int cmd, float sc) {
        ItemStack it = new ItemStack(Material.NETHERITE_INGOT);
        ItemMeta m = it.getItemMeta();
        m.setCustomModelData(cmd);
        it.setItemMeta(m);
        return at.getWorld().spawn(at, ItemDisplay.class, x -> {
            x.setItemStack(it); x.setPersistent(false); x.setTeleportDuration(2);
            x.setBrightness(new Display.Brightness(15, 15)); x.setViewRange(1.2f);
            x.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(sc, sc, sc), new AxisAngle4f()));
        });
    }

    void remove() { for (int i = 0; i < 4; i++) { if (d[i] != null) d[i].remove(); d[i] = null; } }
}
