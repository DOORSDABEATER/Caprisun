package com.des.legendary.orison;

import net.kyori.adventure.sound.Sound.Source;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.SoundCategory;

import java.util.List;
import java.util.Map;
import java.util.Random;

/** Contextual ORISON lines. Text fallback always; plays des:orison.voice.<event> only if the pack supplies it. */
final class Voice {
    private final OrisonModule m;
    private final Random rnd = new Random();
    private static final Map<String, List<String>> L = Map.ofEntries(
        Map.entry("online", List.of("Core synchronization complete. All systems operational.", "Resonance stable. I am with you.", "Core awake. Say the word.")),
        Map.entry("forge", List.of("New weapon geometry recognized. Beginning construction.", "Matter manipulation engaged.", "Constructing. Try not to break it.")),
        Map.entry("dismiss", List.of("Disassembling.", "Returning matter to resonance.")),
        Map.entry("lowenergy", List.of("Resonance reserves insufficient. Forging remains available.", "Reserves low. Reposition.")),
        Map.entry("overload", List.of("Reactor output exceeding safe parameters. I recommend immediate discharge.", "Overload. Venting. Do not push me.")),
        Map.entry("ultimate", List.of("The Last Chord. Stand clear.", "All six anchors in place. Releasing.")),
        Map.entry("intercept", List.of("Missile trajectory confirmed. Interception successful.", "Projectile neutralized.")),
        Map.entry("hostile", List.of("Hostile signatures identified. Tracking initiated.", "Threat acquired.")),
        Map.entry("half", List.of("Tactical configuration deploying. Analysis optics online.", "Partial armour engaged. Eyes open.")),
        Map.entry("retract", List.of("Armour retracting. Core secure.", "Standing down.")),
        Map.entry("full", List.of("SOVEREIGN ARMOUR ONLINE.", "Full architecture locked. Systems nominal.")),
        Map.entry("max", List.of("Ascendant architecture synchronized. Maximum configuration available.", "Ascendant Sovereign online. Please. Try to keep up.")),
        Map.entry("overdrive", List.of("Discord Overdrive engaged. Safeguards are... advisory.", "Output rising. I would not hold this long.")),
        Map.entry("victory", List.of("Hostile neutralized. Resonance stable.", "Target down. Efficient.")),
        Map.entry("defeat", List.of("Vital signs failing. Core secured for recovery.", "Core preserved. We will return.")),
        Map.entry("danger", List.of("Critical danger. Disengage or I will do it for you.", "Integrity compromised. Move.")),
        Map.entry("armour", List.of("Armour integrity reduced. Absorbing.", "Impact registered. Plating holding.")),
        Map.entry("secret", List.of("The first note. The one that was never struck.", "Silence. Everything stops listening."))
    );

    Voice(OrisonModule m) { this.m = m; }

    void say(Session s, String ev) {
        if (!m.cfg.getBoolean("voice.enabled", true)) return;
        List<String> lines = L.get(ev);
        if (lines == null || s.now() < s.voiceReady) return;
        s.voiceReady = s.now() + m.cfg.getInt("voice.cooldown-ticks", 100);
        String line = lines.get(rnd.nextInt(lines.size()));
        s.p.sendMessage(Component.text("ORISON ▸ ", NamedTextColor.DARK_PURPLE).append(Component.text(line, NamedTextColor.WHITE)));
        if (m.cfg.getBoolean("voice.play-sound", true))
            s.p.playSound(s.p.getLocation(), "des:orison.voice." + ev, SoundCategory.VOICE, (float) m.cfg.getDouble("voice.volume", 1.0), 1f);
    }
}
