package com.des.legendary.orison;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.NamespacedKey;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

/** /orison selftest — in-server verification of everything that can be checked without a human playing. */
final class SelfTest {
    private static int pass, fail;
    private static void check(CommandSender to, String name, boolean ok) {
        if (ok) pass++; else fail++;
        to.sendMessage(Component.text((ok ? "✔ " : "✘ ") + name, ok ? NamedTextColor.GREEN : NamedTextColor.RED));
    }

    static void run(OrisonModule m, CommandSender to) {
        pass = 0; fail = 0;
        to.sendMessage(Component.text("ORISON self-test", NamedTextColor.LIGHT_PURPLE));
        for (Form f : Form.values()) check(to, f.display + " roster = " + f.abilityCount, Abilities.forForm(f).size() == f.abilityCount);
        check(to, "weapon catalogue = 14", m.forge.catalogue.size() == 14);
        boolean all8 = true;
        for (Forge.Blueprint b : m.forge.catalogue.values()) all8 &= b.moveset().size() == 8;
        check(to, "every weapon has exactly 8 abilities", all8);
        try { Abilities.validate(m.forge); check(to, "all ability ids unique", true); } catch (IllegalStateException e) { check(to, "ability registry: " + e.getMessage(), false); }
        check(to, "forging has no cost keys in config", !m.cfg.contains("forge.cost") && !m.cfg.contains("forging.cost"));

        // identity: no name lock, fakes rejected, rename survives, tamper rejected, revoke works
        UUID owner = UUID.randomUUID();
        ItemStack core = m.items.create(owner);
        check(to, "genuine core recognised", m.items.isGenuine(core));
        ItemStack renamed = core.clone();
        ItemMeta rm = renamed.getItemMeta(); rm.displayName(Component.text("totally renamed")); renamed.setItemMeta(rm);
        check(to, "renamed genuine core still genuine (no name lock)", m.items.isGenuine(renamed));
        ItemStack fake = new ItemStack(core.getType());
        ItemMeta fm = fake.getItemMeta(); fm.displayName(core.getItemMeta().displayName()); fake.setItemMeta(fm);
        check(to, "fake copy with identical name rejected", !m.items.isGenuine(fake));
        ItemStack tampered = core.clone();
        ItemMeta tm = tampered.getItemMeta();
        tm.getPersistentDataContainer().set(new NamespacedKey(m.plugin, "orison_core_sig"), PersistentDataType.STRING, "00");
        tampered.setItemMeta(tm);
        check(to, "tampered signature rejected", !m.items.isGenuine(tampered));
        UUID id = m.items.idOf(core);
        if (id != null) m.store.revoke(id);
        check(to, "revoked core rejected", !m.items.isGenuine(core));

        // store round trip
        UUID t = UUID.randomUUID();
        m.store.setFavs(t, List.of("scythe", "hammer"));
        check(to, "favourites persist", m.store.favs(t).equals(List.of("scythe", "hammer")));

        // Bukkit API sanity: display entities spawn and clean up
        if (to instanceof Player p) {
            ItemDisplay d = p.getWorld().spawn(p.getLocation(), ItemDisplay.class, x -> x.setPersistent(false));
            boolean ok = d.isValid();
            d.remove();
            check(to, "display entity spawn/remove", ok);
            Session s = m.sessions.get(p.getUniqueId());
            check(to, "your session active (wear a genuine core to test)", s != null);
            if (s != null) check(to, "session tasks bounded (" + s.tasks.size() + ")", s.tasks.size() <= m.cfg.getInt("limits.max-tasks-per-player", 40));
        }
        to.sendMessage(Component.text("Result: " + pass + " passed, " + fail + " failed", fail == 0 ? NamedTextColor.GREEN : NamedTextColor.RED));
    }
}
