package com.des.legendary.orison;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.util.*;

/**
 * ORISON entry point. NOT a plugin entrypoint: LegendaryPlugin calls enable() at the end of onEnable()
 * and disable() at the start of onDisable(). No second main class, no existing system touched.
 */
public final class OrisonModule {
    final JavaPlugin plugin;
    YamlConfiguration cfg;
    final Map<UUID, Session> sessions = new HashMap<>();
    Store store;
    OrisonItems items;
    Forge forge;
    Voice voice;
    private BukkitTask tick;
    int errors;
    String lastError = "";

    public OrisonModule(JavaPlugin plugin) { this.plugin = plugin; }

    public void enable() {
        reload();
        if (!cfg.getBoolean("enabled", true)) { plugin.getLogger().info("ORISON disabled in orison.yml"); return; }
        store = new Store(plugin);
        items = new OrisonItems(this);
        forge = new Forge();
        voice = new Voice(this);
        try { Abilities.validate(forge); }
        catch (IllegalStateException ex) { plugin.getLogger().severe("ORISON ability registry invalid, module not started: " + ex.getMessage()); return; }

        Bukkit.getPluginManager().registerEvents(new OrisonListener(this), plugin);
        OrisonCommand cmd = new OrisonCommand(this);
        PluginCommand pc = plugin.getCommand("orison");
        if (pc == null) plugin.getLogger().severe("Add the 'orison' command to plugin.yml (see README).");
        else { pc.setExecutor(cmd); pc.setTabCompleter(cmd); }
        tick = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 2, 2);
        plugin.getLogger().info("ORISON online: core roster " + Abilities.CORE.size() + "/8, weapons " + forge.catalogue.keySet());
    }

    public void disable() {
        if (tick != null) tick.cancel();
        for (Session s : sessions.values()) s.destroy();
        sessions.clear();
        if (store != null) store.save();
    }

    void reload() {
        File f = new File(plugin.getDataFolder(), "orison.yml");
        if (!f.exists()) plugin.saveResource("orison.yml", false);
        cfg = YamlConfiguration.loadConfiguration(f);
        Fx.intensity = Math.max(0.1, Math.min(1.0, cfg.getDouble("vfx.intensity", 1.0)));
    }

    private void tick() {
        Fx.budget = cfg.getInt("vfx.max-particles-per-tick", 3000);
        for (Player p : Bukkit.getOnlinePlayers()) {
            try {
                boolean worn = items.isGenuine(p.getInventory().getChestplate()) && p.hasPermission("orison.use");
                Session s = sessions.get(p.getUniqueId());
                if (worn && s == null) { s = new Session(this, p); s.activate(); sessions.put(p.getUniqueId(), s); }
                else if (!worn && s != null) { s.destroy(); sessions.remove(p.getUniqueId()); s = null; }
                if (s != null) s.tick();
            } catch (Throwable t) {
                errors++;
                lastError = t.getClass().getSimpleName() + ": " + t.getMessage();
                if (errors <= 5 || errors % 200 == 0) plugin.getLogger().log(java.util.logging.Level.SEVERE, "ORISON tick error for " + p.getName() + " (#" + errors + ")", t);
                Session bad = sessions.remove(p.getUniqueId());
                if (bad != null) { try { bad.destroy(); } catch (Throwable ignored) {} }
            }
        }
        sessions.values().removeIf(s -> { if (!s.p.isOnline()) { s.destroy(); return true; } return false; });
    }

    /** Never overwrites an equipped chestplate; falls back to inventory, then to the pending store. */
    void giveSafe(Player p, ItemStack core) {
        if (p.getInventory().getChestplate() == null) { p.getInventory().setChestplate(core); return; }
        Map<Integer, ItemStack> left = p.getInventory().addItem(core);
        if (!left.isEmpty()) {
            store.addPending(p.getUniqueId(), core);
            p.sendMessage(Component.text("ORISON ▸ Inventory full — your core is held safely and will be returned when there is room (/orison status).", NamedTextColor.GRAY));
        }
    }

    void returnPending(Player p) {
        if (!p.isOnline()) return;
        for (ItemStack it : store.takePending(p.getUniqueId())) giveSafe(p, it);
    }
}
