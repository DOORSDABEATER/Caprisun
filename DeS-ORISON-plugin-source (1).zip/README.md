# ORISON — honest status

## Build
- **Plugin (merge into DeS):** copy `src/main/java/com/des/legendary/orison/*` (EXCLUDING the `standalone/` folder) and `src/main/resources/orison.yml`, apply the 3 edits below. Your own pom needs Paper API 1.21.4+ and Java 21.
- **Quick test without DeS:** `mvn -Pstandalone package` -> `target/orison-1.0.0.jar` (a throwaway harness plugin containing only ORISON). Delete the `standalone/` folder before merging.
- **Resource pack:** `DeS-ORISON-resourcepack.zip` (ready to use) or regenerate with `python3 tools/build_pack.py` (reads the plugin source, so every custom_model_data id is guaranteed a model). Add it to your mandatory DeS pack by merging `assets/` (items/*.json files for the 11 base materials must be MERGED if you already override those items).
- Pack format 46 (1.21.4). For 1.21.9+ change `pack.mcmeta` to `min_format`/`max_format` per the current wiki.

## Resource pack contents (generated, not hand-modelled)
102 block-geometry models in violet/black/white (core with 3 rings + 6 fragments, 12 fragment variants, 14 weapons, Half/Full/MAX armour including the three MAX rings as differently-oriented hoops, props), 3 textures, HUD glyph font (energy cells, heat, flight, overdrive), `sounds.json` mapping every voice event to a vanilla placeholder sound. **These are blocky procedural models, not artist-quality Blockbench work; replace any `m<id>.json` with your own and keep the id.** Models are static: ring rotation comes from the plugin spinning the display entities. The core while worn in the chest slot renders as a purple leather chestplate (vanilla equipment layer); its 3D model shows in inventory/hand only.

## Latest additions
- **Core State visual:** crystal reactor + three independently spinning rings (GENERATION / HARMONICS / DISCORD) on the chest (`CoreVisual`); hides while armour is deployed; rings spin 2.2x in Overdrive.
- **Weapon swing animation:** weapon parts swing through an arc on every weapon-ability cast.
- **VFX limits:** `vfx.intensity` (0.1-1.0) and `vfx.max-particles-per-tick` hard budget in `orison.yml`.
- **Persistence:** resonance energy now saved per player (core, favourites, ultimate discovery already were).
- **Voice:** added victory, defeat, critical-danger and armour-damage lines (kills also grant resonance).
- **`/orison selftest` (admin):** in-server checks - roster sizes 8/10/12/16, 14 weapons x 8 abilities, unique ids, no forging cost keys, genuine/renamed/fake/tampered/revoked core identity, favourites persistence, display-entity spawn/cleanup, task bound. **Run this first after installing.**
- Pack now has 106 models (core visuals added).

## Verification status
Nothing here has been compiled or played. `/orison selftest` automates what can be checked without a human; everything else (VFX look, combat feel, assembly alignment, flight feel, balance, multiplayer sync) needs you in-game. Report failures and I will fix them.

# (earlier notes)

**Not compiled. Not run on a server. Not tested in-game.** This environment had no JDK, no Paper jar, and I could not see your DeS project or the NULL//REQUIEM source. Expect a round of compile fixes (most likely Paper-version API differences). Target: Paper 1.21.x, Java 21.

## Integration (3 edits to your existing project)
1. Copy `com/des/legendary/orison/*` into your source tree (package `com.des.legendary.orison`). If your real package/entrypoint differs, adjust only the package line.
2. In `LegendaryPlugin`: field `private OrisonModule orison;` — end of `onEnable()`: `orison = new OrisonModule(this); orison.enable();` — start of `onDisable()`: `if (orison != null) orison.disable();`
3. Merge `plugin-yml-snippet.yml` into plugin.yml; copy `orison.yml` to resources.

No second entrypoint, nothing existing is modified or replaced.

## Identity (no name lock)
`OrisonItems`: random core UUID + HMAC-SHA256 signature in the item PDC. Display name and player name are never read. Revocation list makes `/orison recover` safe (old ids die, one fresh core issued).
**Decision for you:** I could not inspect NULL//REQUIEM, so this is *not* a reuse of its scheme. If you want parity, swap the bodies of `create()` / `idOf()` — nothing else depends on them.

## What is implemented (all written, NONE compiled or run)
- **Core/identity/lifecycle:** signed-ID core (own scheme, no name lock), session per worn core, death/respawn/join return, indestructible drops, GUI-safe.
- **Four forms, exact roster sizes enforced at startup:** Core 8, Half 10, Full 12, MAX 16 (`Abilities.validate` refuses to start otherwise). Rosters are independent (no shared ids).
- **Armour (`Armour`):** piece-by-piece assembly/retraction for Half (9 pieces), Full (13, faceplate last), MAX (20 pieces: reinforced legs, expanded reactor, unfolding back array, shoulder weapons, oversized gauntlets, spine plates, three giant spinning rings that grow into place). Full->MAX is a real-time reconfiguration (parts detach, scatter, new architecture assembles). CORE->MAX auto-routes through Full. Display-entity based; equipment slots untouched.
- **Flight:** velocity-based, per-form speed/accel/brake/boost config (Paper 1.21.3+ for `getCurrentInput`).
- **Ultimates (5, separate from ability slots):** Chorus Collapse (Core), Tactical Dominion (Half), THE LAST CHORD - ZERO HOUR (Full: six anchors, ring sync, steerable sustained beam, shockwave), THE SOVEREIGN EXTINCTION (MAX: sky array, six pillars, 22-block layered detonation, collapsing field), and the secret **THE UNSTRUCK NOTE** (silence/banking mechanic; discovery = use each form ultimate once; activation = Overdrive + Sneak + `/orison ultimate`; perm `orison.secret`; hidden from help/GUI/tab; all configurable).
- **Discord Overdrive:** `/orison overdrive` - 10s high-output state (+35% damage, -40% cooldowns, faster fragments/rings/flight, extra heat, aftershock heat on expiry), per-form enable list, not a transformation.
- **Defence:** Resonance Shield / Aegis Dome / Layered Barrier (pool), Kinetic Absorption, Counterpulse (Full + MAX), Interceptor Grid, fragment interception, Emergency Barrier, impact dampening.
- **Forging (always free):** `/orison forge`, GUI, favourites, Sneak+1-5. **14 weapons, each with exactly 8 abilities (112 total):** scythe, hammer, spear, bow, sword, katana, axe, dagger, crossbow, shield, claws, staff, pickaxe, drill. Tools never break blocks.
- Fragments: six, distinct behaviours, MAX model swap + larger orbit, tactical fan formation in Half.
- Commands: forge, dismiss, cast, ultimate, overdrive, fav, status, fragments, transform core|half|full|max, deactivate, flight, give/remove/recover/reload/debug.

## NOT done
No weapons missing from the requested catalogue any more. Add more by copying the `Weapons2` pattern and registering in `Forge`.
Still not done: all resource-pack models/textures/sounds/voice recordings (code uses fallbacks), custom HUD font (action bar HUD only), weapon swing animations, restart-persistence of energy/form (core + favourites + ultimate discovery persist; armour deliberately re-deploys on demand), in-game verification of anything.

## Known limits / risks
- Items in the void are always removed by vanilla; use `/orison recover`.
- Leather chestplate gives 3 armour; swap material if you need 0.
- `Phantom Cut` teleports (short, block-checked) — whitelist in your anticheat if it flags.
- Weapon has no swing animation yet (parts follow the hand only); needs model animation work.
- Damage routes through `LivingEntity#damage(amount, player)` so protection plugins can cancel it; bosses capped via `damage.boss-cap-fraction`.

## Resource pack assets you must supply (fallback = vanilla item look)
| Item | Material | custom_model_data |
|---|---|---|
| Core | LEATHER_CHESTPLATE | 7100 |
| Fragments AEGIS…NEXUS | AMETHYST_SHARD | 7201–7206 |
| Half armour: boots L/R, chest, back, shoulder L/R, gauntlet L/R, visor | NETHERITE_INGOT | 7401-7409 |
| Full armour (13) | NETHERITE_INGOT | 7501-7513 |
| MAX armour (17) + rings | NETHERITE_INGOT | 7601-7617, rings 7621/7622/7623 |
| Ascendant fragments | AMETHYST_SHARD | 7211-7216 |
| Spectral blade / remote blade | NETHERITE_SWORD | 7350 / 7351 |
| Hammer / Spear / Bow icons+parts | NETHERITE_AXE / TRIDENT / BOW + parts | 7320-22 / 7330-33 / 7340-42 |
| Sword / Katana / Axe / Dagger | various | 7360-62 / 7370-72 / 7380-82 / 7390-91 |
| Crossbow / Shield / Claws / Staff / Pickaxe / Drill | various | 7710-12 / 7720-22 / 7730-32 / 7740-43 / 7750-52 / 7760-63 |
| Scythe icon / blade / shaft / pommel | NETHERITE_HOE / NETHERITE_SWORD | 7300 / 7301 / 7302 / 7303 |
Sounds (optional): `des:orison.voice.{online,forge,dismiss,lowenergy,overload,ultimate,intercept,hostile}`.
Purple `#963CFF`, deep `#3C0078`, white — used by all VFX.

## Test checklist (run before trusting any of it)
Give core → wear → fake copy / renamed copy / different player name → drop/relog/restart → die/respawn → forge scythe (GUI, command, favourites) → all 8 core + 8 scythe abilities → ultimate → check `/orison debug` task count stays bounded → disable plugin and confirm no displays remain.
