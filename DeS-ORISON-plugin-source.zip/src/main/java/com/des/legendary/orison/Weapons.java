package com.des.legendary.orison;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

/** Additional forgeable weapons. Each blueprint = parts + EXACTLY 8 abilities (Forge refuses anything else). */
final class Weapons {
    private static Ability a(String id, String name, String desc, int cost, int heat, Ability.Cast c) { return new Ability(id, name, desc, cost, heat, c); }
    private static Vector fl(Session s) { return Abilities.flat(s.p.getEyeLocation().getDirection()); }

    // ---------------- HAMMER ----------------
    static Forge.Blueprint hammer() {
        return new Forge.Blueprint("hammer", "Resonance Hammer", "Hammers", Material.NETHERITE_AXE, 7320,
            List.of(new Forge.Part(7321, new Vector(0, 1.0, 0.1), 1.3f), new Forge.Part(7322, new Vector(0, 0.1, 0), 1.0f)),
            List.of(
            a("hammer_pounding_blow", "Pounding Blow", "Heavy overhead strike with strong knockback.", 0, 4, s -> {
                Vector f = fl(s);
                Location c = s.p.getLocation().add(f.clone().multiply(2.4));
                Fx.burst(c, 2); Fx.sound(c, Sound.ENTITY_IRON_GOLEM_ATTACK, 1f, 0.5f);
                for (LivingEntity e : Scythe.cone(s, 4, 100)) s.hit(e, Abilities.d(s, "hammer_pounding_blow", 9), f.clone().multiply(1.1).setY(0.4));
                return 20;
            }),
            a("hammer_shockwave_slam", "Shockwave Slam", "Ground slam: ring of force racing outward.", 10, 6, s -> {
                Location c = s.p.getLocation(); Set<UUID> hit = new HashSet<>();
                Fx.sound(c, Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.7f);
                s.every(1, 8, t -> { double r = 1 + t * 0.8; Fx.ring(c.clone().add(0, 0.2, 0), r, (int) (r * 12), Fx.PURPLE);
                    for (LivingEntity e : Abilities.radius(s, c, r + 0.8)) if (hit.add(e.getUniqueId())) s.hit(e, Abilities.d(s, "hammer_shockwave_slam", 8), new Vector(0, 0.6, 0)); return false; }, null);
                return 120;
            }),
            a("hammer_quake_line", "Quake Line", "Fault line splits the ground forward, launching enemies.", 14, 8, s -> {
                Vector f = fl(s); Location o = s.p.getLocation();
                s.every(2, 20, t -> { Location c = o.clone().add(f.clone().multiply(2 + t * 0.6)); for (double y = 0; y < 2; y += 0.4) Fx.dust(c.clone().add(0, y, 0), Fx.DEEP, 4, 0.4);
                    for (LivingEntity e : Abilities.radius(s, c, 1.8)) s.hit(e, Abilities.d(s, "hammer_quake_line", 7), new Vector(0, 1.0, 0)); return false; }, null);
                return 160;
            }),
            a("hammer_stagger_swing", "Stagger Swing", "Full spin that staggers everything around you.", 12, 6, s -> {
                Fx.sound(s.p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, 1f, 0.5f);
                s.every(2, 12, t -> { Scythe.arc(s, new Vector(1, 0, 0).rotateAroundY(Math.toRadians(t * 60)), 0, 60, 1.8, 3.6); return false; }, () -> {
                    for (LivingEntity e : Abilities.radius(s, s.p.getLocation(), 3.8)) { s.hit(e, Abilities.d(s, "hammer_stagger_swing", 6), null); e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 30, 4, true, false)); }
                });
                return 140;
            }),
            a("hammer_meteor_drop", "Meteor Drop", "Launch skyward, then crash down as a meteor.", 24, 14, s -> {
                s.fallGuardUntil = s.now() + 100;
                s.p.setVelocity(new Vector(0, 1.5, 0));
                s.every(1, 60, t -> {
                    Fx.dust(s.p.getLocation(), Fx.PURPLE, 6, 0.3);
                    if (t == 12) s.p.setVelocity(fl(s).multiply(0.5).setY(-2.4));
                    if (t > 14 && s.p.isOnGround()) {
                        Location c = s.p.getLocation(); Fx.burst(c, 7); Fx.sound(c, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.6f);
                        for (LivingEntity e : Abilities.radius(s, c, 7)) s.hit(e, Abilities.d(s, "hammer_meteor_drop", 14), new Vector(0, 0.9, 0));
                        return true; }
                    return false; }, null);
                return 240;
            }),
            a("hammer_resonant_anvil", "Resonant Anvil", "Mark ground; a giant anvil of resonance falls after 1s.", 16, 8, s -> {
                Location c = Abilities.aim(s, 20);
                s.every(2, 20, t -> { Fx.ring(c.clone().add(0, 0.1, 0), 2.5 - t * 0.08, 24, Fx.WHITE); return false; }, () -> {
                    for (double y = 0; y < 10; y += 0.5) Fx.dust(c.clone().add(0, y, 0), Fx.DEEP, 5, 0.6);
                    Fx.burst(c, 3.5); Fx.sound(c, Sound.BLOCK_ANVIL_LAND, 1.5f, 0.5f);
                    for (LivingEntity e : Abilities.radius(s, c, 3.2)) s.hit(e, Abilities.d(s, "hammer_resonant_anvil", 15), new Vector(0, 0.3, 0)); });
                return 200;
            }),
            a("hammer_bulwark_stance", "Bulwark Stance", "Plant the hammer: Resistance II and absorption for 3s.", 12, 3, s -> {
                s.p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 60, 1, true, false));
                s.p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 60, 1, true, false));
                s.every(4, 60, t -> { Fx.ring(s.p.getLocation().add(0, 0.2, 0), 1.2, 16, Fx.DEEP); return false; }, null);
                Fx.sound(s.p.getLocation(), Sound.BLOCK_ANVIL_PLACE, 1f, 0.6f);
                return 240;
            }),
            a("hammer_titans_verdict", "Titan's Verdict", "Finisher: wind-up then colossal blow; heavy bonus vs slowed foes.", 50, 24, s -> {
                Vector f = fl(s);
                s.every(2, 10, t -> { Fx.ring(s.p.getLocation().add(0, 2.5, 0), 0.5 + t * 0.1, 14, Fx.WHITE); return false; }, () -> {
                    Location c = s.p.getLocation().add(f.clone().multiply(3));
                    Fx.burst(c, 6); Fx.sound(c, Sound.ENTITY_GENERIC_EXPLODE, 2f, 0.5f);
                    for (LivingEntity e : Abilities.radius(s, c, 6)) { boolean slow = e.hasPotionEffect(PotionEffectType.SLOWNESS);
                        s.hit(e, Abilities.d(s, "hammer_titans_verdict", 22) * (slow ? 1.4 : 1.0), f.clone().multiply(1.5).setY(0.8)); }
                });
                return 400;
            }))
        );
    }

    // ---------------- SPEAR ----------------
    static Forge.Blueprint spear() {
        return new Forge.Blueprint("spear", "Resonance Spear", "Spears", Material.ECHO_SHARD, 7330,
            List.of(new Forge.Part(7331, new Vector(0, 1.5, 0.1), 1.0f), new Forge.Part(7332, new Vector(0, 0.4, 0), 1.0f), new Forge.Part(7333, new Vector(0, -0.8, 0), 0.8f)),
            List.of(
            a("spear_thrust", "Thrust", "Fast five-block lunge-thrust.", 0, 2, s -> {
                Location from = s.p.getEyeLocation().add(0, -0.3, 0);
                Abilities.beam(s, from, from.getDirection(), 5, 0.7, Abilities.d(s, "spear_thrust", 8), false);
                Fx.sound(from, Sound.ITEM_TRIDENT_THROW, 1f, 1.4f);
                return 10;
            }),
            a("spear_javelin_throw", "Javelin Throw", "Hurl a resonance javelin; pierces and slows.", 8, 5, s -> {
                Location e = s.p.getEyeLocation(); Vector d = e.getDirection();
                Abilities.shoot(s, e.clone().add(d), d, 2.0, 40, 0.9, Abilities.d(s, "spear_javelin_throw", 12), true,
                    l -> { Fx.dust(l, Fx.WHITE, 2, 0.02); Fx.dust(l, Fx.PURPLE, 2, 0.1); }, l -> Fx.burst(l, 1.2));
                return 70;
            }),
            a("spear_vault_strike", "Vault Strike", "Pole-vault forward and stab on landing.", 12, 6, s -> {
                s.fallGuardUntil = s.now() + 60;
                s.p.setVelocity(fl(s).multiply(1.0).setY(0.9));
                s.every(1, 30, t -> { Fx.dust(s.p.getLocation(), Fx.PURPLE, 3, 0.2);
                    if (t >= 5 && s.p.isOnGround()) { Location c = s.p.getLocation(); Fx.burst(c, 3);
                        for (LivingEntity x : Abilities.radius(s, c, 3)) s.hit(x, Abilities.d(s, "spear_vault_strike", 10), new Vector(0, 0.6, 0)); return true; } return false; }, null);
                return 120;
            }),
            a("spear_sweeping_reach", "Sweeping Reach", "Wide long-reach sweep.", 6, 3, s -> {
                Vector f = fl(s);
                s.every(1, 3, t -> { Scythe.arc(s, f, -60 + t * 40, -20 + t * 40, 3, 6); return false; }, null);
                for (LivingEntity e : Scythe.cone(s, 6.2, 120)) s.hit(e, Abilities.d(s, "spear_sweeping_reach", 6), f.clone().multiply(0.6).setY(0.2));
                return 30;
            }),
            a("spear_pin", "Pin", "Impale and root a target for 2s.", 10, 5, s -> {
                LivingEntity t = Scythe.sight(s, 12); if (t == null) return -1;
                s.hit(t, Abilities.d(s, "spear_pin", 5), null);
                t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 7, true, false));
                t.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 40, 128, true, false));
                Fx.line(s.p.getEyeLocation(), t.getLocation().add(0, 1, 0), 0.3, Fx.WHITE); Fx.burst(t.getLocation(), 1.5);
                return 140;
            }),
            a("spear_triple_lunge", "Triple Lunge", "Three chained dash-thrusts.", 16, 8, s -> {
                int[] n = {0};
                s.every(4, 12, t -> { Vector d = s.p.getEyeLocation().getDirection(); s.p.setVelocity(d.clone().multiply(1.1).setY(0.1));
                    Abilities.beam(s, s.p.getEyeLocation(), d, 4, 0.8, Abilities.d(s, "spear_triple_lunge", 6), false); Fx.sound(s.p.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_1, 1f, 1.2f + n[0]++ * 0.2f); return false; }, null);
                return 140;
            }),
            a("spear_impale_rush", "Impale Rush", "Charge 8 blocks carrying the first enemy you hit.", 18, 10, s -> {
                Vector d = fl(s); LivingEntity[] carried = {null};
                s.every(1, 10, t -> { s.p.setVelocity(d.clone().multiply(1.3)); Fx.dust(s.p.getLocation().add(0, 1, 0), Fx.PURPLE, 5, 0.3);
                    if (carried[0] == null) for (LivingEntity e : Abilities.radius(s, s.p.getLocation().add(0, 1, 0), 1.8)) { carried[0] = e; break; }
                    if (carried[0] != null && s.valid(carried[0]) && !Session.boss(carried[0])) carried[0].teleport(s.p.getLocation().add(d.clone().multiply(1.5)));
                    return false; }, () -> { if (carried[0] != null && s.valid(carried[0])) { s.hit(carried[0], Abilities.d(s, "spear_impale_rush", 12), d.clone().multiply(0.8).setY(0.5)); Fx.burst(carried[0].getLocation(), 2); } });
                return 200;
            }),
            a("spear_skyfall_lance", "Skyfall Lance", "Finisher: a colossal lance falls on your target after 1s.", 50, 22, s -> {
                Location c = Abilities.aim(s, 35);
                s.every(2, 20, t -> { Fx.ring(c.clone().add(0, 0.1, 0), 3 - t * 0.1, 28, Fx.WHITE); for (double y = 20 - t; y < 24; y += 1) Fx.dust(c.clone().add(0, y, 0), Fx.PURPLE, 1, 0.1); return false; }, () -> {
                    for (double y = 0; y < 22; y += 0.4) Fx.dust(c.clone().add(0, y, 0), y < 3 ? Fx.WHITE : Fx.PURPLE, 4, 0.3);
                    Fx.burst(c, 4.5); Fx.sound(c, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 2f, 1.2f);
                    for (LivingEntity e : Abilities.radius(s, c, 3.5)) s.hit(e, Abilities.d(s, "spear_skyfall_lance", 22), new Vector(0, 0.8, 0)); });
                return 380;
            }))
        );
    }

    // ---------------- BOW ----------------
    static Forge.Blueprint bow() {
        return new Forge.Blueprint("bow", "Resonance Bow", "Ranged Weapons", Material.ECHO_SHARD, 7340,
            List.of(new Forge.Part(7341, new Vector(0.1, 1.0, 0.2), 1.1f), new Forge.Part(7342, new Vector(0.1, 1.0, 0.1), 1.0f)),
            List.of(
            a("bow_quick_shot", "Quick Shot", "Fast light arrow of resonance.", 2, 1, s -> { shot(s, s.p.getEyeLocation().getDirection(), 1.9, 40, Abilities.d(s, "bow_quick_shot", 6), false); return 6; }),
            a("bow_power_shot", "Power Shot", "Half-second draw, then a piercing heavy arrow.", 10, 6, s -> {
                s.every(2, 10, t -> { Fx.ring(Armour.gauntlet(s, false), 0.2 + t * 0.03, 10, Fx.PURPLE); return false; },
                    () -> shot(s, s.p.getEyeLocation().getDirection(), 2.4, 55, Abilities.d(s, "bow_power_shot", 14), true));
                return 60;
            }),
            a("bow_multishot", "Multishot", "Five-arrow fan.", 12, 6, s -> {
                Vector d = s.p.getEyeLocation().getDirection();
                for (int i = -2; i <= 2; i++) shot(s, d.clone().rotateAroundY(Math.toRadians(i * 8)), 1.8, 32, Abilities.d(s, "bow_multishot", 5), false);
                return 80;
            }),
            a("bow_arrow_rain", "Arrow Rain", "Volley falls on an area for 1.5s.", 18, 9, s -> {
                Location c = Abilities.aim(s, 35); Random r = new Random();
                s.every(2, 30, t -> { for (int i = 0; i < 3; i++) { Location p = c.clone().add((r.nextDouble() - .5) * 8, 0, (r.nextDouble() - .5) * 8);
                    for (double y = 0; y < 8; y += 0.6) Fx.dust(p.clone().add(0, y, 0), Fx.WHITE, 1, 0.02);
                    for (LivingEntity e : Abilities.radius(s, p, 1.4)) s.hit(e, Abilities.d(s, "bow_arrow_rain", 3), null); } return false; }, null);
                return 200;
            }),
            a("bow_homing_arrow", "Homing Arrow", "Arrow that bends toward your lock or nearest threat.", 14, 7, s -> {
                LivingEntity t = s.lockTarget() != null ? s.lockTarget() : Abilities.nearest(s, 35);
                Abilities.homing(s, s.p.getEyeLocation(), s.p.getEyeLocation().getDirection(), t, 1.5, Abilities.d(s, "bow_homing_arrow", 9), 1.5, 70);
                return 100;
            }),
            a("bow_piercing_beam", "Piercing Beam Arrow", "Instant 40-block line shot.", 20, 12, s -> {
                Abilities.beam(s, s.p.getEyeLocation(), s.p.getEyeLocation().getDirection(), 40, 0.6, Abilities.d(s, "bow_piercing_beam", 10), false); return 160;
            }),
            a("bow_grapple_arrow", "Grapple Arrow", "Reel yourself to the block you aim at (up to 25).", 8, 3, s -> {
                Location t = Abilities.aim(s, 25);
                if (t.distanceSquared(s.p.getLocation()) < 9) return -1;
                Fx.line(s.p.getEyeLocation(), t, 0.4, Fx.WHITE);
                s.fallGuardUntil = s.now() + 60;
                s.p.setVelocity(t.toVector().subtract(s.p.getLocation().toVector()).normalize().multiply(1.6).setY(0.3));
                return 100;
            }),
            a("bow_barrage", "Barrage", "Finisher: twenty arrows in two seconds.", 45, 20, s -> {
                int[] n = {0};
                s.every(2, 40, t -> { Vector d = s.p.getEyeLocation().getDirection().add(new Vector((Math.random() - .5) * .15, (Math.random() - .5) * .1, (Math.random() - .5) * .15));
                    shot(s, d, 2.0, 40, Abilities.d(s, "bow_barrage", 5), false); n[0]++; return false; }, null);
                return 320;
            }))
        );
    }

    private static void shot(Session s, Vector dir, double speed, double range, double dmg, boolean pierce) {
        Location from = s.p.getEyeLocation().add(dir.clone().normalize().multiply(0.9));
        Fx.sound(from, Sound.ENTITY_ARROW_SHOOT, 1f, 0.6f);
        Abilities.shoot(s, from, dir, speed, range, 0.7, dmg, pierce, l -> { Fx.dust(l, Fx.WHITE, 1, 0); Fx.dust(l, Fx.PURPLE, 1, 0.03); }, l -> Fx.spark(l, 6, 0.15));
    }
}
