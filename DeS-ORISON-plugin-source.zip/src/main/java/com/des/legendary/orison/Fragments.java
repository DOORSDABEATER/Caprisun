package com.des.legendary.orison;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Vector;

/** The six autonomous fragments. Six non-persistent ItemDisplays per session, hard-capped, removed on destroy. */
final class Fragments {
    enum Kind { AEGIS, VECTOR, LANCE, SENTRY, PULSE, NEXUS }
    static final int MODEL_BASE = 7200; // 7201..7206

    private final Session s;
    final ItemDisplay[] disp = new ItemDisplay[6];
    /** Non-null = this fragment is commanded to a fixed point (ultimates). */
    final Location[] override = new Location[6];
    private double ang;
    private int lanceReady;
    private LivingEntity target;
    private boolean announced;
    private Form modelForm;

    Fragments(Session s) { this.s = s; }

    void deploy() {
        remove();
        modelForm = null;
        for (int i = 0; i < 6; i++) {
            ItemStack it = new ItemStack(Material.AMETHYST_SHARD);
            ItemMeta meta = it.getItemMeta();
            meta.setCustomModelData(MODEL_BASE + 1 + i);
            it.setItemMeta(meta);
            final int idx = i;
            disp[i] = s.p.getWorld().spawn(orbit(i), ItemDisplay.class, d -> {
                d.setItemStack(it);
                d.setPersistent(false);               // never survives a restart -> no orphans
                d.setTeleportDuration(2);
                d.setBrightness(new Display.Brightness(15, 15));
                d.setViewRange(1.5f);
            });
        }
    }
    void remove() { for (int i = 0; i < 6; i++) { if (disp[i] != null) disp[i].remove(); disp[i] = null; override[i] = null; } }
    boolean alive() { for (ItemDisplay d : disp) if (d == null || !d.isValid()) return false; return true; }
    boolean nexusLinked() { return alive(); }
    boolean dampensFall() { return alive(); } // VECTOR stabilisation

    /** MAX swaps to the Ascendant fragment models (7211-7216). */
    private void applyModels() {
        for (int i = 0; i < 6; i++) {
            if (disp[i] == null) continue;
            ItemStack it = new ItemStack(Material.AMETHYST_SHARD);
            ItemMeta meta = it.getItemMeta();
            meta.setCustomModelData(MODEL_BASE + (s.form == Form.MAX ? 10 : 0) + 1 + i);
            it.setItemMeta(meta);
            disp[i].setItemStack(it);
            Fx.burst(disp[i].getLocation(), 0.8);
        }
    }

    private boolean anyOverride() { for (Location l : override) if (l != null) return true; return false; }

    Location orbit(int i) {
        if (s.form == Form.HALF) { // tactical formation: fixed fan behind the shoulders, gentle bob
            double yaw = Math.toRadians(s.p.getLocation().getYaw());
            double spread = (i - 2.5) * 0.42;
            double dx = Math.sin(yaw) * 1.5 * Math.cos(spread) - Math.cos(yaw) * 1.5 * Math.sin(spread);
            double dz = -Math.cos(yaw) * 1.5 * Math.cos(spread) - Math.sin(yaw) * 1.5 * Math.sin(spread);
            return s.p.getLocation().add(dx, 1.5 + 0.12 * Math.sin(ang * 2 + i), dz);
        }
        double a = ang + i * Math.PI * 2 / 6;
        double rad = 1.7 * (s.form == Form.MAX ? 1.5 : 1.0) * (s.od() ? 1.3 : 1.0);
        return s.p.getLocation().add(Math.cos(a) * rad, 1.4 + 0.25 * Math.sin(ang * 2 + i), Math.sin(a) * rad);
    }
    Location pos(int i) { return disp[i] == null ? s.p.getLocation() : disp[i].getLocation(); }

    void tick() {
        if (!alive() || disp[0].getWorld() != s.p.getWorld()) deploy(); // world change / lost entity -> rebuild
        if (modelForm != s.form) { modelForm = s.form; applyModels(); }
        ang += s.od() ? 0.43 : 0.24;
        for (int i = 0; i < 6; i++) {
            Location t = override[i] != null ? override[i].clone() : orbit(i);
            t.setYaw((float) Math.toDegrees(ang) + i * 60);
            disp[i].teleport(t);
        }
        if (anyOverride()) return; // an ability is commanding fragments
        if (!s.overloaded) s.gain(0.05);                    // PULSE: amplification
        aegis();
        if (s.ticks % 20 == 0) sentry();
        lance();
        if (s.ticks % 10 == 0) nexus();
    }

    private void aegis() { // AEGIS: projectile interception
        Location a = pos(Kind.AEGIS.ordinal());
        for (Projectile pr : a.getWorld().getNearbyEntitiesByType(Projectile.class, s.p.getLocation().add(0, 1, 0), 3.2)) {
            if (pr.isDead() || s.p.equals(pr.getShooter()) || pr.isOnGround()) continue;
            Fx.line(a, pr.getLocation(), 0.4, Fx.PURPLE);
            Fx.spark(pr.getLocation(), 8, 0.15);
            Fx.sound(pr.getLocation(), org.bukkit.Sound.BLOCK_AMETHYST_BLOCK_BREAK, 0.8f, 1.7f);
            pr.remove();
            s.gain(3);
            s.m.voice.say(s, "intercept");
        }
    }
    private void sentry() { // SENTRY: threat scan (mobs targeting you first, else nearest monster)
        LivingEntity best = null; double bd = 1e9;
        for (LivingEntity e : s.p.getWorld().getNearbyLivingEntities(s.p.getLocation(), 18)) {
            if (!s.valid(e) || !(e instanceof Mob mob)) continue;
            boolean hostile = s.p.equals(mob.getTarget()) || e instanceof Monster;
            if (!hostile) continue;
            double d = e.getLocation().distanceSquared(s.p.getLocation()) - (s.p.equals(mob.getTarget()) ? 100 : 0);
            if (d < bd) { bd = d; best = e; }
        }
        target = best;
        if (target != null) {
            Fx.dust(target.getEyeLocation().add(0, 0.6, 0), Fx.WHITE, 3, 0.1);
            if (!announced) { announced = true; s.m.voice.say(s, "hostile"); }
        } else announced = false;
    }
    private void lance() { // LANCE: precision bolt at the sentry's target
        if (target == null || !s.valid(target) || s.now() < lanceReady || s.overloaded) return;
        Location from = pos(Kind.LANCE.ordinal());
        Vector dir = target.getEyeLocation().toVector().subtract(from.toVector());
        if (dir.lengthSquared() > 20 * 20) return;
        lanceReady = s.now() + s.m.cfg.getInt("fragments.lance-interval-ticks", 50);
        Abilities.shoot(s, from, dir, 1.8, 24, 0.7, s.m.cfg.getDouble("fragments.lance-damage", 3.5), false,
                l -> Fx.dust(l, Fx.WHITE, 2, 0.02), l -> Fx.burst(l, 0.8));
    }
    private void nexus() { // NEXUS: visible synchronisation lattice (+5% cooldown reduction handled in Session.cast)
        if (!alive()) return;
        for (int i = 0; i < 6; i++) Fx.line(pos(i), pos((i + 1) % 6), 0.5, Fx.DEEP);
    }
}
