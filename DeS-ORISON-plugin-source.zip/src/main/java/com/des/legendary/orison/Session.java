package com.des.legendary.orison;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.*;
import org.bukkit.Location;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.function.IntPredicate;

/** Per-player live ORISON state. Exists only while a genuine core is worn. All tasks/entities are owned here. */
final class Session {
    enum Heat { NORMAL, ELEVATED, CRITICAL, OVERLOAD }

    final OrisonModule m;
    final Player p;
    Form form = Form.CORE;
    double energy = 50, heat = 0;
    boolean overloaded, destroyed, debug;
    final Map<String, Integer> cd = new HashMap<>();
    final Set<BukkitRunnable> tasks = new HashSet<>();
    Forge.Blueprint weapon;
    List<org.bukkit.entity.ItemDisplay> weaponParts = new ArrayList<>();
    int sel = 0, absorbUntil, voiceReady, emergencyReady, fallGuardUntil, markUntil, ticks;
    UUID mark;
    Fragments fragments;
    final Armour armour = new Armour(this);
    final Flight flight = new Flight(this);
    UUID lock;
    int lockUntil, scanUntil;
    final Set<UUID> scanned = new HashSet<>();
    final List<Entity> temp = new ArrayList<>();          // tracked props, always removed on destroy
    int counterUntil, barrierUntil, overdriveUntil;
    double counterStored, barrierHp, silenceBank;
    boolean remoteActive;
    final Set<UUID> silenced = new HashSet<>();
    final List<org.bukkit.entity.Mob> unaware = new ArrayList<>();

    Session(OrisonModule m, Player p) { this.m = m; this.p = p; }

    void activate() {
        fragments = new Fragments(this);
        fragments.deploy();
        m.voice.say(this, "online");
    }

    void destroy() {
        destroyed = true;
        for (BukkitRunnable r : new ArrayList<>(tasks)) { try { r.cancel(); } catch (IllegalStateException ignored) {} }
        tasks.clear();
        flight.cleanup();
        restoreAwareness();
        for (Entity e : new ArrayList<>(temp)) e.remove();
        temp.clear();
        armour.remove();
        m.forge.clearParts(this);
        if (fragments != null) fragments.remove();
    }

    int now() { return Bukkit.getCurrentTick(); }

    // ---- scheduling (bounded, auto-cleaned) ----
    /** Runs body every `period` ticks for `duration` ticks; body returns true to stop early. end always runs once. */
    void every(int period, int duration, IntPredicate body, Runnable end) {
        if (destroyed || tasks.size() >= m.cfg.getInt("limits.max-tasks-per-player", 24)) { if (end != null && !destroyed) end.run(); return; }
        BukkitRunnable r = new BukkitRunnable() {
            int t = 0;
            @Override public void run() {
                if (destroyed || !p.isOnline() || p.isDead()) { stop(); return; }
                boolean done = body.test(t);
                t += period;
                if (done || t >= duration) { stop(); if (end != null) end.run(); }
            }
            void stop() { cancel(); tasks.remove(this); }
        };
        tasks.add(r);
        r.runTaskTimer(m.plugin, 0, period);
    }

    // ---- targeting / damage (server-authoritative) ----
    boolean valid(LivingEntity e) {
        if (e == p || e.isDead() || !e.isValid() || e instanceof ArmorStand) return false;
        if (e instanceof Tameable t && t.isTamed() && p.getUniqueId().equals(t.getOwnerUniqueId())) return false;
        return !(e instanceof Player o && (o.getGameMode() == GameMode.SPECTATOR || o.getGameMode() == GameMode.CREATIVE));
    }
    static boolean boss(LivingEntity e) { return e instanceof EnderDragon || e instanceof Wither || e instanceof Warden; }

    @SuppressWarnings("deprecation")
    void hit(LivingEntity t, double dmg, Vector kb) {
        double d = dmg * m.cfg.getDouble("damage.multiplier", 1.0) * (od() ? m.cfg.getDouble("overdrive.damage-multiplier", 1.35) : 1.0);
        if (boss(t)) d = Math.min(d, m.cfg.getDouble("damage.boss-cap-fraction", 0.02) * t.getMaxHealth());
        if (silenced.contains(t.getUniqueId())) silenceBank += d;
        t.damage(d, p);
        if (kb != null && !boss(t)) t.setVelocity(t.getVelocity().add(kb));
        gain(2);
    }

    void gain(double e) { energy = Math.min(100, energy + e); }
    void addHeat(double h) { heat = Math.min(100, heat + h * (od() ? 1.3 : 1.0)); if (heat >= 100 && !overloaded) { overloaded = true; m.voice.say(this, "overload"); } }
    Heat heatLevel() { return overloaded ? Heat.OVERLOAD : heat < 40 ? Heat.NORMAL : heat < 70 ? Heat.ELEVATED : Heat.CRITICAL; }

    // ---- ability usage ----
    List<Ability> roster() { return weapon != null ? weapon.moveset() : Abilities.forForm(form); }
    Ability selected() { List<Ability> r = roster(); return r.get(Math.floorMod(sel, r.size())); }
    void cycle() {
        sel = Math.floorMod(sel + 1, roster().size());
        p.sendActionBar(Component.text("▶ " + selected().name(), NamedTextColor.LIGHT_PURPLE)
                .append(Component.text("  " + selected().desc(), NamedTextColor.GRAY)));
    }

    /** Forging/dismissal NEVER route through here, so they can never be blocked by energy, heat or cooldown. */
    void cast(Ability a) {
        if (destroyed || p.isDead() || p.getGameMode() == GameMode.SPECTATOR) return;
        int now = now();
        Integer ready = cd.get(a.id());
        if (ready != null && ready > now) { p.sendActionBar(Component.text(a.name() + " — " + ((ready - now + 19) / 20) + "s", NamedTextColor.GRAY)); return; }
        if (overloaded) { p.sendActionBar(Component.text("REACTOR OVERLOAD — venting", NamedTextColor.RED)); return; }
        if (energy < a.cost()) { p.sendActionBar(Component.text("Resonance low", NamedTextColor.RED)); m.voice.say(this, "lowenergy"); return; }
        energy -= a.cost();
        int c = a.cast().run(this);
        if (c < 0) { energy += a.cost(); return; }
        addHeat(a.heat());
        c = m.cfg.getInt("abilities." + a.id() + ".cooldown-ticks", c);
        if (od()) c = (int) (c * m.cfg.getDouble("overdrive.cooldown-multiplier", 0.6));
        if (fragments != null && fragments.nexusLinked()) c = (int) (c * 0.95);
        cd.put(a.id(), now + c);
    }

    boolean od() { return now() < overdriveUntil; }

    boolean secretUnlocked() {
        return m.store.ultsUsed(p.getUniqueId()).size() >= m.cfg.getInt("secret.required-ultimates", 4);
    }

    /** Discord Overdrive: temporary high-output state (NOT a fifth transformation). */
    void overdrive() {
        if (destroyed || overloaded || od()) return;
        if (!m.cfg.getStringList("overdrive.forms").isEmpty() && !m.cfg.getStringList("overdrive.forms").contains(form.name())) {
            p.sendMessage(Component.text("ORISON ▸ Overdrive is disabled for " + form.display + ".", NamedTextColor.GRAY)); return;
        }
        double cost = m.cfg.getDouble("overdrive.cost", 50);
        if (energy < cost) { p.sendActionBar(Component.text("Overdrive needs " + (int) cost + " resonance", NamedTextColor.RED)); return; }
        energy -= cost;
        overdriveUntil = now() + m.cfg.getInt("overdrive.duration-ticks", 200);
        m.voice.say(this, "overdrive");
        Fx.burst(p.getLocation().add(0, 1.2, 0), 4);
        Fx.sound(p.getLocation(), org.bukkit.Sound.ENTITY_WARDEN_SONIC_CHARGE, 1.2f, 0.6f);
    }

    void ultimate() {
        if (destroyed || overloaded) return;
        int now = now();
        boolean secret = od() && p.isSneaking() && secretUnlocked() && p.hasPermission("orison.secret");
        String ukey = secret ? "ult_secret" : "ult_" + form.name();
        Integer ready = cd.get(ukey);
        if (ready != null && ready > now) { p.sendActionBar(Component.text("Ultimate recharging " + ((ready - now + 19) / 20) + "s", NamedTextColor.GRAY)); return; }
        if (energy < 100) { p.sendActionBar(Component.text("Ultimate needs 100 resonance", NamedTextColor.RED)); return; }
        if (!secret && form != Form.CORE && !armour.ready) return;
        energy = 0;
        addHeat(40);
        m.voice.say(this, secret ? "secret" : "ultimate");
        if (secret) Ultimates.unstruckNote(this);
        else switch (form) {
            case CORE -> Abilities.chorusCollapse(this);
            case HALF -> Half.tacticalDominion(this);
            case FULL -> Ultimates.zeroHour(this);
            case MAX -> Ultimates.sovereignExtinction(this);
        }
        String key = secret ? "secret" : form.name().toLowerCase();
        cd.put(ukey, now + m.cfg.getInt("ultimates." + key + ".cooldown-ticks", secret ? 6000 : 3000));
        if (!secret) {
            boolean before = secretUnlocked();
            m.store.markUlt(p.getUniqueId(), form);
            if (!before && secretUnlocked() && m.cfg.getBoolean("secret.hint", true))
                p.sendMessage(Component.text("ORISON ▸ A fifth chord stirs beneath the four. Overdrive may reveal it.", NamedTextColor.DARK_PURPLE));
        }
    }

    void restoreAwareness() { for (org.bukkit.entity.Mob mob : unaware) if (mob.isValid()) mob.setAware(true); unaware.clear(); silenced.clear(); }

    LivingEntity lockTarget() {
        if (lock == null || now() >= lockUntil) return null;
        Entity e = Bukkit.getEntity(lock);
        return e instanceof LivingEntity le && valid(le) ? le : null;
    }

    /** Any form <-> any form. CORE->MAX goes through FULL first (standard architecture visibly becomes Ascendant). */
    void transform(Form f) {
        if (!f.implemented) { p.sendMessage(Component.text("ORISON ▸ " + f.display + " is not built.", NamedTextColor.RED)); return; }
        if (armour.busy) { p.sendMessage(Component.text("ORISON ▸ Armour is mid-sequence.", NamedTextColor.GRAY)); return; }
        if (f == form) return;
        if (f == Form.CORE) { m.voice.say(this, "retract"); armour.retract(m.cfg.getInt("transformation.retract-duration-ticks", 50)); return; }
        int dur = m.cfg.getInt("transformation." + f.name().toLowerCase() + "-duration-ticks", f == Form.HALF ? 64 : f == Form.FULL ? 110 : 140);
        if (form == Form.CORE) {
            if (f == Form.MAX) armour.assemble(Armour.FULL, Form.FULL, m.cfg.getInt("transformation.full-duration-ticks", 110), () -> { if (!destroyed && form == Form.FULL) armour.transition(Armour.MAX, Form.MAX, m.cfg.getInt("transformation.max-duration-ticks", 140)); });
            else armour.assemble(Armour.piecesFor(f), f, dur);
        } else armour.transition(Armour.piecesFor(f), f, dur);
    }

    // ---- per-0.1s tick ----
    void tick() {
        ticks += 2;
        if (!overloaded) gain(m.cfg.getDouble("energy.regen-per-second", 1.5) / 10.0);
        else { energy = Math.max(0, energy - 0.3); if (ticks % 10 == 0) p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 25, 0, true, false)); }
        heat = Math.max(0, heat - (overloaded ? 0.35 : 0.12));
        if (overloaded && heat < 60) overloaded = false;
        fragments.tick();
        if (overdriveUntil != 0 && !od()) { overdriveUntil = 0; addHeat(20); m.voice.say(this, "retract"); }
        if (od() && ticks % 4 == 0) {
            Location core = p.getLocation().add(0, 1.3, 0);
            Fx.ring(core.clone().add(0, (ticks % 20) * 0.02, 0), 0.7, 14, Fx.WHITE);
            Fx.dust(core, Fx.PURPLE, 4, 0.5);
            Fx.spark(p.getEyeLocation(), 1, 0.05);
        }
        m.forge.follow(this);
        armour.follow();
        if (ticks % 6 == 0) hud();
    }

    private static final Key HUD_FONT = Key.key("des", "orison_hud");
    /** Energy bar drawn with the pack's HUD font (E000 filled cell / E001 empty cell). */
    private static Component cells(int filled) {
        Component c = Component.empty();
        for (int i = 0; i < 10; i++)
            c = c.append(Component.text(i < filled ? "\uE000" : "\uE001", i < filled ? NamedTextColor.LIGHT_PURPLE : NamedTextColor.DARK_GRAY).font(HUD_FONT));
        return c;
    }

    void hud() {
        Ability a = selected();
        Integer ready = cd.get(a.id());
        String cdTxt = ready != null && ready > now() ? ((ready - now() + 19) / 20) + "s" : "READY";
        int bars = (int) Math.round(energy / 10);
        Component c = Component.text("ORISON ", NamedTextColor.DARK_PURPLE)
                .append(Component.text(form.display + "  ", NamedTextColor.LIGHT_PURPLE))
                .append(cells(bars))
                .append(Component.text(" " + (int) energy + "  ", NamedTextColor.WHITE))
                .append(Component.text("\uE002 ", heatLevel() == Heat.NORMAL ? NamedTextColor.WHITE : NamedTextColor.RED).font(HUD_FONT))
                .append(Component.text(heatLevel().name() + "  ", heatLevel() == Heat.NORMAL ? NamedTextColor.WHITE : NamedTextColor.RED))
                .append(Component.text(flight.on ? "\uE003 " : "", NamedTextColor.WHITE).font(HUD_FONT)).append(Component.text(od() ? "\uE004 " : "", NamedTextColor.LIGHT_PURPLE).font(HUD_FONT))
                .append(Component.text((weapon != null ? weapon.name() + " ▸ " : "") + a.name() + " [" + cdTxt + "]", NamedTextColor.GRAY));
        p.sendActionBar(c);
    }
}
