package com.des.legendary.orison;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.*;
import java.util.stream.Collectors;

final class OrisonCommand implements CommandExecutor, TabCompleter {
    private final OrisonModule m;
    OrisonCommand(OrisonModule m) { this.m = m; }

    private static void msg(CommandSender s, String t, NamedTextColor c) { s.sendMessage(Component.text("ORISON ▸ ", NamedTextColor.DARK_PURPLE).append(Component.text(t, c))); }

    @Override public boolean onCommand(CommandSender snd, Command cmd, String lbl, String[] a) {
        String sub = a.length == 0 ? "help" : a[0].toLowerCase(Locale.ROOT);
        boolean admin = snd.hasPermission("orison.admin");
        switch (sub) {
            case "reload" -> { if (!admin) return deny(snd); m.reload(); msg(snd, "Reloaded.", NamedTextColor.WHITE); }
            case "give", "remove", "recover" -> {
                if (!admin) return deny(snd);
                if (a.length < 2 || Bukkit.getPlayerExact(a[1]) == null) { msg(snd, "Usage: /orison " + sub + " <online player>", NamedTextColor.RED); return true; }
                admin(snd, sub, Bukkit.getPlayerExact(a[1]));
            }
            default -> {
                if (!(snd instanceof Player p)) { msg(snd, "Players only.", NamedTextColor.RED); return true; }
                if (!p.hasPermission("orison.use")) return deny(snd);
                player(p, sub, a);
            }
        }
        return true;
    }

    private boolean deny(CommandSender s) { msg(s, "No permission.", NamedTextColor.RED); return true; }

    private void admin(CommandSender snd, String sub, Player t) {
        UUID id = t.getUniqueId();
        switch (sub) {
            case "give" -> { m.giveSafe(t, m.items.create(id)); msg(snd, "Core issued to " + t.getName() + ".", NamedTextColor.WHITE); }
            case "remove" -> {
                m.store.issuedTo(id).forEach(m.store::revoke);
                strip(t.getInventory());
                msg(snd, "All cores issued to " + t.getName() + " revoked and removed.", NamedTextColor.WHITE);
            }
            case "recover" -> { // revoke old ids first so a recovered core can never coexist with a duplicate
                m.store.issuedTo(id).forEach(m.store::revoke);
                strip(t.getInventory());
                m.giveSafe(t, m.items.create(id));
                msg(snd, "Recovered: old cores revoked, fresh core issued to " + t.getName() + ".", NamedTextColor.WHITE);
            }
        }
    }
    private void strip(PlayerInventory inv) {
        for (int i = 0; i < inv.getSize(); i++) if (m.items.isGenuine(inv.getItem(i))) inv.setItem(i, null);
        if (m.items.isGenuine(inv.getChestplate())) inv.setChestplate(null);
    }

    private void player(Player p, String sub, String[] a) {
        Session s = m.sessions.get(p.getUniqueId());
        switch (sub) {
            case "help" -> msg(p, "forge [weapon] · dismiss · cast <n|id> · ultimate · overdrive · fav <weapon> · status · fragments · transform <form> · deactivate · debug. F = cast, Sneak+F = cycle, Sneak+1-5 = favourites.", NamedTextColor.GRAY);
            case "forge" -> {
                if (s == null) { msg(p, "Wear a genuine ORISON core in the chest slot first.", NamedTextColor.RED); return; }
                if (a.length < 2) m.forge.openGui(p, 0, null);
                else if (!m.forge.forge(s, a[1])) msg(p, "Unknown weapon. Available: " + String.join(", ", m.forge.catalogue.keySet()), NamedTextColor.RED);
            }
            case "dismiss" -> { if (s != null) m.forge.dismiss(s, true); }
            case "cast" -> {
                if (s == null) { msg(p, "No active core.", NamedTextColor.RED); return; }
                if (a.length < 2) { msg(p, "Usage: /orison cast <1-8|id>", NamedTextColor.RED); return; }
                Ability found = null;
                List<Ability> all = new ArrayList<>(Abilities.forForm(s.form));
                if (s.weapon != null) all.addAll(s.weapon.moveset());
                for (Ability x : all) if (x.id().equalsIgnoreCase(a[1])) found = x;
                if (found == null) try { List<Ability> r = s.roster(); found = r.get(Integer.parseInt(a[1]) - 1); } catch (Exception ignored) {}
                if (found == null) msg(p, "No such ability.", NamedTextColor.RED); else s.cast(found);
            }
            case "overdrive" -> { if (s != null) s.overdrive(); }
            case "ultimate" -> { if (s != null && p.hasPermission("orison.ultimate")) s.ultimate(); }
            case "fav" -> {
                if (a.length < 2 || !m.forge.catalogue.containsKey(a[1].toLowerCase())) { msg(p, "Usage: /orison fav <weapon>", NamedTextColor.RED); return; }
                List<String> f = m.store.favs(p.getUniqueId());
                if (!f.remove(a[1].toLowerCase())) { f.add(a[1].toLowerCase()); while (f.size() > 5) f.remove(0); }
                m.store.setFavs(p.getUniqueId(), f);
                msg(p, "Favourites: " + f, NamedTextColor.WHITE);
            }
            case "status", "energy" -> {
                if (s == null) { msg(p, "No active core.", NamedTextColor.RED); return; }
                msg(p, s.form.display + " | resonance " + (int) s.energy + "/100 | heat " + s.heatLevel() + " | weapon " + (s.weapon == null ? "none" : s.weapon.name())
                        + " | fragments " + (s.fragments.alive() ? "6/6" : "recovering") + (s.od() ? " | OVERDRIVE" : ""), NamedTextColor.WHITE);
            }
            case "fragments" -> { if (s != null) { s.fragments.deploy(); msg(p, "Fragments redeployed.", NamedTextColor.WHITE); } }
            case "transform" -> {
                if (s == null) return;
                Form f = a.length > 1 ? Arrays.stream(Form.values()).filter(x -> x.name().equalsIgnoreCase(a[1])).findFirst().orElse(null) : null;
                if (f == null) msg(p, "Usage: /orison transform <core|half|full|max>", NamedTextColor.RED);
                else s.transform(f);
            }
            case "deactivate" -> { if (s != null) s.transform(Form.CORE); }
            case "flight" -> { if (s != null) s.flight.toggle(); }
            case "debug" -> { if (s != null && p.hasPermission("orison.admin")) { s.debug = !s.debug; msg(p, "debug " + s.debug + " tasks=" + s.tasks.size(), NamedTextColor.GRAY); } }
            default -> msg(p, "Unknown subcommand. /orison help", NamedTextColor.RED);
        }
    }

    @Override public List<String> onTabComplete(CommandSender snd, Command c, String l, String[] a) {
        List<String> opts = new ArrayList<>();
        if (a.length == 1) {
            opts.addAll(List.of("forge", "dismiss", "cast", "ultimate", "fav", "status", "energy", "fragments", "transform", "deactivate", "flight", "overdrive", "help"));
            if (snd.hasPermission("orison.admin")) opts.addAll(List.of("give", "remove", "recover", "reload", "debug"));
        } else if (a.length == 2) {
            switch (a[0].toLowerCase()) {
                case "forge", "fav" -> opts.addAll(m.forge.catalogue.keySet());
                case "transform" -> Arrays.stream(Form.values()).forEach(f -> opts.add(f.name().toLowerCase()));
                case "cast" -> { Abilities.CORE.forEach(x -> opts.add(x.id())); m.forge.catalogue.values().forEach(b -> b.moveset().forEach(x -> opts.add(x.id()))); }
                case "give", "remove", "recover" -> Bukkit.getOnlinePlayers().forEach(p -> opts.add(p.getName()));
            }
        }
        String pre = a[a.length - 1].toLowerCase();
        return opts.stream().filter(x -> x.toLowerCase().startsWith(pre)).collect(Collectors.toList());
    }
}
