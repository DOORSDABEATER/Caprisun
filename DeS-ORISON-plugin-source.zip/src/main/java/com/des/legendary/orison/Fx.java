package com.des.legendary.orison;

import org.bukkit.*;
import org.bukkit.util.Vector;

/** Violet / black / white VFX toolkit. Everything is cosmetic; damage never depends on it. */
final class Fx {
    static final Particle.DustOptions PURPLE = new Particle.DustOptions(Color.fromRGB(150, 60, 255), 1.4f);
    static final Particle.DustOptions DEEP = new Particle.DustOptions(Color.fromRGB(60, 0, 120), 1.9f);
    static final Particle.DustOptions WHITE = new Particle.DustOptions(Color.fromRGB(255, 255, 255), 1.0f);

    static void dust(Location l, Particle.DustOptions o, int n, double sp) {
        l.getWorld().spawnParticle(Particle.DUST, l, n, sp, sp, sp, 0, o);
    }
    static void spark(Location l, int n, double sp) {
        World w = l.getWorld();
        w.spawnParticle(Particle.END_ROD, l, n, sp, sp, sp, 0.03);
        w.spawnParticle(Particle.ELECTRIC_SPARK, l, n, sp, sp, sp, 0.1);
    }
    static void ring(Location c, double r, int pts, Particle.DustOptions o) {
        for (int i = 0; i < pts; i++) {
            double a = i * Math.PI * 2 / pts;
            dust(c.clone().add(Math.cos(a) * r, 0, Math.sin(a) * r), o, 1, 0);
        }
    }
    static void line(Location a, Location b, double step, Particle.DustOptions o) {
        Vector d = b.toVector().subtract(a.toVector());
        double len = d.length();
        if (len < 0.01) return;
        d.normalize().multiply(step);
        Location c = a.clone();
        for (double i = 0; i < len; i += step) { dust(c, o, 1, 0); c.add(d); }
    }
    static void helix(Location from, Vector dir, double len, double rad) {
        Vector f = dir.clone().normalize();
        Vector u = f.clone().crossProduct(new Vector(0, 1, 0));
        if (u.lengthSquared() < 1e-4) u = new Vector(1, 0, 0);
        u.normalize();
        Vector v = f.clone().crossProduct(u).normalize();
        for (double t = 0; t < len; t += 0.25) {
            Location axis = from.clone().add(f.clone().multiply(t));
            for (int k = 0; k < 2; k++) {
                double a = t * 3.0 + k * Math.PI;
                dust(axis.clone().add(u.clone().multiply(Math.cos(a) * rad)).add(v.clone().multiply(Math.sin(a) * rad)),
                        k == 0 ? PURPLE : WHITE, 1, 0);
            }
            dust(axis, DEEP, 1, 0.02);
        }
    }
    /** Ring in the plane perpendicular to dir (for flying ring projectiles). */
    static void discRing(Location c, Vector dir, double r, int pts, Particle.DustOptions o) {
        Vector f = dir.clone().normalize();
        Vector u = f.clone().crossProduct(new Vector(0, 1, 0));
        if (u.lengthSquared() < 1e-4) u = new Vector(1, 0, 0);
        u.normalize();
        Vector v = f.clone().crossProduct(u).normalize();
        for (int i = 0; i < pts; i++) {
            double a = i * Math.PI * 2 / pts;
            dust(c.clone().add(u.clone().multiply(Math.cos(a) * r)).add(v.clone().multiply(Math.sin(a) * r)), o, 1, 0);
        }
    }
    static void sound(Location l, Sound s, float vol, float pitch) {
        l.getWorld().playSound(l, s, SoundCategory.PLAYERS, vol, pitch);
    }
    static void burst(Location l, double r) {
        ring(l, r, Math.max(16, (int) (r * 12)), PURPLE);
        ring(l, r * 0.6, Math.max(12, (int) (r * 8)), WHITE);
        spark(l, 12, r * 0.3);
        sound(l, Sound.BLOCK_AMETHYST_CLUSTER_BREAK, 1f, 0.8f);
    }
}
