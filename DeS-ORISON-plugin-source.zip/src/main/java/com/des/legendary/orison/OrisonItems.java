package com.des.legendary.orison;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.persistence.PersistentDataType;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import java.util.UUID;

/**
 * Genuine-core identity. NO NAME LOCK: nothing here reads the display name or the player's name.
 * Identity = random core UUID + HMAC signature (server secret) in the item's PersistentDataContainer.
 * Survives rename / move / drop / storage / relog / restart / world change. Copies made without the
 * secret cannot be signed. Revocation (admin remove/recover) kills a stale id so recovery never duplicates.
 *
 * INTEGRATION HOOK: if NULL//REQUIEM already has a proven identity scheme, replace the body of
 * isGenuine()/create() with a call into it. Every other class only talks to these two methods.
 */
final class OrisonItems {
    static final int CORE_MODEL = 7100;
    private final OrisonModule m;
    private final NamespacedKey ID, SIG;
    private final byte[] secret;

    OrisonItems(OrisonModule m) {
        this.m = m;
        ID = new NamespacedKey(m.plugin, "orison_core_id");
        SIG = new NamespacedKey(m.plugin, "orison_core_sig");
        secret = m.store.secret().getBytes(StandardCharsets.UTF_8);
    }

    private String sign(String id) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret, "HmacSHA256"));
            return HexFormat.of().formatHex(mac.doFinal(id.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) { throw new IllegalStateException(e); }
    }

    ItemStack create(UUID owner) {
        UUID id = UUID.randomUUID();
        ItemStack it = new ItemStack(Material.LEATHER_CHESTPLATE);
        LeatherArmorMeta meta = (LeatherArmorMeta) it.getItemMeta();
        meta.setColor(Color.fromRGB(100, 30, 190)); // fallback look if the pack is missing
        meta.setCustomModelData(CORE_MODEL);
        meta.setUnbreakable(true);
        meta.addItemFlags(ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_DYE);
        meta.displayName(Component.text("ORISON — THE LAST CHORD", NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD)
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(List.of(
                Component.text("The Sovereign Resonance Armour", NamedTextColor.DARK_PURPLE).decoration(TextDecoration.ITALIC, false),
                Component.text("Wear in the chest slot to awaken.", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
        meta.getPersistentDataContainer().set(ID, PersistentDataType.STRING, id.toString());
        meta.getPersistentDataContainer().set(SIG, PersistentDataType.STRING, sign(id.toString()));
        it.setItemMeta(meta);
        m.store.issue(id, owner);
        return it;
    }

    UUID idOf(ItemStack it) {
        if (it == null || it.getType() != Material.LEATHER_CHESTPLATE || !it.hasItemMeta()) return null;
        var pdc = it.getItemMeta().getPersistentDataContainer();
        String id = pdc.get(ID, PersistentDataType.STRING), sig = pdc.get(SIG, PersistentDataType.STRING);
        if (id == null || sig == null) return null;
        if (!MessageDigest.isEqual(sign(id).getBytes(StandardCharsets.UTF_8), sig.getBytes(StandardCharsets.UTF_8))) return null;
        try { UUID u = UUID.fromString(id); return m.store.revoked(u) ? null : u; } catch (IllegalArgumentException e) { return null; }
    }

    boolean isGenuine(ItemStack it) { return idOf(it) != null; }
}
