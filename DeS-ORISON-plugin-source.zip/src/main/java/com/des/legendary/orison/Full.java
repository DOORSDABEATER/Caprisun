package com.des.legendary.orison;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Projectile;
import org.bukkit.util.Vector;

import java.util.*;

/** FULL TRANSFORMATION — Sovereign Armour. Exactly 12 abilities. */
final class Full {
    static final List<Ability> ROSTER = new ArrayList<>();
    private static void add(String id, String name, String desc, int cost, int heat, Ability.Cast c) { ROSTER.add(new Ability(id, name, desc, cost, heat, c)); }
    static Vector look(Session s) { return s.p.getEyeLocation().getDirection(); }

    static {
        add("full_repulsor_blast", "Repulsor Blast", "Rapid palm bolt, alternating hands.", 3, 2, s -> {
            boolean right = (s.now() / 4) % 2 == 0;
            Location from = Armour.gauntlet(s, right);
            Vector dir = Half.aimPoint(s).toVector().subtract(from.toVector());
            Fx.sound(from, Sound.ENTITY_BLAZE_SHOOT, 0.8f, 1.9f);
            Abilities.shoot(s, from, dir, 2.0, 40, 0.9, Abilities.d(s, "full_repulsor_blast", 7), false,
                    l -> { Fx.dust(l, Fx.PURPLE, 2, 0.04); Fx.dust(l, Fx.WHITE, 1, 0); }, l -> Fx.burst(l, 1.0));
            return 6;
        });

        add("full_dual_repulsors", "Dual Repulsors", "Both palms fire short-range beams at once.", 14, 7, s -> {
            double dmg = Abilities.d(s, "full_dual_repulsors", 6);
            for (boolean r : new boolean[]{false, true}) {
                Location from = Armour.gauntlet(s, r);
                Vector dir = Half.aimPoint(s).toVector().subtract(from.toVector());
                Abilities.beam(s, from, dir, 14, 0.8, dmg, false);
            }
            Fx.sound(s.p.getLocation(), Sound.ENTITY_ILLUSIONER_CAST_SPELL, 1f, 1.5f);
            return 70;
        });

        add("full_charged_repulsor", "Charged Repulsor", "0.8s palm charge, then a massive piercing bolt.", 22, 12, s -> {
            Fx.sound(s.p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.8f);
            s.every(2, 16, t -> {
                Location g = Armour.gauntlet(s, true);
                Fx.ring(g, 0.2 + t * 0.03, 12, Fx.PURPLE); Fx.dust(g, Fx.WHITE, 3, 0.1 + t * 0.01);
                return false;
            }, () -> {
                Location from = Armour.gauntlet(s, true);
                Vector dir = Half.aimPoint(s).toVector().subtract(from.toVector());
                Fx.sound(from, Sound.ENTITY_WARDEN_SONIC_BOOM, 1f, 1.6f);
                Abilities.shoot(s, from, dir, 2.2, 45, 1.4, Abilities.d(s, "full_charged_repulsor", 16), true,
                        l -> { Fx.dust(l, Fx.PURPLE, 6, 0.2); Fx.dust(l, Fx.WHITE, 3, 0.1); Fx.discRing(l, dir, 0.7, 10, Fx.DEEP); },
                        l -> Fx.burst(l, 2.5));
            });
            return 160;
        });

        add("full_unibeam", "Unibeam", "Chest reactor discharge: sustained focused beam you can steer.", 30, 18, s -> {
            double dmg = Abilities.d(s, "full_unibeam", 3);
            Fx.sound(s.p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1.2f, 0.6f);
            s.every(2, 24, t -> {
                Abilities.beam(s, Armour.reactor(s), look(s), 16, 1.0, t % 4 == 0 ? dmg : 0, false);
                Fx.ring(Armour.reactor(s), 0.4, 10, Fx.WHITE);
                return false;
            }, null);
            return 240;
        });

        add("full_resonance_nova", "Resonance Nova", "Reactor detonation: huge expanding shockwave.", 35, 20, s -> {
            Location c = s.p.getLocation().add(0, 1, 0);
            double dmg = Abilities.d(s, "full_resonance_nova", 14);
            Set<UUID> hit = new HashSet<>();
            Fx.sound(c, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.8f);
            s.every(1, 11, t -> {
                double r = 1 + t * 0.75;
                Fx.ring(c, r, (int) (r * 12), Fx.PURPLE); Fx.ring(c.clone().add(0, 0.5, 0), r * 0.8, (int) (r * 10), Fx.WHITE); Fx.ring(c.clone().add(0, -0.4, 0), r * 0.9, (int) (r * 10), Fx.DEEP);
                for (LivingEntity e : Abilities.radius(s, c, r + 0.8)) if (hit.add(e.getUniqueId()))
                    s.hit(e, dmg, e.getLocation().toVector().subtract(c.toVector()).setY(0).normalize().multiply(1.2).setY(0.5));
                return false;
            }, null);
            return 260;
        });

        add("full_aegis_dome", "Aegis Dome", "4s spherical barrier: deletes up to 20 projectiles, shoves enemies out.", 18, 6, s -> {
            int[] left = {20};
            Random rnd = new Random();
            Fx.sound(s.p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.4f);
            s.every(2, 80, t -> {
                Location c = s.p.getLocation().add(0, 1, 0);
                for (int i = 0; i < 30; i++) {
                    Vector v = new Vector(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian()).normalize().multiply(3.5);
                    Fx.dust(c.clone().add(v), i % 4 == 0 ? Fx.WHITE : Fx.PURPLE, 1, 0);
                }
                for (Projectile pr : c.getWorld().getNearbyEntitiesByType(Projectile.class, c, 3.8)) {
                    if (pr.isDead() || s.p.equals(pr.getShooter())) continue;
                    pr.remove(); Fx.spark(pr.getLocation(), 8, 0.2); s.gain(2);
                    if (--left[0] <= 0) { Fx.burst(c, 3); return true; }
                }
                for (LivingEntity e : Abilities.radius(s, c, 3.6)) if (!Session.boss(e))
                    e.setVelocity(e.getLocation().toVector().subtract(c.toVector()).normalize().multiply(0.5).setY(0.1));
                return false;
            }, null);
            return 280;
        });

        add("full_missile_barrage", "Missile Barrage", "Eight homing missiles spread across the three nearest threats.", 28, 14, s -> {
            List<LivingEntity> tg = Abilities.targets(s, 35, 3);
            LivingEntity lt = s.lockTarget();
            double dmg = Abilities.d(s, "full_missile_barrage", 5);
            int[] n = {0};
            s.every(2, 16, t -> {
                LivingEntity tgt = lt != null ? lt : tg.isEmpty() ? null : tg.get(n[0] % tg.size());
                Location from = Armour.shoulder(s, n[0] % 2 == 0);
                Fx.sound(from, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.7f, 1.0f);
                Abilities.homing(s, from, look(s).add(new Vector((n[0] % 2 == 0 ? 0.5 : -0.5), 0.8, 0)).normalize(), tgt, 1.0, dmg, 2.2, 70);
                n[0]++;
                return false;
            }, null);
            return 200;
        });

        add("full_fragment_swarm", "Fragment Swarm", "All six fragments detach and hunt separate enemies.", 24, 10, s -> {
            for (Location o : s.fragments.override) if (o != null) return -1;
            List<LivingEntity> tg = Abilities.targets(s, 30, 6);
            Location aim = Abilities.aim(s, 30);
            double dmg = Abilities.d(s, "full_fragment_swarm", 6);
            s.every(2, 40, t -> {
                for (int i = 0; i < 6; i++) {
                    LivingEntity e = tg.isEmpty() ? null : tg.get(i % tg.size());
                    Location base = e != null && s.valid(e) ? e.getLocation().add(0, e.getHeight() + 0.8, 0) : aim.clone().add(0, 2, 0);
                    double a = t * 0.4 + i;
                    s.fragments.override[i] = base.clone().add(Math.cos(a) * 1.2, Math.sin(t * 0.5 + i) * 0.4, Math.sin(a) * 1.2);
                    if (t % 8 == 0 && t >= 8 && e != null && s.valid(e)) {
                        Fx.line(s.fragments.override[i], e.getLocation().add(0, 1, 0), 0.4, Fx.PURPLE);
                        s.hit(e, dmg, null);
                    }
                }
                return false;
            }, () -> { for (int i = 0; i < 6; i++) s.fragments.override[i] = null; });
            return 220;
        });

        add("full_afterburner_ram", "Afterburner Ram", "Rocket-boost forward through enemies.", 20, 10, s -> {
            Vector dir = look(s).normalize();
            double dmg = Abilities.d(s, "full_afterburner_ram", 10);
            Set<UUID> hit = new HashSet<>();
            s.fallGuardUntil = s.now() + 60;
            Fx.sound(s.p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1f, 0.6f);
            s.every(1, 10, t -> {
                s.p.setVelocity(dir.clone().multiply(2.0));
                Location l = s.p.getLocation().add(0, 1, 0);
                Fx.dust(l.clone().subtract(dir.clone().multiply(0.8)), Fx.PURPLE, 8, 0.3); Fx.spark(l.clone().subtract(dir), 3, 0.2);
                for (LivingEntity e : Abilities.radius(s, l, 2.2)) if (hit.add(e.getUniqueId())) s.hit(e, dmg, dir.clone().multiply(1.1).setY(0.4));
                return false;
            }, null);
            return 160;
        });

        add("full_matter_lance", "Matter Lance Volley", "Forge five spectral lances overhead and hurl them.", 18, 9, s -> {
            List<LivingEntity> tg = Abilities.targets(s, 35, 3);
            LivingEntity lt = s.lockTarget();
            double dmg = Abilities.d(s, "full_matter_lance", 7);
            ItemDisplay[] props = new ItemDisplay[5];
            for (int i = 0; i < 5; i++) {
                double a = -1.2 + i * 0.6;
                props[i] = Abilities.prop(s, s.p.getLocation().add(Math.cos(a) * 1.3, 2.7, Math.sin(a) * 1.3), Material.NETHERITE_SWORD, 7350, 1.2f);
                Fx.spark(s.p.getLocation().add(Math.cos(a) * 1.3, 2.7, Math.sin(a) * 1.3), 6, 0.2);
            }
            {
                s.every(3, 15, t -> {
                    int idx = t / 3;
                    ItemDisplay pr = props[idx];
                    if (pr == null) return false;
                    LivingEntity tgt = lt != null ? lt : tg.isEmpty() ? null : tg.get(idx % tg.size());
                    Location from = pr.getLocation();
                    Vector dir = tgt != null ? tgt.getLocation().add(0, 1, 0).toVector().subtract(from.toVector()) : Abilities.aim(s, 35).toVector().subtract(from.toVector());
                    Fx.sound(from, Sound.ITEM_TRIDENT_THROW, 1f, 0.8f);
                    Abilities.homing(s, from, dir, tgt, 1.5, dmg, 1.6, 50, l -> pr.teleport(l), () -> Abilities.drop(s, pr));
                    return false;
                }, null);
            }
            return 200;
        });

        add("full_counterpulse", "Counterpulse", "3s: soak 30% of damage into stored resonance, then release it.", 10, 4, s -> {
            Abilities.counter(s, 60, 1.2, 7, 40);
            return 300;
        });

        add("full_sovereign_verdict", "Sovereign Verdict", "Finisher: three orbital strikes on one target; bonus on the wounded.", 55, 25, s -> {
            LivingEntity t = Scythe.sight(s, 30);
            if (t == null) return -1;
            @SuppressWarnings("deprecation") double missing = Math.min(30, (t.getMaxHealth() - t.getHealth()) * 0.4);
            double each = (Abilities.d(s, "full_sovereign_verdict", 22) + missing) / 3;
            Fx.sound(t.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1.2f, 2f);
            s.every(5, 15, k -> {
                if (!s.valid(t)) return true;
                Location c = t.getLocation();
                Fx.ring(c.clone().add(0, 0.1, 0), 2.2, 24, Fx.WHITE);
                for (double y = 0; y < 25; y += 0.4) Fx.dust(c.clone().add(0, y, 0), y % 1.2 < 0.4 ? Fx.WHITE : Fx.PURPLE, 3, 0.3);
                Fx.burst(c.clone().add(0, 1, 0), 2.5);
                Fx.sound(c, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1.6f);
                s.hit(t, each, new Vector(0, 0.5, 0));
                return false;
            }, null);
            return 420;
        });
    }
}
