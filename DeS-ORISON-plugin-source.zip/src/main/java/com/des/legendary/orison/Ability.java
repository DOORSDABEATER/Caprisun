package com.des.legendary.orison;

/** One registered ability. cast returns the cooldown in ticks, or -1 to cancel (energy refunded, no cooldown). */
public record Ability(String id, String name, String desc, int cost, int heat, Cast cast) {
    @FunctionalInterface public interface Cast { int run(Session s); }
}
