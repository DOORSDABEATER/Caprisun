package com.des.legendary.orison;

import org.bukkit.Input;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;

/**
 * Controlled flight: velocity-driven with acceleration curve, braking, hover, strafing, vertical thrust, landing,
 * energy drain and fall protection. Requires Paper 1.21.3+ for Player#getCurrentInput().
 * Gravity is restored on stop / death / quit / disable; a PDC tag lets the join handler repair a crash mid-flight.
 * Keys: W/S/A/D move along look/strafe, Space ascend, Shift descend (and land), Sprint boost (if the form allows).
 */
final class Flight {
    private final Session s;
    boolean on;
    private final NamespacedKey tag;

    Flight(Session s) { this.s = s; tag = new NamespacedKey(s.m.plugin, "orison_flying"); }

    void toggle() { if (on) stop(); else start(); }

    void start() {
        if (on || !s.form.flight || !s.armour.ready) { s.p.sendActionBar(net.kyori.adventure.text.Component.text("Flight needs a deployed armour form")); return; }
        if (s.energy < 5 || s.overloaded) return;
        on = true;
        s.p.setGravity(false);
        s.p.getPersistentDataContainer().set(tag, PersistentDataType.BYTE, (byte) 1);
        s.p.setVelocity(new Vector(0, 0.6, 0));
        Fx.sound(s.p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 1f, 0.7f);
        s.every(1, 1_000_000, this::step, this::cleanup);
    }

    void stop() { on = false; }

    void cleanup() {
        boolean was = on || !s.p.hasGravity();
        on = false;
        if (was && s.p.isOnline()) {
            s.p.setGravity(true);
            s.p.getPersistentDataContainer().remove(tag);
            s.fallGuardUntil = s.now() + 60;
        }
    }

    private boolean step(int t) {
        Player p = s.p;
        if (!on || !s.form.flight || !s.armour.ready) return true;
        if (s.energy <= 0.5) { s.m.voice.say(s, "lowenergy"); p.sendActionBar(net.kyori.adventure.text.Component.text("Flight instability — reserves depleted")); return true; }
        String f = s.form.name().toLowerCase();
        double max = s.m.cfg.getDouble("flight." + f + ".max-speed", 0.32);
        double accel = s.m.cfg.getDouble("flight." + f + ".acceleration", 0.12);
        double brake = s.m.cfg.getDouble("flight." + f + ".braking", 0.22);
        double boost = s.m.cfg.getDouble("flight." + f + ".boost-multiplier", 1.0);
        if (s.od()) { max *= 1.25; boost *= 1.1; }
        Input in = p.getCurrentInput();
        Vector look = p.getEyeLocation().getDirection(), flat = Abilities.flat(look);
        Vector right = new Vector(-flat.getZ(), 0, flat.getX());
        Vector want = new Vector();
        if (in.isForward()) want.add(look);
        if (in.isBackward()) want.subtract(look);
        if (in.isRight()) want.add(right);
        if (in.isLeft()) want.subtract(right);
        if (in.isJump()) want.add(new Vector(0, 1, 0));
        if (in.isSneak()) want.subtract(new Vector(0, 1, 0));
        boolean boosting = in.isSprint() && boost > 1.0 && s.energy > 10;
        double rate = accel;
        if (want.lengthSquared() > 1e-4) want.normalize().multiply(max * (boosting ? boost : 1));
        else rate = brake;
        Vector v = p.getVelocity();
        Vector nv = v.clone().add(want.subtract(v).multiply(rate));
        double cap = max * (boosting ? boost : 1) * 1.1;
        if (nv.length() > cap) nv.normalize().multiply(cap);
        p.setVelocity(nv);
        s.energy = Math.max(0, s.energy - (boosting ? 0.12 : 0.02));
        s.fallGuardUntil = s.now() + 40;
        if (t > 10 && p.isOnGround() && in.isSneak()) return true; // precision landing
        // thrusters: boots + back
        double sp = nv.length();
        org.bukkit.Location l = p.getLocation();
        Fx.dust(l.clone().add(0, 0.1, 0), Fx.PURPLE, 2, 0.1);
        Fx.dust(l.clone().add(0, 0.1, 0), Fx.WHITE, 1, 0.05);
        if (sp > 0.05) Fx.dust(l.clone().add(0, 1.2, 0).subtract(flat.clone().multiply(0.4)), Fx.PURPLE, 2, 0.12);
        if (boosting) Fx.spark(l.clone().add(0, 1, 0).subtract(nv.clone().normalize().multiply(0.8)), 2, 0.1);
        if (t % 20 == 0) Fx.sound(l, Sound.BLOCK_BEACON_AMBIENT, 0.3f, 1.8f);
        return false;
    }
}
