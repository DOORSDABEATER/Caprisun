package com.des.legendary.orison;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.function.Consumer;

/** Core State roster (exactly 8) + Core ultimate + shared combat helpers. */
final class Abilities {
    static final List<Ability> CORE = new ArrayList<>();

    static double d(Session s, String id, double def) { return s.m.cfg.getDouble("abilities." + id + ".damage", def); }
    static Vector flat(Vector v) {
        Vector f = v.clone().setY(0);
        return f.lengthSquared() < 1e-4 ? new Vector(0, 0, 1) : f.normalize();
    }

    /** Server-side projectile: stepped, block + entity checked, bounded lifetime. */
    static void shoot(Session s, Location from, Vector dir, double speed, double range, double radius, double dmg,
                      boolean pierce, Consumer<Location> trail, Consumer<Location> impact) {
        shoot(s, from, dir, speed, range, radius, dmg, pierce, trail, impact, null);
    }
    static void shoot(Session s, Location from, Vector dir, double speed, double range, double radius, double dmg,
                      boolean pierce, Consumer<Location> trail, Consumer<Location> impact, Runnable onEnd) {
        Location pos = from.clone();
        Vector step = dir.clone().normalize().multiply(speed * 0.5);
        Vector kb = dir.clone().normalize().multiply(0.45).setY(0.15);
        Set<UUID> hit = new HashSet<>();
        double[] travelled = {0};
        s.every(1, 120, t -> {
            for (int i = 0; i < 2; i++) {
                pos.add(step);
                travelled[0] += speed * 0.5;
                trail.accept(pos);
                if (!pos.getBlock().isPassable()) { impact.accept(pos); return true; }
                for (LivingEntity e : pos.getWorld().getNearbyLivingEntities(pos, radius)) {
                    if (s.valid(e) && hit.add(e.getUniqueId())) {
                        s.hit(e, dmg, kb);
                        impact.accept(pos);
                        if (!pierce) return true;
                    }
                }
                if (travelled[0] >= range) return true;
            }
            return false;
        }, onEnd);
    }

    static List<LivingEntity> radius(Session s, Location c, double r) {
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : c.getWorld().getNearbyLivingEntities(c, r)) if (s.valid(e)) out.add(e);
        return out;
    }

    static Location aim(Session s, double range) {
        Location eye = s.p.getEyeLocation();
        RayTraceResult r = eye.getWorld().rayTraceBlocks(eye, eye.getDirection(), range, FluidCollisionMode.NEVER, true);
        return r != null ? r.getHitPosition().toLocation(eye.getWorld()) : eye.clone().add(eye.getDirection().multiply(range));
    }

    static List<Ability> forForm(Form f) {
        return switch (f) { case CORE -> CORE; case HALF -> Half.ROSTER; case FULL -> Full.ROSTER; case MAX -> MaxForm.ROSTER; };
    }

    /** Up to n valid mobs/players, nearest first. */
    static List<LivingEntity> targets(Session s, double range, int n) {
        List<LivingEntity> l = new ArrayList<>();
        for (LivingEntity e : radius(s, s.p.getLocation(), range)) if (e instanceof Mob || e instanceof Player) l.add(e);
        Location c = s.p.getLocation();
        l.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(c)));
        return l.size() > n ? new ArrayList<>(l.subList(0, n)) : l;
    }

    /** Instant piercing beam; damages each entity once per call (dmg <= 0 = visual only). Returns end point. */
    static Location beam(Session s, Location from, Vector dir, double len, double width, double dmg, boolean pierceBlocks) {
        Vector d = dir.clone().normalize();
        Location cur = from.clone();
        Set<UUID> hit = new HashSet<>();
        double l = 0;
        for (; l < len; l += 0.6) {
            cur.add(d.clone().multiply(0.6));
            if (!pierceBlocks && !cur.getBlock().isPassable()) break;
            if (dmg > 0) for (LivingEntity e : cur.getWorld().getNearbyLivingEntities(cur, width))
                if (s.valid(e) && hit.add(e.getUniqueId())) s.hit(e, dmg, d.clone().multiply(0.6).setY(0.2));
        }
        Fx.helix(from, d, l, Math.min(0.5, width * 0.4));
        Fx.line(from, cur, 0.5, Fx.WHITE);
        return cur;
    }

    /** Temporary display prop (spectral weapon etc). Tracked on the session so it can never leak. */
    static ItemDisplay prop(Session s, Location at, Material m, int cmd, float scale) {
        if (s.temp.size() >= s.m.cfg.getInt("limits.max-props-per-player", 40)) return null;
        ItemStack it = new ItemStack(m);
        ItemMeta mt = it.getItemMeta();
        mt.setCustomModelData(cmd);
        it.setItemMeta(mt);
        ItemDisplay d = at.getWorld().spawn(at, ItemDisplay.class, x -> {
            x.setItemStack(it); x.setPersistent(false); x.setTeleportDuration(1);
            x.setBrightness(new Display.Brightness(15, 15));
            x.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(scale, scale, scale), new AxisAngle4f()));
        });
        s.temp.add(d);
        return d;
    }
    static void drop(Session s, Entity e) { if (e != null) { e.remove(); s.temp.remove(e); } }

    /** COUNTERPULSE: absorbs part of incoming damage for `window` ticks, then releases it as a shockwave. */
    static void counter(Session s, int window, double mult, double radius, double cap) {
        s.counterUntil = s.now() + window;
        s.counterStored = 0;
        Fx.sound(s.p.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 1f, 1.2f);
        s.every(2, window, t -> {
            Location c = s.p.getLocation().add(0, 1, 0);
            Fx.ring(c, 0.8 + Math.min(1.2, s.counterStored * 0.05), 18, Fx.DEEP);
            Fx.dust(c, Fx.PURPLE, 2, 0.4);
            return false;
        }, () -> {
            double dmg = Math.min(cap, s.counterStored * mult);
            s.counterUntil = 0;
            Location c = s.p.getLocation().add(0, 0.5, 0);
            Fx.sound(c, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.3f);
            for (int k = 0; k < 3; k++) { Fx.ring(c.clone().add(0, k * 0.5, 0), radius * (0.5 + k * 0.25), (int) (radius * 12), k == 1 ? Fx.WHITE : Fx.PURPLE); }
            if (dmg < 1) return;
            for (LivingEntity e : radius(s, c, radius)) s.hit(e, dmg, e.getLocation().toVector().subtract(c.toVector()).setY(0).normalize().multiply(1.3).setY(0.4));
        });
    }

    static Vector flatDirOrLook(Session s) { return s.p.getEyeLocation().getDirection(); }

    /** Nearest threat: mobs targeting the player first, then any hostile, within range. */
    static LivingEntity nearest(Session s, double range) {
        LivingEntity best = null; double bd = 1e18;
        for (LivingEntity e : s.p.getWorld().getNearbyLivingEntities(s.p.getLocation(), range)) {
            if (!s.valid(e) || !(e instanceof Mob m)) continue;
            double d = e.getLocation().distanceSquared(s.p.getLocation()) - (s.p.equals(m.getTarget()) ? 400 : e instanceof Monster ? 0 : 900);
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    /** Server-side homing missile: steers toward target, detonates on block/entity/timeout. No block damage. */
    static void homing(Session s, Location from, Vector initial, LivingEntity tgt, double speed, double dmg, double blast, int life) {
        homing(s, from, initial, tgt, speed, dmg, blast, life, null, null);
    }
    static void homing(Session s, Location from, Vector initial, LivingEntity tgt, double speed, double dmg, double blast, int life,
                       Consumer<Location> onMove, Runnable onEnd) {
        Location pos = from.clone();
        Vector vel = initial.clone().normalize().multiply(speed);
        boolean[] done = {false};
        Runnable boom = () -> {
            if (done[0]) return; done[0] = true;
            Fx.burst(pos, blast);
            Fx.sound(pos, Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 1.5f);
            for (LivingEntity e : radius(s, pos, blast)) s.hit(e, dmg, e.getLocation().toVector().subtract(pos.toVector()).normalize().multiply(0.5).setY(0.25));
        };
        s.every(1, life, t -> {
            Vector want = tgt != null && s.valid(tgt) ? tgt.getLocation().add(0, tgt.getHeight() / 2, 0).toVector().subtract(pos.toVector()) : vel.clone();
            if (want.lengthSquared() > 1e-4) vel.add(want.normalize().multiply(speed).subtract(vel).multiply(t < 4 ? 0.05 : 0.3));
            if (vel.length() > speed) vel.normalize().multiply(speed);
            pos.add(vel);
            if (onMove != null) onMove.accept(pos);
            Fx.dust(pos, Fx.WHITE, 1, 0); Fx.dust(pos, Fx.PURPLE, 2, 0.08);
            if (!pos.getBlock().isPassable()) { boom.run(); return true; }
            for (LivingEntity e : pos.getWorld().getNearbyLivingEntities(pos, 1.0)) if (s.valid(e)) { boom.run(); return true; }
            return false;
        }, () -> { boom.run(); if (onEnd != null) onEnd.run(); });
    }

    private static void add(String id, String name, String desc, int cost, int heat, Ability.Cast c) {
        CORE.add(new Ability(id, name, desc, cost, heat, c));
    }

    static {
        add("resonance_bolt", "Resonance Bolt", "Fast precise violet bolt.", 4, 2, s -> {
            Location e = s.p.getEyeLocation();
            Fx.sound(e, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1f, 1.6f);
            shoot(s, e.clone().add(e.getDirection().multiply(0.8)), e.getDirection(), 1.6, 32, 0.9, d(s, "resonance_bolt", 6), false,
                    l -> { Fx.dust(l, Fx.PURPLE, 3, 0.05); Fx.dust(l, Fx.WHITE, 1, 0); }, l -> Fx.burst(l, 1.2));
            return 8;
        });

        add("pulse_ring", "Pulse Ring", "Expanding shockwave that hurls enemies outward.", 12, 6, s -> {
            Location c = s.p.getLocation().add(0, 1, 0);
            double dmg = d(s, "pulse_ring", 5);
            Set<UUID> hit = new HashSet<>();
            Fx.sound(c, Sound.ENTITY_WARDEN_SONIC_CHARGE, 0.7f, 1.8f);
            s.every(1, 9, t -> {
                double r = 1 + t * 0.65;
                Fx.ring(c, r, Math.max(24, (int) (r * 10)), Fx.PURPLE);
                Fx.ring(c.clone().add(0, 0.3, 0), r - 0.3, Math.max(20, (int) (r * 8)), Fx.WHITE);
                for (LivingEntity e : radius(s, c, r + 0.7))
                    if (e.getLocation().distance(c) >= r - 1.3 && hit.add(e.getUniqueId()))
                        s.hit(e, dmg, e.getLocation().toVector().subtract(c.toVector()).setY(0).normalize().multiply(0.9).setY(0.35));
                return false;
            }, null);
            return 100;
        });

        add("harmonic_lance", "Harmonic Lance", "Piercing helical beam. Heavy single-line damage.", 20, 14, s -> {
            Location eye = s.p.getEyeLocation();
            Vector dir = eye.getDirection();
            double dmg = d(s, "harmonic_lance", 11);
            Set<UUID> hit = new HashSet<>();
            Location cur = eye.clone();
            double len = 0;
            for (; len < 24; len += 0.5) {
                cur.add(dir.clone().multiply(0.5));
                if (!cur.getBlock().isPassable()) break;
                for (LivingEntity e : cur.getWorld().getNearbyLivingEntities(cur, 0.8))
                    if (s.valid(e) && hit.add(e.getUniqueId())) s.hit(e, dmg, dir.clone().multiply(0.8).setY(0.2));
            }
            Fx.helix(eye.clone().add(dir.clone().multiply(0.8)), dir, len, 0.35);
            Fx.burst(cur, 1.6);
            Fx.sound(eye, Sound.ENTITY_ILLUSIONER_CAST_SPELL, 1f, 0.6f);
            return 160;
        });

        add("phase_step", "Phase Step", "Resonant dash. Brief afterimage trail.", 10, 4, s -> {
            Vector v = flat(s.p.getLocation().getDirection()).multiply(1.9).setY(0.2);
            Location a = s.p.getLocation().add(0, 1, 0);
            Fx.dust(a, Fx.PURPLE, 25, 0.4);
            Fx.sound(a, Sound.ENTITY_ENDERMAN_TELEPORT, 0.6f, 1.7f);
            s.p.setVelocity(v);
            s.every(1, 6, t -> { Fx.dust(s.p.getLocation().add(0, 1, 0), Fx.PURPLE, 6, 0.3); return false; }, null);
            return 60;
        });

        add("resonance_shield", "Resonance Shield", "Directional barrier. Deletes up to 8 projectiles.", 18, 5, s -> {
            int[] left = {8};
            Fx.sound(s.p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.8f, 1.8f);
            s.every(1, 60, t -> {
                Location eye = s.p.getEyeLocation();
                Vector f = eye.getDirection();
                Location c = eye.clone().add(f.clone().multiply(2.2));
                Vector u = f.clone().crossProduct(new Vector(0, 1, 0));
                if (u.lengthSquared() < 1e-4) u = new Vector(1, 0, 0);
                u.normalize();
                Vector v = f.clone().crossProduct(u).normalize();
                for (int i = 0; i < 24; i++) {
                    double a = i * Math.PI * 2 / 24;
                    Fx.dust(c.clone().add(u.clone().multiply(Math.cos(a) * 1.9)).add(v.clone().multiply(Math.sin(a) * 1.9)), Fx.PURPLE, 1, 0);
                }
                if (t % 3 == 0) Fx.dust(c, Fx.WHITE, 4, 1.3);
                for (Projectile pr : c.getWorld().getNearbyEntitiesByType(Projectile.class, c, 2.6)) {
                    if (pr.isDead() || s.p.equals(pr.getShooter())) continue;
                    pr.remove();
                    Fx.spark(pr.getLocation(), 10, 0.2);
                    s.gain(3);
                    if (--left[0] <= 0) { Fx.burst(c, 2); return true; }
                }
                for (LivingEntity e : radius(s, c, 1.7))
                    e.setVelocity(e.getVelocity().add(f.clone().multiply(0.25).setY(0.05)));
                return false;
            }, null);
            return 240;
        });

        add("kinetic_absorb", "Kinetic Absorption", "4s: halve eligible damage and convert it to resonance.", 0, 0, s -> {
            s.absorbUntil = s.now() + 80;
            Fx.sound(s.p.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_CHARGE, 0.8f, 1.5f);
            s.every(2, 80, t -> {
                Fx.ring(s.p.getLocation().add(0, 0.2 + (t % 40) * 0.045, 0), 0.9, 14, Fx.DEEP);
                Fx.dust(s.p.getLocation().add(0, 1, 0), Fx.PURPLE, 2, 0.5);
                return false;
            }, null);
            return 300;
        });

        add("matter_snare", "Matter Snare", "Gravity well pulls enemies in, then collapses.", 15, 8, s -> {
            Location c = aim(s, 18);
            double dmg = d(s, "matter_snare", 5);
            Fx.sound(c, Sound.ENTITY_ENDER_EYE_DEATH, 1f, 0.6f);
            s.every(2, 40, t -> {
                Fx.ring(c.clone().add(0, 0.2, 0), 4.5 - t * 0.08, 28, Fx.PURPLE);
                Fx.dust(c.clone().add(0, 1, 0), Fx.DEEP, 6, 0.6);
                for (LivingEntity e : radius(s, c, 5.5)) {
                    Vector pull = c.toVector().subtract(e.getLocation().toVector()).normalize().multiply(0.35);
                    if (!Session.boss(e)) e.setVelocity(e.getVelocity().multiply(0.5).add(pull));
                    e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 30, 1, true, false));
                }
                return false;
            }, () -> {
                Fx.burst(c.clone().add(0, 0.5, 0), 4);
                for (LivingEntity e : radius(s, c, 4)) s.hit(e, dmg, null);
            });
            return 200;
        });

        add("discord_spike", "Discord Spike", "Chain of violet eruptions racing forward.", 40, 25, s -> {
            Vector f = flat(s.p.getLocation().getDirection());
            Location o = s.p.getLocation();
            double dmg = d(s, "discord_spike", 9);
            Fx.sound(o, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.7f, 1.4f);
            s.every(3, 24, t -> {
                Location c = o.clone().add(f.clone().multiply(2.5 + t * 0.9));
                c.setY(o.getY());
                for (double y = 0; y < 3; y += 0.3) Fx.dust(c.clone().add(0, y, 0), y > 2 ? Fx.WHITE : Fx.PURPLE, 3, 0.25);
                Fx.ring(c, 1.8, 20, Fx.DEEP);
                for (LivingEntity e : radius(s, c, 2)) s.hit(e, dmg, new Vector(0, 0.8, 0));
                return false;
            }, null);
            return 240;
        });
    }

    /** CORE ULTIMATE — CHORUS COLLAPSE. Fragments become six anchors; rings converge on the core; one detonation. Player stays mobile. */
    static void chorusCollapse(Session s) {
        Location c = s.p.getLocation().clone();
        double dmg = s.m.cfg.getDouble("ultimates.core.damage", 34), rad = s.m.cfg.getDouble("ultimates.core.radius", 12);
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI * 2 / 6;
            s.fragments.override[i] = c.clone().add(Math.cos(a) * 6, 2.5, Math.sin(a) * 6);
        }
        Fx.sound(c, Sound.BLOCK_BEACON_POWER_SELECT, 1.5f, 0.5f);
        s.every(2, 50, t -> {
            Location core = s.p.getLocation().add(0, 1.3, 0);
            for (int i = 0; i < 6; i++) {
                Location a = s.fragments.override[i];
                Fx.line(a, core, 0.45, i % 2 == 0 ? Fx.PURPLE : Fx.WHITE);
                Fx.ring(a, 0.5 + t * 0.01, 10, Fx.PURPLE);
            }
            for (int k = 0; k < 3; k++) Fx.ring(core.clone().add(0, (k - 1) * 0.35, 0), 0.6 + k * 0.3 + Math.sin(t * 0.3) * 0.2, 16, k == 1 ? Fx.WHITE : Fx.PURPLE);
            if (t % 10 == 0) Fx.sound(core, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1.2f, 0.6f + t * 0.025f);
            return false;
        }, () -> {
            Location d = s.p.getLocation().add(0, 0.2, 0);
            Fx.sound(d, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.6f);
            Fx.sound(d, Sound.BLOCK_END_PORTAL_SPAWN, 0.8f, 1.6f);
            for (LivingEntity e : radius(s, d, rad)) {
                double dist = e.getLocation().distance(d);
                s.hit(e, Math.max(8, dmg * (1 - dist / (rad + 4))), e.getLocation().toVector().subtract(d.toVector()).setY(0).normalize().multiply(1.6).setY(0.6));
            }
            s.every(1, 12, t -> {
                double r = 1 + t * (rad / 12.0);
                Fx.ring(d, r, (int) (r * 14), Fx.PURPLE);
                Fx.ring(d.clone().add(0, 0.5, 0), r * 0.8, (int) (r * 10), Fx.WHITE);
                Fx.ring(d.clone().add(0, 1.2, 0), r * 0.6, (int) (r * 8), Fx.DEEP);
                return false;
            }, () -> { for (int i = 0; i < 6; i++) s.fragments.override[i] = null; });
        });
    }

    /** Fails startup if any roster is not exactly the specified size. */
    static void validate(Forge forge) {
        if (CORE.size() != Form.CORE.abilityCount) throw new IllegalStateException("Core roster must be " + Form.CORE.abilityCount + " but is " + CORE.size());
        Set<String> ids = new HashSet<>();
        for (Ability a : CORE) if (!ids.add(a.id())) throw new IllegalStateException("Duplicate ability id " + a.id());
        if (Full.ROSTER.size() != Form.FULL.abilityCount) throw new IllegalStateException("Full roster must be " + Form.FULL.abilityCount + " but is " + Full.ROSTER.size());
        if (MaxForm.ROSTER.size() != Form.MAX.abilityCount) throw new IllegalStateException("MAX roster must be " + Form.MAX.abilityCount + " but is " + MaxForm.ROSTER.size());
        for (Ability a : Full.ROSTER) if (!ids.add(a.id())) throw new IllegalStateException("Duplicate ability id " + a.id());
        for (Ability a : MaxForm.ROSTER) if (!ids.add(a.id())) throw new IllegalStateException("Duplicate ability id " + a.id());
        if (Half.ROSTER.size() != Form.HALF.abilityCount) throw new IllegalStateException("Half roster must be " + Form.HALF.abilityCount + " but is " + Half.ROSTER.size());
        for (Ability a : Half.ROSTER) if (!ids.add(a.id())) throw new IllegalStateException("Duplicate ability id " + a.id());
        for (Forge.Blueprint b : forge.catalogue.values()) {
            if (b.moveset().size() != 8) throw new IllegalStateException(b.id() + " must have exactly 8 abilities");
            for (Ability a : b.moveset()) if (!ids.add(a.id())) throw new IllegalStateException("Duplicate ability id " + a.id());
        }
    }
}
