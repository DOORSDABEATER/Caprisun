package com.des.legendary.orison;

/** The four ORISON operating architectures. Ability counts are enforced at startup. */
public enum Form {
    CORE("Core State", 8, true, false),
    HALF("Half Transformation", 10, true, true),
    FULL("Full Transformation", 12, true, true),
    MAX("MAX Transformation", 16, true, true);

    public final String display;
    public final int abilityCount;
    /** false = roster/armour not built yet; transform is refused instead of faked. */
    public final boolean implemented;
    public final boolean flight;

    Form(String d, int c, boolean i, boolean f) { display = d; abilityCount = c; implemented = i; flight = f; }
}
