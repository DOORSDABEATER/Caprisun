package com.des.legendary.orison;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Projectile;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;

/** HALF TRANSFORMATION — Tactical Configuration. Exactly 10 abilities + ultimate TACTICAL DOMINION. */
final class Half {
    static final List<Ability> ROSTER = new ArrayList<>();
    private static void add(String id, String name, String desc, int cost, int heat, Ability.Cast c) { ROSTER.add(new Ability(id, name, desc, cost, heat, c)); }

    /** Where shoulder/precision weapons aim: the lock, else the crosshair. */
    static Location aimPoint(Session s) {
        LivingEntity t = s.lockTarget();
        return t != null ? t.getLocation().add(0, t.getHeight() / 2, 0) : Abilities.aim(s, 40);
    }
    private static boolean marked(Session s, LivingEntity t) {
        return (s.lockTarget() == t) || (s.now() < s.scanUntil && s.scanned.contains(t.getUniqueId()));
    }

    static {
        add("half_analysis_scan", "Analysis Scan", "28-block sweep: outlines and tags up to 16 threats.", 6, 2, s -> {
            Location c = s.p.getLocation();
            s.scanned.clear();
            s.scanUntil = s.now() + 160;
            Fx.sound(c, Sound.BLOCK_BEACON_POWER_SELECT, 0.8f, 2f);
            s.every(1, 10, t -> { Fx.ring(c.clone().add(0, 1, 0), 2 + t * 2.8, 40, Fx.WHITE); Fx.ring(c.clone().add(0, 1.1, 0), 1.6 + t * 2.8, 40, Fx.PURPLE); return false; }, null);
            int n = 0;
            for (LivingEntity e : Abilities.radius(s, c, 28)) {
                if (!(e instanceof org.bukkit.entity.Mob) && !(e instanceof org.bukkit.entity.Player)) continue;
                if (n++ >= 16) break;
                s.scanned.add(e.getUniqueId());
                e.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 80, 0, true, false));
            }
            s.p.sendActionBar(net.kyori.adventure.text.Component.text("Scan complete: " + s.scanned.size() + " signatures"));
            return 100;
        });

        add("half_target_lock", "Target Lock", "10s lock on the entity you look at. Shoulder systems follow it.", 4, 1, s -> {
            LivingEntity t = Scythe.sight(s, 40);
            if (t == null) return -1;
            s.lock = t.getUniqueId();
            s.lockUntil = s.now() + 200;
            Fx.sound(t.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, 2f);
            s.every(4, 200, k -> {
                if (s.lockTarget() != t) return true;
                Location l = t.getLocation().add(0, t.getHeight() / 2, 0);
                Fx.ring(l, 0.9, 16, Fx.WHITE); Fx.ring(l, 1.2, 20, Fx.PURPLE);
                return false;
            }, null);
            return 20;
        });

        add("half_precision_shot", "Precision Shot", "Gauntlet beam. +50% damage on locked or scanned targets.", 12, 6, s -> {
            Location from = Armour.gauntlet(s, true), eye = s.p.getEyeLocation();
            RayTraceResult r = eye.getWorld().rayTrace(eye, eye.getDirection(), 40, org.bukkit.FluidCollisionMode.NEVER, true, 0.4, e -> e instanceof LivingEntity le && s.valid(le));
            Location end = r != null ? r.getHitPosition().toLocation(eye.getWorld()) : eye.clone().add(eye.getDirection().multiply(40));
            Fx.line(from, end, 0.3, Fx.PURPLE);
            Fx.line(from.clone().add(0, 0.05, 0), end, 0.6, Fx.WHITE);
            Fx.burst(end, 1.2);
            Fx.sound(from, Sound.ENTITY_BLAZE_SHOOT, 1f, 0.5f);
            if (r != null && r.getHitEntity() instanceof LivingEntity t) {
                double d = Abilities.d(s, "half_precision_shot", 9) * (marked(s, t) ? 1.5 : 1.0);
                s.hit(t, d, end.toVector().subtract(from.toVector()).normalize().multiply(0.5).setY(0.15));
            }
            return 50;
        });

        add("half_shoulder_shot", "Shoulder Shot", "Both shoulder shooters fire at the lock or crosshair.", 8, 3, s -> {
            double dmg = Abilities.d(s, "half_shoulder_shot", 4);
            for (int i = 0; i < 2; i++) {
                final boolean right = i == 1;
                s.every(3, 4, t -> {
                    Location from = Armour.shoulder(s, right);
                    Vector dir = aimPoint(s).toVector().subtract(from.toVector());
                    Fx.sound(from, Sound.ENTITY_SHULKER_SHOOT, 0.7f, 1.6f);
                    Abilities.shoot(s, from, dir, 1.7, 32, 0.8, dmg, false, l -> Fx.dust(l, Fx.PURPLE, 2, 0.03), l -> Fx.burst(l, 0.9));
                    return true;
                }, null);
            }
            return 40;
        });

        add("half_tracking_missiles", "Tracking Missiles", "Four homing missiles launch from the shoulders.", 22, 10, s -> {
            LivingEntity tgt = s.lockTarget() != null ? s.lockTarget() : Abilities.nearest(s, 30);
            double dmg = Abilities.d(s, "half_tracking_missiles", 5);
            int[] n = {0};
            s.every(4, 16, t -> {
                boolean right = n[0]++ % 2 == 0;
                Location from = Armour.shoulder(s, right);
                Vector up = new Vector(right ? 0.4 : -0.4, 0.9, 0);
                Fx.sound(from, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.8f, 0.9f);
                Abilities.homing(s, from, s.p.getEyeLocation().getDirection().add(up).normalize(), tgt, 0.9, dmg, 2.2, 60);
                return false;
            }, null);
            return 160;
        });

        add("half_interceptor_grid", "Interceptor Grid", "4s: shoulders destroy hostile projectiles within 6 blocks (max 12).", 16, 5, s -> {
            int[] left = {12};
            Fx.sound(s.p.getLocation(), Sound.BLOCK_CONDUIT_ACTIVATE, 0.8f, 1.6f);
            s.every(2, 80, t -> {
                Location c = s.p.getLocation().add(0, 1, 0);
                Fx.ring(c, 0.9 + (t % 20) * 0.02, 16, Fx.DEEP);
                for (Projectile pr : c.getWorld().getNearbyEntitiesByType(Projectile.class, c, 6)) {
                    if (pr.isDead() || s.p.equals(pr.getShooter()) || pr.isOnGround()) continue;
                    Fx.line(Armour.shoulder(s, pr.getLocation().getX() > c.getX()), pr.getLocation(), 0.4, Fx.WHITE);
                    Fx.spark(pr.getLocation(), 8, 0.2);
                    pr.remove(); s.gain(3);
                    s.m.voice.say(s, "intercept");
                    if (--left[0] <= 0) return true;
                }
                return false;
            }, null);
            return 240;
        });

        add("half_fragment_strike", "Fragment Strike", "LANCE, SENTRY and PULSE detach and strike the lock or crosshair.", 20, 8, s -> {
            for (Location o : s.fragments.override) if (o != null) return -1;
            Location tgt = aimPoint(s);
            double dmg = Abilities.d(s, "half_fragment_strike", 5);
            int[] idx = {2, 3, 4};
            LivingEntity lt = s.lockTarget();
            Set<UUID> struck = new HashSet<>();
            s.every(2, 28, t -> {
                Location base = lt != null && s.valid(lt) ? lt.getLocation().add(0, lt.getHeight() / 2, 0) : tgt;
                for (int k = 0; k < 3; k++) {
                    double a = t * 0.3 + k * Math.PI * 2 / 3;
                    s.fragments.override[idx[k]] = base.clone().add(Math.cos(a) * 2.5, 1.5 - Math.min(t, 16) * 0.06, Math.sin(a) * 2.5);
                    if (t >= 16) Fx.line(s.fragments.override[idx[k]], base, 0.4, Fx.PURPLE);
                }
                if (t == 16) {
                    Fx.burst(base, 2.2);
                    for (LivingEntity e : Abilities.radius(s, base, 2.5)) if (struck.add(e.getUniqueId())) s.hit(e, dmg * 3, new Vector(0, 0.4, 0));
                }
                return false;
            }, () -> { for (int k : idx) s.fragments.override[k] = null; });
            return 200;
        });

        add("half_tactical_flight", "Tactical Flight", "Toggle slow, controlled flight. WASD, Space up, Shift down/land.", 0, 0, s -> {
            s.flight.toggle();
            return 20;
        });

        add("half_orbital_mark", "Orbital Mark", "Mark ground; after 1.2s a column of resonance strikes there.", 18, 9, s -> {
            Location c = Abilities.aim(s, 40);
            double dmg = Abilities.d(s, "half_orbital_mark", 12);
            Fx.sound(c, Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.5f);
            s.every(2, 24, t -> { Fx.ring(c.clone().add(0, 0.1, 0), 3 - t * 0.1, 28, Fx.WHITE); Fx.ring(c.clone().add(0, 0.1, 0), 3, 28, Fx.PURPLE); return false; }, () -> {
                for (double y = 0; y < 30; y += 0.4) Fx.dust(c.clone().add(0, y, 0), y % 1.2 < 0.4 ? Fx.WHITE : Fx.PURPLE, 4, 0.35);
                Fx.burst(c, 3.5);
                Fx.sound(c, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 1.8f);
                for (LivingEntity e : Abilities.radius(s, c, 3)) s.hit(e, dmg, new Vector(0, 0.9, 0));
            });
            return 180;
        });

        add("half_tactical_resonance", "Tactical Resonance", "Detonates every scanned threat in sequence, with chain splash.", 25, 12, s -> {
            if (s.now() >= s.scanUntil || s.scanned.isEmpty()) { s.p.sendActionBar(net.kyori.adventure.text.Component.text("Run Analysis Scan first")); return -1; }
            List<UUID> list = new ArrayList<>(s.scanned);
            double dmg = Abilities.d(s, "half_tactical_resonance", 6);
            int[] i = {0};
            s.every(4, 4 * Math.min(8, list.size()), t -> {
                if (i[0] >= list.size()) return true;
                org.bukkit.entity.Entity ent = org.bukkit.Bukkit.getEntity(list.get(i[0]++));
                if (ent instanceof LivingEntity e && s.valid(e) && e.getLocation().distance(s.p.getLocation()) < 40) {
                    Location l = e.getLocation().add(0, 1, 0);
                    Fx.line(s.p.getLocation().add(0, 1.4, 0), l, 0.5, Fx.PURPLE);
                    Fx.burst(l, 2);
                    s.hit(e, dmg, new Vector(0, 0.3, 0));
                    for (LivingEntity o : Abilities.radius(s, l, 3)) if (o != e) s.hit(o, dmg * 0.5, null);
                }
                return false;
            }, null);
            return 260;
        });
    }

    /** HALF ULTIMATE — TACTICAL DOMINION: scans, locks up to 8 threats, 6 fragments + shoulders hammer each with homing strikes, then converge. */
    static void tacticalDominion(Session s) {
        Location c = s.p.getLocation();
        List<LivingEntity> targets = new ArrayList<>();
        for (LivingEntity e : Abilities.radius(s, c, 32)) if (e instanceof org.bukkit.entity.Mob || e instanceof org.bukkit.entity.Player) targets.add(e);
        targets.sort(Comparator.comparingDouble(e -> e.getLocation().distanceSquared(c)));
        if (targets.size() > 8) targets = new ArrayList<>(targets.subList(0, 8));
        final List<LivingEntity> tg = targets;
        double dmg = s.m.cfg.getDouble("ultimates.half.damage", 8), fin = s.m.cfg.getDouble("ultimates.half.final-damage", 14);
        Fx.sound(c, Sound.BLOCK_BEACON_POWER_SELECT, 1.5f, 1.4f);
        s.every(1, 12, t -> { Fx.ring(c.clone().add(0, 1, 0), 3 + t * 2.6, 48, Fx.WHITE); Fx.ring(c.clone().add(0, 1.2, 0), 2 + t * 2.6, 48, Fx.PURPLE); return false; }, null);
        for (LivingEntity e : tg) e.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 100, 0, true, false));
        int[] n = {0};
        s.every(4, 48, t -> {
            if (tg.isEmpty()) return true;
            for (int k = 0; k < Math.min(6, Math.max(tg.size(), 1)); k++) {
                LivingEntity e = tg.get((n[0] + k) % tg.size());
                if (!s.valid(e)) continue;
                Location from = k % 2 == 0 ? s.fragments.pos(k) : Armour.shoulder(s, k % 4 == 1);
                Abilities.homing(s, from, e.getLocation().add(0, 1, 0).toVector().subtract(from.toVector()).add(new Vector(0, 1.2, 0)), e, 1.0, dmg, 1.8, 50);
            }
            n[0]++;
            return false;
        }, () -> {
            for (LivingEntity e : tg) if (s.valid(e)) {
                Location l = e.getLocation().add(0, 1, 0);
                Fx.burst(l, 3);
                Fx.sound(l, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.2f);
                s.hit(e, fin, new Vector(0, 0.7, 0));
            }
        });
    }
}
