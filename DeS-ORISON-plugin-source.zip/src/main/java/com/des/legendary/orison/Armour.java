package com.des.legendary.orison;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.*;

/**
 * Piece-by-piece real-time armour assembly. Pieces are non-persistent ItemDisplays visible to everyone nearby
 * (so assembly is synchronised for observers). No equipment slot is touched: the core always stays in the chest
 * slot, so armour can never overwrite or duplicate it, and a crash can never leave armour protection active.
 * The player keeps full control throughout (no camera, no freeze).
 * Interrupted assemble/retract is handled with an epoch counter: the newest operation wins, old ones stop.
 */
final class Armour {
    record Piece(String name, int model, Vector off, float scale, int delay, boolean head, double spin) {
        Piece(String n, int m, Vector o, float sc, int d, boolean h) { this(n, m, o, sc, d, h, 0); }
    }

    /** HALF / tactical: boots+thrusters, partial chest, back plate, shoulder shooters, gauntlets, analysis visor LAST. */
    static final List<Piece> HALF = List.of(
        new Piece("thruster_boot_l", 7401, new Vector(-0.2, 0.15, 0), 0.7f, 0, false),
        new Piece("thruster_boot_r", 7402, new Vector(0.2, 0.15, 0), 0.7f, 0, false),
        new Piece("chest_plate", 7403, new Vector(0, 1.2, 0.18), 0.9f, 14, false),
        new Piece("back_plate", 7404, new Vector(0, 1.2, -0.25), 0.9f, 22, false),
        new Piece("shoulder_shooter_l", 7405, new Vector(-0.5, 1.55, -0.05), 0.7f, 30, false),
        new Piece("shoulder_shooter_r", 7406, new Vector(0.5, 1.55, -0.05), 0.7f, 30, false),
        new Piece("gauntlet_l", 7407, new Vector(-0.55, 0.95, 0.12), 0.7f, 38, false),
        new Piece("gauntlet_r", 7408, new Vector(0.55, 0.95, 0.12), 0.7f, 38, false),
        new Piece("analysis_visor", 7409, new Vector(0, 1.72, 0.12), 0.8f, 48, true));

    /** FULL / Sovereign Armour: complete exosuit. Faceplate closes LAST. */
    static final List<Piece> FULL = List.of(
        new Piece("boot_l", 7501, new Vector(-0.2, 0.15, 0), 0.8f, 0, false),
        new Piece("boot_r", 7502, new Vector(0.2, 0.15, 0), 0.8f, 0, false),
        new Piece("leg_l", 7503, new Vector(-0.18, 0.6, 0), 0.9f, 12, false),
        new Piece("leg_r", 7504, new Vector(0.18, 0.6, 0), 0.9f, 12, false),
        new Piece("chest", 7505, new Vector(0, 1.2, 0.18), 1.0f, 26, false),
        new Piece("back_architecture", 7506, new Vector(0, 1.25, -0.28), 1.0f, 34, false),
        new Piece("reactor_housing", 7507, new Vector(0, 1.3, 0.3), 0.6f, 42, false),
        new Piece("shoulder_l", 7508, new Vector(-0.52, 1.55, -0.02), 0.8f, 52, false),
        new Piece("shoulder_r", 7509, new Vector(0.52, 1.55, -0.02), 0.8f, 52, false),
        new Piece("gauntlet_l", 7510, new Vector(-0.55, 0.95, 0.12), 0.8f, 62, false),
        new Piece("gauntlet_r", 7511, new Vector(0.55, 0.95, 0.12), 0.8f, 62, false),
        new Piece("helmet", 7512, new Vector(0, 1.72, 0.0), 0.9f, 76, true),
        new Piece("faceplate", 7513, new Vector(0, 1.72, 0.14), 0.8f, 90, true));

    /** MAX / Ascendant Sovereign: different geometry — reinforced legs, expanded reactor, unfolding back array, oversized gauntlets, spine plates, three giant spinning rings. */
    static final List<Piece> MAX = List.of(
        new Piece("max_boot_l", 7601, new Vector(-0.22, 0.2, 0), 1.0f, 0, false),
        new Piece("max_boot_r", 7602, new Vector(0.22, 0.2, 0), 1.0f, 0, false),
        new Piece("max_leg_l", 7603, new Vector(-0.2, 0.65, 0), 1.1f, 8, false),
        new Piece("max_leg_r", 7604, new Vector(0.2, 0.65, 0), 1.1f, 8, false),
        new Piece("max_chest", 7605, new Vector(0, 1.25, 0.2), 1.2f, 20, false),
        new Piece("max_reactor", 7606, new Vector(0, 1.3, 0.38), 1.0f, 28, false),
        new Piece("max_array_l", 7607, new Vector(-0.9, 1.5, -0.45), 1.1f, 36, false),
        new Piece("max_array_r", 7608, new Vector(0.9, 1.5, -0.45), 1.1f, 40, false),
        new Piece("max_array_c", 7609, new Vector(0, 1.9, -0.6), 1.2f, 44, false),
        new Piece("max_shoulder_weapon_l", 7610, new Vector(-0.62, 1.65, -0.02), 1.0f, 52, false),
        new Piece("max_shoulder_weapon_r", 7611, new Vector(0.62, 1.65, -0.02), 1.0f, 52, false),
        new Piece("max_gauntlet_l", 7612, new Vector(-0.65, 0.95, 0.15), 1.1f, 62, false),
        new Piece("max_gauntlet_r", 7613, new Vector(0.65, 0.95, 0.15), 1.1f, 62, false),
        new Piece("max_spine_a", 7614, new Vector(0, 1.0, -0.35), 0.9f, 68, false),
        new Piece("max_spine_b", 7615, new Vector(0, 1.6, -0.35), 0.9f, 70, false),
        new Piece("max_helmet", 7616, new Vector(0, 1.75, 0.0), 1.0f, 78, true),
        new Piece("max_faceplate", 7617, new Vector(0, 1.75, 0.16), 0.9f, 88, true),
        new Piece("ring_generation", 7621, new Vector(0, 1.3, 0), 2.4f, 96, false, 5.0),
        new Piece("ring_harmonics", 7622, new Vector(0, 1.3, 0), 3.0f, 102, false, -3.0),
        new Piece("ring_discord", 7623, new Vector(0, 1.3, 0), 3.6f, 108, false, 8.0));

    static List<Piece> piecesFor(Form f) { return f == Form.HALF ? HALF : f == Form.FULL ? FULL : MAX; }

    private final Session s;
    List<Piece> pieces = List.of();
    List<ItemDisplay> disp = new ArrayList<>();
    boolean busy, ready;
    private int epoch;

    Armour(Session s) { this.s = s; }

    private Location anchor(Piece p) {
        Location l = s.p.getLocation();
        double yaw = Math.toRadians(l.getYaw());
        Vector fwd = new Vector(-Math.sin(yaw), 0, Math.cos(yaw)), right = new Vector(-Math.cos(yaw), 0, -Math.sin(yaw));
        Location out = l.clone().add(right.multiply(p.off().getX())).add(fwd.multiply(p.off().getZ())).add(0, p.off().getY(), 0);
        out.setYaw(p.spin() != 0 ? (float) (s.ticks * p.spin() * (s.od() ? 2 : 1)) : l.getYaw());
        out.setPitch(p.head() ? l.getPitch() : 0);
        return out;
    }

    private ItemDisplay spawn(Location at, Piece p) { return spawn(at, p, false); }

    private ItemDisplay spawn(Location at, Piece p, boolean grow) {
        float sc0 = grow && p.spin() != 0 ? p.scale() * 0.2f : p.scale();
        ItemStack it = new ItemStack(Material.NETHERITE_INGOT);
        ItemMeta meta = it.getItemMeta();
        meta.setCustomModelData(p.model());
        it.setItemMeta(meta);
        return at.getWorld().spawn(at, ItemDisplay.class, d -> {
            d.setItemStack(it);
            d.setPersistent(false);
            d.setTeleportDuration(2);
            d.setBrightness(new Display.Brightness(15, 15));
            d.setViewRange(1.5f);
            d.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(sc0, sc0, sc0), new AxisAngle4f()));
        });
    }

    private void grow(ItemDisplay d, float sc) {
        d.setInterpolationDelay(0);
        d.setInterpolationDuration(30);
        d.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(sc, sc, sc), new AxisAngle4f()));
    }

    private int maxDelay(List<Piece> ps) { int m = 0; for (Piece p : ps) m = Math.max(m, p.delay()); return m; }

    void assemble(List<Piece> ps, Form target, int dur) { assemble(ps, target, dur, null); }

    void assemble(List<Piece> ps, Form target, int dur, Runnable after) {
        remove();               // bumps epoch and clears old pieces first
        int my = ++epoch;
        pieces = ps; busy = true; ready = false;
        double f = dur / (double) (maxDelay(ps) + 20);
        int fl = Math.max(4, (int) (20 * f));
        int total = (int) ((maxDelay(ps) + 20) * f) + 2;
        List<ItemDisplay> ds = new ArrayList<>(Collections.nCopies(ps.size(), null));
        disp = ds;
        Location[] st = new Location[ps.size()];
        boolean[] locked = new boolean[ps.size()];
        Random r = new Random();
        Fx.sound(s.p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, 0.7f);
        s.every(1, total, t -> {
            if (epoch != my) return true;
            for (int i = 0; i < ps.size(); i++) {
                int start = (int) (ps.get(i).delay() * f);
                if (t < start) continue;
                if (ds.get(i) == null) {
                    Vector v = new Vector(r.nextDouble() - .5, r.nextDouble() * .8, r.nextDouble() - .5).normalize().multiply(4 + r.nextDouble() * 2);
                    st[i] = s.p.getLocation().add(0, 1, 0).add(v);
                    ds.set(i, spawn(st[i], ps.get(i), true));
                }
                double k = Math.min(1, (t - start) / (double) fl);
                k = 1 - Math.pow(1 - k, 3);
                Location tgt = anchor(ps.get(i)), cur = st[i].clone().add(tgt.clone().subtract(st[i]).toVector().multiply(k));
                cur.setYaw(tgt.getYaw() + (float) ((1 - k) * 540)); cur.setPitch(tgt.getPitch());
                ItemDisplay d = ds.get(i);
                if (d.isValid()) d.teleport(cur);
                Fx.dust(cur, Fx.PURPLE, 2, 0.08);
                if (k >= 1 && !locked[i]) {
                    locked[i] = true;
                    if (ps.get(i).spin() != 0 && ds.get(i).isValid()) grow(ds.get(i), ps.get(i).scale());
                    Fx.spark(tgt, 8, 0.15); Fx.ring(tgt, 0.4, 10, Fx.WHITE);
                    Fx.sound(tgt, Sound.BLOCK_IRON_TRAPDOOR_CLOSE, 0.8f, 1.4f);
                }
            }
            return false;
        }, () -> {
            if (epoch != my) return;
            for (int i = 0; i < ds.size(); i++) if (ds.get(i) == null || !ds.get(i).isValid()) ds.set(i, spawn(anchor(ps.get(i)), ps.get(i)));
            busy = false; ready = true; s.form = target;
            Fx.burst(s.p.getLocation().add(0, 1, 0), 1.8);
            Fx.sound(s.p.getLocation(), Sound.BLOCK_RESPAWN_ANCHOR_SET_SPAWN, 1f, 1.5f);
            s.m.voice.say(s, target == Form.MAX ? "max" : target == Form.FULL ? "full" : "half");
            if (after != null) after.run();
        });
    }

    /** Real-time reconfiguration: current pieces detach and scatter outward, then the new architecture assembles. */
    void transition(List<Piece> to, Form target, int dur) {
        int my = ++epoch;
        s.flight.stop();
        busy = true; ready = false;
        List<ItemDisplay> old = disp;
        Location[] from = new Location[old.size()], dest = new Location[old.size()];
        Random r = new Random();
        Fx.sound(s.p.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1f, 0.5f);
        s.every(1, 24, t -> {
            if (epoch != my) return true;
            for (int i = 0; i < old.size(); i++) {
                ItemDisplay d = old.get(i);
                if (d == null || !d.isValid()) continue;
                if (from[i] == null) {
                    from[i] = d.getLocation();
                    dest[i] = s.p.getLocation().add(0, 1, 0).add(new Vector(r.nextDouble() - .5, r.nextDouble() * .6, r.nextDouble() - .5).normalize().multiply(3.5));
                }
                double k = Math.min(1, t / 20.0);
                Location cur = from[i].clone().add(dest[i].clone().subtract(from[i]).toVector().multiply(k));
                cur.setYaw(cur.getYaw() + t * 30);
                d.teleport(cur);
                Fx.dust(cur, Fx.WHITE, 2, 0.1);
            }
            return false;
        }, () -> {
            if (epoch != my) return;
            for (ItemDisplay d : old) if (d != null && d.isValid()) { Fx.spark(d.getLocation(), 4, 0.2); d.remove(); }
            disp = new ArrayList<>(); pieces = List.of();
            assemble(to, target, dur, null);
        });
    }

    /** Pieces fly back to the core in reverse order and vanish. Form reverts to CORE immediately. */
    void retract(int dur) {
        int my = ++epoch;
        s.flight.stop();
        s.form = Form.CORE;
        busy = true; ready = false;
        List<ItemDisplay> ds = disp;
        List<Piece> ps = pieces;
        double f = dur / (double) (maxDelay(ps) + 14);
        int fl = Math.max(3, (int) (14 * f));
        int total = (int) ((maxDelay(ps) + 14) * f) + 2;
        Location[] from = new Location[ds.size()];
        boolean[] gone = new boolean[ds.size()];
        s.every(1, total, t -> {
            if (epoch != my) return true;
            Location core = s.p.getLocation().add(0, 1.3, 0);
            for (int i = 0; i < ds.size(); i++) {
                ItemDisplay d = ds.get(i);
                if (d == null || !d.isValid() || gone[i]) continue;
                int start = (int) ((maxDelay(ps) - ps.get(i).delay()) * f);
                if (t < start) { d.teleport(anchor(ps.get(i))); continue; }
                if (from[i] == null) from[i] = d.getLocation();
                double k = Math.min(1, (t - start) / (double) fl);
                Location cur = from[i].clone().add(core.clone().subtract(from[i]).toVector().multiply(k * k));
                d.teleport(cur);
                Fx.dust(cur, Fx.DEEP, 2, 0.05);
                if (k >= 1) { gone[i] = true; Fx.spark(core, 4, 0.2); d.remove(); }
            }
            return false;
        }, () -> {
            if (epoch != my) return;
            for (ItemDisplay d : ds) if (d != null && d.isValid()) d.remove();
            disp = new ArrayList<>(); pieces = List.of(); busy = false;
            Fx.sound(s.p.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1f, 1.2f);
        });
    }

    /** Armour tracks the body; missing/foreign-world pieces are silently rebuilt so visuals never desync from state. */
    void follow() {
        if (!ready) return;
        for (int i = 0; i < pieces.size(); i++) {
            ItemDisplay d = disp.get(i);
            Location a = anchor(pieces.get(i));
            if (d == null || !d.isValid() || d.getWorld() != a.getWorld()) {
                if (d != null) d.remove();
                disp.set(i, spawn(a, pieces.get(i)));
            } else d.teleport(a);
        }
    }

    void remove() {
        epoch++;
        for (ItemDisplay d : disp) if (d != null && d.isValid()) d.remove();
        disp = new ArrayList<>(); pieces = List.of(); busy = false; ready = false;
    }

    static Location reactor(Session s) {
        Location l = s.p.getLocation();
        double yaw = Math.toRadians(l.getYaw());
        return l.clone().add(-Math.sin(yaw) * 0.35, 1.3, Math.cos(yaw) * 0.35);
    }
    static Location shoulder(Session s, boolean right) {
        Location l = s.p.getLocation();
        double yaw = Math.toRadians(l.getYaw()), side = right ? 0.5 : -0.5;
        return l.clone().add(-Math.cos(yaw) * side - Math.sin(yaw) * -0.05, 1.55, -Math.sin(yaw) * side + Math.cos(yaw) * -0.05);
    }
    static Location gauntlet(Session s, boolean right) {
        Location l = s.p.getLocation();
        double yaw = Math.toRadians(l.getYaw()), side = right ? 0.55 : -0.55;
        return l.clone().add(-Math.cos(yaw) * side - Math.sin(yaw) * 0.4, 1.1, -Math.sin(yaw) * side + Math.cos(yaw) * 0.4);
    }
}
