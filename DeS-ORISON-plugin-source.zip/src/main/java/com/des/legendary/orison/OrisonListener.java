package com.des.legendary.orison;

import org.bukkit.Bukkit;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Iterator;
import java.util.List;

final class OrisonListener implements Listener {
    private final OrisonModule m;
    OrisonListener(OrisonModule m) { this.m = m; }

    // F = cast selected ability; Sneak+F = cycle selection
    @EventHandler(ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent e) {
        Session s = m.sessions.get(e.getPlayer().getUniqueId());
        if (s == null || !e.getPlayer().hasPermission("orison.use")) return;
        e.setCancelled(true);
        if (e.getPlayer().isSneaking()) s.cycle(); else s.cast(s.selected());
    }

    // Sneak + hotbar 1-5 = forge favourite N (quick selection)
    @EventHandler(ignoreCancelled = true)
    public void onHeld(PlayerItemHeldEvent e) {
        Player p = e.getPlayer();
        Session s = m.sessions.get(p.getUniqueId());
        if (s == null || !p.isSneaking() || !m.cfg.getBoolean("quick-select.sneak-hotbar", true)) return;
        List<String> favs = m.store.favs(p.getUniqueId());
        if (e.getNewSlot() < favs.size() && e.getNewSlot() < 5) { e.setCancelled(true); m.forge.forge(s, favs.get(e.getNewSlot())); }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Session s = m.sessions.get(p.getUniqueId());
        if (s == null) return;
        int now = s.now();
        EntityDamageEvent.DamageCause c = e.getCause();
        if (c == EntityDamageEvent.DamageCause.FALL) {
            if (now < s.fallGuardUntil) { e.setCancelled(true); return; }
            if (s.fragments.dampensFall()) e.setDamage(e.getDamage() * 0.4); // IMPACT DAMPENING (VECTOR)
        }
        boolean eligible = c == EntityDamageEvent.DamageCause.ENTITY_ATTACK || c == EntityDamageEvent.DamageCause.ENTITY_SWEEP_ATTACK
                || c == EntityDamageEvent.DamageCause.PROJECTILE || c == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION
                || c == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION;
        if (now < s.absorbUntil && eligible) {
            double full = e.getDamage();
            e.setDamage(full * 0.5);
            s.gain(Math.min(25, full * 2.5));
            Fx.spark(p.getLocation().add(0, 1, 0), 6, 0.3);
        }
        if (now < s.barrierUntil && s.barrierHp > 0 && c != EntityDamageEvent.DamageCause.VOID && c != EntityDamageEvent.DamageCause.SUICIDE) {
            double take = Math.min(e.getDamage(), s.barrierHp);
            s.barrierHp -= take;
            e.setDamage(e.getDamage() - take);
            Fx.spark(p.getLocation().add(0, 1, 0), 8, 0.4);
            if (e.getDamage() <= 0) return;
        }
        if (now < s.counterUntil && eligible) {              // COUNTERPULSE stores 30% of what hits you
            s.counterStored += e.getDamage();
            e.setDamage(e.getDamage() * 0.7);
        }
        // EMERGENCY BARRIER: finite, on cooldown, never invulnerability
        double after = p.getHealth() - e.getFinalDamage();
        if (after <= 4 && after > 0 && now >= s.emergencyReady && !s.overloaded) {
            s.emergencyReady = now + m.cfg.getInt("defence.emergency-barrier-cooldown-ticks", 1200);
            p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 1, true, false));
            Fx.burst(p.getLocation().add(0, 1, 0), 2.5);
        }
    }

    // ---- core can never be lost to death ----
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        Session s = m.sessions.remove(p.getUniqueId());
        if (s != null) s.destroy();
        if (e.getKeepInventory()) return;
        Iterator<ItemStack> it = e.getDrops().iterator();
        while (it.hasNext()) { ItemStack d = it.next(); if (m.items.isGenuine(d)) { it.remove(); m.store.addPending(p.getUniqueId(), d); } }
    }
    @EventHandler public void onRespawn(PlayerRespawnEvent e) { Bukkit.getScheduler().runTaskLater(m.plugin, () -> m.returnPending(e.getPlayer()), 5); }
    @EventHandler public void onJoin(PlayerJoinEvent e) {
        var key = new org.bukkit.NamespacedKey(m.plugin, "orison_flying");
        if (e.getPlayer().getPersistentDataContainer().has(key)) { e.getPlayer().setGravity(true); e.getPlayer().getPersistentDataContainer().remove(key); }
        Bukkit.getScheduler().runTaskLater(m.plugin, () -> m.returnPending(e.getPlayer()), 20); }
    @EventHandler public void onQuit(PlayerQuitEvent e) { Session s = m.sessions.remove(e.getPlayer().getUniqueId()); if (s != null) s.destroy(); }

    // dropped cores: indestructible, never despawn
    @EventHandler public void onItemSpawn(EntitySpawnEvent e) {
        if (e.getEntity() instanceof Item i && m.items.isGenuine(i.getItemStack())) { i.setInvulnerable(true); i.setUnlimitedLifetime(true); }
    }
    @EventHandler public void onDespawn(ItemDespawnEvent e) { if (m.items.isGenuine(e.getEntity().getItemStack())) e.setCancelled(true); }

    // ---- GUI: nothing can be taken, moved or duplicated ----
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Forge.Gui g)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != e.getView().getTopInventory() || !(e.getWhoClicked() instanceof Player p)) return;
        Session s = m.sessions.get(p.getUniqueId());
        int slot = e.getSlot();
        if (slot == 45) m.forge.openGui(p, Math.max(0, g.page - 1), g.category);
        else if (slot == 53) m.forge.openGui(p, g.page + 1, g.category);
        else if (slot == 49 && s != null) m.forge.dismiss(s, true);
        else if (slot == 0) m.forge.openGui(p, 0, null);
        else if (slot >= 1 && slot <= 8) { if (slot - 1 < g.cats.size()) m.forge.openGui(p, 0, g.cats.get(slot - 1)); }
        else if (slot >= 9 && slot < 45) {
            int idx = g.page * 36 + (slot - 9);
            if (idx >= g.ids.size()) return;
            String id = g.ids.get(idx);
            if (e.isRightClick()) {
                List<String> f = m.store.favs(p.getUniqueId());
                if (!f.remove(id)) { f.add(id); while (f.size() > 5) f.remove(0); }
                m.store.setFavs(p.getUniqueId(), f);
                p.sendMessage(net.kyori.adventure.text.Component.text("Favourites: " + f, net.kyori.adventure.text.format.NamedTextColor.GRAY));
            } else if (s != null) { p.closeInventory(); m.forge.forge(s, id); }
            else p.sendMessage(net.kyori.adventure.text.Component.text("Wear a genuine ORISON core first.", net.kyori.adventure.text.format.NamedTextColor.RED));
        }
    }
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent e) { if (e.getView().getTopInventory().getHolder() instanceof Forge.Gui) e.setCancelled(true); }
}
