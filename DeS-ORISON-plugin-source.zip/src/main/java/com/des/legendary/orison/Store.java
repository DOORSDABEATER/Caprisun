package com.des.legendary.orison;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.*;

/** Persistent state: signing secret, issued/revoked core ids, favourites, cores waiting to be returned. */
final class Store {
    private final JavaPlugin pl;
    private final File f;
    private final YamlConfiguration y;
    private final Set<UUID> revoked = new HashSet<>();

    Store(JavaPlugin pl) {
        this.pl = pl;
        pl.getDataFolder().mkdirs();
        f = new File(pl.getDataFolder(), "orison-data.yml");
        y = YamlConfiguration.loadConfiguration(f);
        for (String s : y.getStringList("revoked")) revoked.add(UUID.fromString(s));
    }
    String secret() {
        String s = y.getString("secret");
        if (s == null) {
            byte[] b = new byte[32];
            new SecureRandom().nextBytes(b);
            s = HexFormat.of().formatHex(b);
            y.set("secret", s);
            save();
        }
        return s;
    }
    void issue(UUID id, UUID owner) { y.set("issued." + id, owner.toString()); save(); }
    boolean revoked(UUID id) { return revoked.contains(id); }
    void revoke(UUID id) {
        if (revoked.add(id)) {
            List<String> l = new ArrayList<>();
            for (UUID u : revoked) l.add(u.toString());
            y.set("revoked", l);
            save();
        }
    }
    List<UUID> issuedTo(UUID owner) {
        List<UUID> out = new ArrayList<>();
        ConfigurationSection s = y.getConfigurationSection("issued");
        if (s == null) return out;
        for (String k : s.getKeys(false)) if (owner.toString().equals(s.getString(k))) out.add(UUID.fromString(k));
        return out;
    }
    List<String> favs(UUID u) { return new ArrayList<>(y.getStringList("fav." + u)); }
    void setFavs(UUID u, List<String> l) { y.set("fav." + u, l); save(); }

    void addPending(UUID u, ItemStack it) {
        List<ItemStack> l = pending(u);
        l.add(it);
        y.set("pending." + u, l);
        save();
    }
    @SuppressWarnings("unchecked")
    private List<ItemStack> pending(UUID u) {
        List<?> raw = y.getList("pending." + u, new ArrayList<>());
        List<ItemStack> l = new ArrayList<>();
        for (Object o : raw) if (o instanceof ItemStack is) l.add(is);
        return l;
    }
    List<ItemStack> takePending(UUID u) {
        List<ItemStack> l = pending(u);
        if (!l.isEmpty()) { y.set("pending." + u, null); save(); }
        return l;
    }
    Set<String> ultsUsed(UUID u) { return new HashSet<>(y.getStringList("ults." + u)); }
    void markUlt(UUID u, Form f) {
        Set<String> s = ultsUsed(u);
        if (s.add(f.name())) { y.set("ults." + u, new ArrayList<>(s)); save(); }
    }
    void save() {
        try { y.save(f); } catch (IOException e) { pl.getLogger().warning("ORISON store save failed: " + e.getMessage()); }
    }
}
