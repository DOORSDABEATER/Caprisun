package com.des.legendary.orison;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Projectile;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * Remaining catalogue: sword, katana, axe, dagger, crossbow, shield, claws, staff, pickaxe, drill.
 * Each = exactly 8 abilities. Tools never break blocks (griefing-safe); their identity is purely combat.
 */
final class Weapons2 {
    @FunctionalInterface interface Act { boolean run(Session s); }

    private static Ability ab(String id, String name, String desc, int cost, int heat, int cd, Act act) {
        return new Ability(id, name, desc, cost, heat, s -> act.run(s) ? cd : -1);
    }
    private static Vector fl(Session s) { return Abilities.flat(s.p.getEyeLocation().getDirection()); }
    private static Vector eye(Session s) { return s.p.getEyeLocation().getDirection(); }
    private static double d(Session s, String id, double def) { return Abilities.d(s, id, def); }
    private static Forge.Part part(int m, double x, double y, double z, float sc) { return new Forge.Part(m, new Vector(x, y, z), sc); }

    // ---- shared primitives ----
    static boolean melee(Session s, String id, double range, double deg, double dmg, double kb, double up) {
        Vector f = fl(s);
        Scythe.arc(s, f, -deg / 2, deg / 2, range * 0.5, range);
        Fx.sound(s.p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.8f);
        for (LivingEntity e : Scythe.cone(s, range, deg)) s.hit(e, d(s, id, dmg), f.clone().multiply(kb).setY(up));
        return true;
    }
    static boolean dashHit(Session s, String id, double len, double dmg) {
        Location start = s.p.getLocation(), last = start.clone();
        Vector dir = fl(s);
        Set<LivingEntity> hit = new LinkedHashSet<>();
        for (double x = 0; x < len; x += 0.5) {
            Location n = last.clone().add(dir.clone().multiply(0.5));
            if (!n.getBlock().isPassable() || !n.clone().add(0, 1, 0).getBlock().isPassable()) break;
            last = n;
            for (LivingEntity e : n.getWorld().getNearbyLivingEntities(n.clone().add(0, 1, 0), 1.3)) if (s.valid(e)) hit.add(e);
        }
        if (last.distanceSquared(start) < 1) return false;
        Fx.line(start.clone().add(0, 1, 0), last.clone().add(0, 1, 0), 0.3, Fx.WHITE);
        last.setYaw(start.getYaw()); last.setPitch(start.getPitch());
        s.p.teleport(last);
        for (LivingEntity e : hit) s.hit(e, d(s, id, dmg), dir.clone().multiply(0.3).setY(0.2));
        return true;
    }
    static void bolt(Session s, String id, Vector dir, double speed, double range, double radius, double dmg, boolean pierce, Particle.DustOptions c) {
        Location from = s.p.getEyeLocation().add(dir.clone().normalize().multiply(0.9));
        Abilities.shoot(s, from, dir, speed, range, radius, d(s, id, dmg), pierce, l -> { Fx.dust(l, c, 2, 0.05); Fx.dust(l, Fx.WHITE, 1, 0); }, l -> Fx.burst(l, 1.0));
    }
    static void areaHit(Session s, String id, Location c, double r, double dmg, double up) {
        Fx.burst(c, Math.max(1.5, r * 0.6));
        for (LivingEntity e : Abilities.radius(s, c, r)) s.hit(e, d(s, id, dmg), new Vector(0, up, 0));
    }
    static void execute(Session s, String id, LivingEntity t, double base, double pct, double cap) {
        @SuppressWarnings("deprecation") double miss = Math.min(cap, (t.getMaxHealth() - t.getHealth()) * pct);
        s.hit(t, d(s, id, base) + miss, new Vector(0, 0.4, 0));
        Fx.burst(t.getLocation().add(0, 1, 0), 2);
    }
    static void spin(Session s, String id, int ticks, double r, double dmg, int every) {
        s.every(2, ticks, t -> {
            Scythe.arc(s, new Vector(1, 0, 0).rotateAroundY(Math.toRadians(t * 40)), 0, 60, r * 0.5, r);
            if (t % every == 0) for (LivingEntity e : Abilities.radius(s, s.p.getLocation(), r)) s.hit(e, d(s, id, dmg), null);
            return false;
        }, null);
    }
    static void potion(Session s, PotionEffectType t, int ticks, int amp) { s.p.addPotionEffect(new PotionEffect(t, ticks, amp, true, false)); }
    static void burstTimes(Session s, int n, int period, Runnable r) { int[] i = {0}; s.every(period, period * n, t -> { r.run(); return false; }, null); }

    // ================= SWORD =================
    static Forge.Blueprint sword() {
        return new Forge.Blueprint("sword", "Resonance Sword", "Swords", Material.NETHERITE_SWORD, 7360,
            List.of(part(7361, 0, 1.0, 0.1, 1.1f), part(7362, 0, 0.1, 0, 0.9f)), List.of(
            ab("sword_slash", "Slash", "Quick arc.", 0, 2, 8, s -> melee(s, "sword_slash", 4.2, 90, 6, 0.4, 0.2)),
            ab("sword_riposte", "Riposte", "1.5s parry stance; stored hits return as a blast.", 8, 3, 100, s -> { Abilities.counter(s, 30, 1.5, 5, 25); return true; }),
            ab("sword_lunge", "Lunge Thrust", "Dash-thrust through the target.", 6, 4, 60, s -> dashHit(s, "sword_lunge", 4.5, 8)),
            ab("sword_whirl", "Whirl", "Double spin cut.", 10, 5, 100, s -> { spin(s, "sword_whirl", 16, 3.6, 5, 8); return true; }),
            ab("sword_beam", "Sword Beam", "Piercing resonance beam of the blade.", 10, 6, 90, s -> { bolt(s, "sword_beam", eye(s), 1.8, 30, 1.1, 8, true, Fx.PURPLE); return true; }),
            ab("sword_flurry", "Flurry", "Five rapid cuts.", 12, 6, 120, s -> { burstTimes(s, 5, 2, () -> melee(s, "sword_flurry", 3.8, 100, 3, 0.1, 0.05)); return true; }),
            ab("sword_sky_cutter", "Sky Cutter", "Upward cut, then a leaping follow-up.", 14, 7, 140, s -> {
                for (LivingEntity e : Scythe.cone(s, 4, 90)) s.hit(e, d(s, "sword_sky_cutter", 6), new Vector(0, 1.0, 0));
                s.p.setVelocity(new Vector(0, 0.8, 0)); s.fallGuardUntil = s.now() + 60;
                s.every(1, 12, t -> { if (t == 8) { for (LivingEntity e : Abilities.radius(s, s.p.getLocation(), 4)) s.hit(e, 7, new Vector(0, -0.5, 0)); Fx.burst(s.p.getLocation(), 3); return true; } return false; }, null); return true; }),
            ab("sword_blade_sovereign", "Blade Sovereign", "Finisher: three crossing arcs.", 45, 20, 360, s -> {
                burstTimes(s, 3, 3, () -> { Vector f = fl(s); Scythe.arc(s, f, -100, 100, 2, 6); for (LivingEntity e : Scythe.cone(s, 6, 200)) s.hit(e, d(s, "sword_blade_sovereign", 18) / 3, f.clone().multiply(0.4).setY(0.3)); }); return true; })
        ));
    }

    // ================= KATANA =================
    static Forge.Blueprint katana() {
        return new Forge.Blueprint("katana", "Resonance Katana", "Swords", Material.IRON_SWORD, 7370,
            List.of(part(7371, 0, 1.0, 0.1, 1.2f), part(7372, 0, 0.0, 0, 0.8f)), List.of(
            ab("katana_draw_cut", "Draw Cut", "Instant long thin cut.", 4, 3, 30, s -> { Abilities.beam(s, s.p.getEyeLocation(), eye(s), 6.5, 0.6, d(s, "katana_draw_cut", 8), false); return true; }),
            ab("katana_iaido", "Iaido Dash", "Dash, then the cut lands again as you sheathe.", 12, 6, 110, s -> {
                Location from = s.p.getLocation();
                if (!dashHit(s, "katana_iaido", 8, 12)) return false;
                s.every(5, 10, t -> { if (t == 5) { Fx.line(from.clone().add(0, 1, 0), s.p.getLocation().add(0, 1, 0), 0.3, Fx.PURPLE); for (LivingEntity e : Abilities.radius(s, s.p.getLocation(), 3.5)) s.hit(e, 6, null); } return false; }, null); return true; }),
            ab("katana_crescent_flash", "Crescent Flash", "Razor-thin piercing crescent.", 9, 5, 80, s -> { bolt(s, "katana_crescent_flash", eye(s), 2.2, 28, 0.6, 7, true, Fx.WHITE); return true; }),
            ab("katana_counter", "Counter Stance", "2s: soak and return damage 2.5x.", 10, 4, 160, s -> { Abilities.counter(s, 40, 2.5, 5, 30); return true; }),
            ab("katana_triple", "Triple Slash", "Three cuts at three angles.", 12, 6, 100, s -> {
                int[] n = {0}; s.every(3, 9, t -> { double a = (n[0]++ - 1) * 35; Vector f = fl(s).rotateAroundY(Math.toRadians(a)); Scythe.arc(s, f, -25, 25, 2, 5);
                    for (LivingEntity e : Scythe.cone(s, 5, 70)) s.hit(e, d(s, "katana_triple", 5), f.multiply(0.3)); return false; }, null); return true; }),
            ab("katana_blink", "Blink Cut", "Vanish and reappear behind the nearest enemy.", 14, 7, 120, s -> {
                LivingEntity t = Abilities.nearest(s, 12); if (t == null) return false;
                Location b = t.getLocation().add(t.getLocation().getDirection().multiply(-1.5)); b.setDirection(t.getLocation().toVector().subtract(b.toVector()));
                Fx.burst(s.p.getLocation(), 1.5); s.p.teleport(b); s.hit(t, d(s, "katana_blink", 7), null); Fx.burst(b, 1.5); return true; }),
            ab("katana_petal_storm", "Petal Storm", "Whirl of tiny cuts for 1s.", 18, 9, 160, s -> {
                s.every(2, 20, t -> { Fx.dust(s.p.getLocation().add(0, 1, 0), Fx.PURPLE, 10, 1.6); for (LivingEntity e : Abilities.radius(s, s.p.getLocation(), 4)) if (t % 4 == 0) s.hit(e, d(s, "katana_petal_storm", 2.5), null); return false; }, null); return true; }),
            ab("katana_moonfall", "Moonfall", "Finisher: five slashes through one target.", 50, 22, 380, s -> {
                LivingEntity t = Scythe.sight(s, 20); if (t == null) return false;
                s.every(2, 10, k -> { if (!s.valid(t)) return true; Location c = t.getLocation().add(0, 1, 0); Vector v = new Vector(Math.cos(k), Math.sin(k * 1.3), Math.sin(k));
                    Fx.line(c.clone().add(v.clone().multiply(2)), c.clone().subtract(v.clone().multiply(2)), 0.25, Fx.WHITE); s.hit(t, d(s, "katana_moonfall", 20) / 5, null); return false; }, null); return true; })
        ));
    }

    // ================= AXE =================
    static Forge.Blueprint axe() {
        return new Forge.Blueprint("axe", "Resonance Axe", "Axes", Material.NETHERITE_AXE, 7380,
            List.of(part(7381, 0, 1.0, 0.1, 1.2f), part(7382, 0, 0.1, 0, 1.0f)), List.of(
            ab("axe_chop", "Chop", "Heavy single chop.", 0, 3, 14, s -> melee(s, "axe_chop", 3.8, 70, 8, 0.6, 0.3)),
            ab("axe_cleave", "Cleave", "Wide cleave that causes bleeding (wither).", 8, 5, 80, s -> { melee(s, "axe_cleave", 4.4, 160, 7, 0.5, 0.2); for (LivingEntity e : Scythe.cone(s, 4.4, 160)) e.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 40, 0, true, false)); return true; }),
            ab("axe_hurl", "Hurl Axe", "Throw the axe; pierces.", 10, 6, 90, s -> { bolt(s, "axe_hurl", eye(s), 1.5, 24, 1.2, 11, true, Fx.DEEP); return true; }),
            ab("axe_roar", "Battle Roar", "Strength for 5s; nearby foes are shaken.", 10, 3, 240, s -> { potion(s, PotionEffectType.STRENGTH, 100, 0); Fx.ring(s.p.getLocation().add(0, 1, 0), 4, 30, Fx.PURPLE);
                for (LivingEntity e : Abilities.radius(s, s.p.getLocation(), 5)) e.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 60, 0, true, false)); Fx.sound(s.p.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1f, 0.7f); return true; }),
            ab("axe_leap_chop", "Leap Chop", "Leap and bury the axe on landing.", 14, 8, 140, s -> { s.fallGuardUntil = s.now() + 60; s.p.setVelocity(fl(s).multiply(0.9).setY(0.9));
                s.every(1, 30, t -> { if (t >= 5 && s.p.isOnGround()) { areaHit(s, "axe_leap_chop", s.p.getLocation(), 3.5, 11, 0.6); return true; } return false; }, null); return true; }),
            ab("axe_whirlwind", "Whirlwind", "Long spin, hits every 0.4s.", 16, 9, 180, s -> { spin(s, "axe_whirlwind", 24, 4, 4, 8); return true; }),
            ab("axe_shield_breaker", "Shield Breaker", "Smash one target: damage, weakness, heavy knockback.", 10, 6, 100, s -> {
                LivingEntity t = Scythe.sight(s, 5); if (t == null) return false; s.hit(t, d(s, "axe_shield_breaker", 10), fl(s).multiply(1.4).setY(0.4));
                t.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 80, 1, true, false)); Fx.burst(t.getLocation().add(0, 1, 0), 2); return true; }),
            ab("axe_execution", "Execution", "Finisher: massive cone cut; bonus on wounded.", 45, 20, 340, s -> { Vector f = fl(s); Scythe.arc(s, f, -80, 80, 2, 6);
                for (LivingEntity e : Scythe.cone(s, 5, 120)) execute(s, "axe_execution", e, 14, 0.4, 25); return true; })
        ));
    }

    // ================= DAGGER =================
    static Forge.Blueprint dagger() {
        return new Forge.Blueprint("dagger", "Resonance Dagger", "Daggers", Material.IRON_SWORD, 7390,
            List.of(part(7391, 0, 0.6, 0.1, 0.8f)), List.of(
            ab("dagger_stab", "Stab", "Fast short stab.", 0, 1, 5, s -> melee(s, "dagger_stab", 2.6, 60, 5, 0.1, 0.05)),
            ab("dagger_backstab", "Backstab", "x2.5 damage on enemies facing away.", 6, 4, 60, s -> {
                LivingEntity t = Scythe.sight(s, 4); if (t == null) return false;
                boolean behind = t.getLocation().getDirection().dot(s.p.getLocation().getDirection()) > 0.3;
                s.hit(t, d(s, "dagger_backstab", 5) * (behind ? 2.5 : 1.0), null); Fx.burst(t.getLocation().add(0, 1, 0), behind ? 2 : 1); return true; }),
            ab("dagger_knives", "Throwing Knives", "Three-knife fan.", 8, 4, 70, s -> { for (int i = -1; i <= 1; i++) bolt(s, "dagger_knives", eye(s).rotateAroundY(Math.toRadians(i * 9)), 2.0, 22, 0.6, 4, false, Fx.WHITE); return true; }),
            ab("dagger_shadow_step", "Shadow Step", "Teleport behind a target you look at and strike.", 12, 6, 110, s -> {
                LivingEntity t = Scythe.sight(s, 15); if (t == null) return false;
                Location b = t.getLocation().add(t.getLocation().getDirection().multiply(-1.3)); b.setDirection(t.getLocation().toVector().subtract(b.toVector()));
                Fx.burst(s.p.getLocation(), 1.5); s.p.teleport(b); s.hit(t, d(s, "dagger_shadow_step", 7), null); return true; }),
            ab("dagger_smoke", "Smoke Bomb", "Blinds nearby foes; you gain speed.", 10, 3, 200, s -> { Location c = s.p.getLocation().add(0, 1, 0); Fx.ring(c, 4, 30, Fx.DEEP); Fx.dust(c, Fx.DEEP, 60, 2);
                for (LivingEntity e : Abilities.radius(s, c, 4)) e.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 0, true, false)); potion(s, PotionEffectType.SPEED, 80, 2); return true; }),
            ab("dagger_poison", "Poison Blade", "Cone cut that poisons for 5s.", 8, 4, 100, s -> { melee(s, "dagger_poison", 3, 90, 3, 0.1, 0.05); for (LivingEntity e : Scythe.cone(s, 3, 90)) e.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 100, 1, true, false)); return true; }),
            ab("dagger_flicker", "Flicker", "Three rapid short dashes, each cutting.", 14, 7, 120, s -> { burstTimes(s, 3, 3, () -> dashHit(s, "dagger_flicker", 3, 4)); return true; }),
            ab("dagger_assassinate", "Assassinate", "Finisher: lethal strike, huge bonus on wounded.", 40, 18, 340, s -> {
                LivingEntity t = Scythe.sight(s, 5); if (t == null) return false; execute(s, "dagger_assassinate", t, 10, 0.5, 30); return true; })
        ));
    }

    // ================= CROSSBOW =================
    static Forge.Blueprint crossbow() {
        return new Forge.Blueprint("crossbow", "Resonance Crossbow", "Ranged Weapons", Material.ECHO_SHARD, 7710,
            List.of(part(7711, 0.1, 1.0, 0.2, 1.1f), part(7712, 0.1, 1.0, 0.1, 1.0f)), List.of(
            ab("xbow_bolt", "Bolt", "Fast heavy bolt.", 3, 2, 10, s -> { bolt(s, "xbow_bolt", eye(s), 2.4, 45, 0.7, 9, false, Fx.PURPLE); return true; }),
            ab("xbow_piercing", "Piercing Bolt", "Armour-piercing line shot.", 10, 6, 80, s -> { bolt(s, "xbow_piercing", eye(s), 2.8, 55, 0.7, 10, true, Fx.WHITE); return true; }),
            ab("xbow_explosive", "Explosive Bolt", "Detonates on impact.", 14, 8, 100, s -> { Location f = s.p.getEyeLocation().add(eye(s));
                Abilities.shoot(s, f, eye(s), 2.0, 40, 0.8, d(s, "xbow_explosive", 6), false, l -> Fx.dust(l, Fx.PURPLE, 2, 0.05), l -> areaHit(s, "xbow_explosive", l, 3, 10, 0.4)); return true; }),
            ab("xbow_burst", "Burst Fire", "Three quick bolts.", 9, 5, 80, s -> { burstTimes(s, 3, 2, () -> bolt(s, "xbow_burst", eye(s), 2.2, 35, 0.7, 5, false, Fx.PURPLE)); return true; }),
            ab("xbow_grapple", "Grapple Bolt", "Reel to the point you aim at.", 8, 3, 100, s -> { Location t = Abilities.aim(s, 28); if (t.distanceSquared(s.p.getLocation()) < 9) return false;
                Fx.line(s.p.getEyeLocation(), t, 0.4, Fx.WHITE); s.fallGuardUntil = s.now() + 60; s.p.setVelocity(t.toVector().subtract(s.p.getLocation().toVector()).normalize().multiply(1.7).setY(0.3)); return true; }),
            ab("xbow_net", "Net Bolt", "Entangles everything near impact.", 12, 5, 140, s -> { Location f = s.p.getEyeLocation().add(eye(s));
                Abilities.shoot(s, f, eye(s), 1.8, 35, 0.8, 2, false, l -> Fx.dust(l, Fx.DEEP, 2, 0.1), l -> { Fx.ring(l, 3, 24, Fx.WHITE);
                    for (LivingEntity e : Abilities.radius(s, l, 3)) e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 5, true, false)); }); return true; }),
            ab("xbow_mine", "Resonance Mine", "Plant a mine; arms in 1s, blasts anything near it.", 14, 6, 160, s -> { Location c = Abilities.aim(s, 14); boolean[] done = {false};
                s.every(5, 100, t -> { Fx.ring(c.clone().add(0, 0.1, 0), 0.6, 10, t < 20 ? Fx.DEEP : Fx.WHITE); if (t >= 20 && !Abilities.radius(s, c, 3).isEmpty()) { done[0] = true; return true; } return false; },
                    () -> areaHit(s, "xbow_mine", c, 4, 12, 0.8)); return true; }),
            ab("xbow_siege_volley", "Siege Volley", "Finisher: eight explosive bolts in an arc.", 45, 20, 340, s -> {
                int[] n = {0}; s.every(2, 16, t -> { Vector v = eye(s).rotateAroundY(Math.toRadians((n[0]++ - 3.5) * 6)); Location f = s.p.getEyeLocation().add(v);
                    Abilities.shoot(s, f, v, 2.0, 40, 0.8, 3, false, l -> Fx.dust(l, Fx.PURPLE, 2, 0.05), l -> areaHit(s, "xbow_siege_volley", l, 2.2, 7, 0.4)); return false; }, null); return true; })
        ));
    }

    // ================= SHIELD =================
    static Forge.Blueprint shield() {
        return new Forge.Blueprint("shield", "Resonance Shield", "Shields", Material.ECHO_SHARD, 7720,
            List.of(part(7721, 0.2, 1.0, 0.3, 1.3f), part(7722, 0.2, 1.0, 0.25, 1.0f)), List.of(
            ab("shield_bash", "Shield Bash", "Short bash with strong knockback.", 0, 3, 14, s -> melee(s, "shield_bash", 3, 70, 5, 1.2, 0.3)),
            ab("shield_guard", "Raise Guard", "3s barrier pool of 25 damage.", 8, 3, 160, s -> { s.barrierUntil = s.now() + 60; s.barrierHp = 25; Fx.sound(s.p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 0.8f);
                s.every(4, 60, t -> { Fx.discRing(s.p.getEyeLocation().add(eye(s).multiply(1.6)), eye(s), 1.4, 20, Fx.PURPLE); return s.barrierHp <= 0; }, () -> { s.barrierUntil = 0; s.barrierHp = 0; }); return true; }),
            ab("shield_throw", "Shield Throw", "Hurl the shield; it flies out and returns.", 12, 6, 120, s -> { Vector dir = eye(s); Location[] last = {s.p.getEyeLocation()};
                Abilities.shoot(s, s.p.getEyeLocation().add(dir), dir, 1.5, 18, 1.3, d(s, "shield_throw", 8), true, l -> { last[0] = l.clone(); Fx.discRing(l, dir, 0.8, 12, Fx.WHITE); }, l -> Fx.burst(l, 1),
                    () -> { Vector back = s.p.getEyeLocation().toVector().subtract(last[0].toVector()); Abilities.shoot(s, last[0], back, 1.6, 22, 1.3, d(s, "shield_throw", 8), true, l -> Fx.discRing(l, back, 0.8, 12, Fx.PURPLE), l -> Fx.burst(l, 1)); }); return true; }),
            ab("shield_charge", "Shield Charge", "Charge forward, bulldozing foes aside.", 14, 7, 140, s -> {
                Vector d = fl(s); Set<UUID> hit = new HashSet<>(); s.every(1, 10, t -> { s.p.setVelocity(d.clone().multiply(1.1)); Fx.dust(s.p.getLocation().add(0, 1, 0), Fx.PURPLE, 4, 0.4);
                    for (LivingEntity e : Abilities.radius(s, s.p.getLocation().add(0, 1, 0), 1.8)) if (hit.add(e.getUniqueId())) s.hit(e, d(s, "shield_charge", 8), d.clone().multiply(1.6).setY(0.4)); return false; }, null); return true; }),
            ab("shield_taunt", "Taunt Pulse", "Forces nearby mobs to target you.", 6, 2, 160, s -> { Fx.ring(s.p.getLocation().add(0, 1, 0), 8, 40, Fx.WHITE);
                for (LivingEntity e : Abilities.radius(s, s.p.getLocation(), 8)) if (e instanceof Mob m) { m.setTarget(s.p); e.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0, true, false)); } return true; }),
            ab("shield_fortify", "Fortify", "Resistance III for 4s, but slowed.", 10, 3, 240, s -> { potion(s, PotionEffectType.RESISTANCE, 80, 2); potion(s, PotionEffectType.SLOWNESS, 80, 0); Fx.burst(s.p.getLocation().add(0, 1, 0), 2); return true; }),
            ab("shield_reflect", "Reflect", "1.5s: erase projectiles and fire them back (up to 6).", 14, 5, 200, s -> { int[] left = {6};
                s.every(2, 30, t -> { Location c = s.p.getEyeLocation().add(eye(s).multiply(1.5)); Fx.discRing(c, eye(s), 1.6, 20, Fx.WHITE);
                    for (Projectile pr : c.getWorld().getNearbyEntitiesByType(Projectile.class, c, 3.5)) { if (pr.isDead() || s.p.equals(pr.getShooter())) continue; pr.remove(); bolt(s, "shield_reflect", eye(s), 1.9, 30, 0.8, 6, false, Fx.PURPLE); if (--left[0] <= 0) return true; }
                    return false; }, null); return true; }),
            ab("shield_quake", "Bulwark Quake", "Finisher: slam that staggers and shields you.", 40, 16, 320, s -> { Location c = s.p.getLocation(); areaHit(s, "shield_quake", c, 6, 10, 0.6);
                for (LivingEntity e : Abilities.radius(s, c, 6)) e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 50, 3, true, false)); potion(s, PotionEffectType.ABSORPTION, 100, 2); return true; })
        ));
    }

    // ================= CLAWS =================
    static Forge.Blueprint claws() {
        return new Forge.Blueprint("claws", "Resonance Claws", "Custom Weapons", Material.NETHERITE_SWORD, 7730,
            List.of(part(7731, -0.2, 0.9, 0.2, 0.9f), part(7732, 0.2, 0.9, 0.2, 0.9f)), List.of(
            ab("claws_rake", "Rake", "Two rapid rakes.", 0, 2, 8, s -> { burstTimes(s, 2, 2, () -> melee(s, "claws_rake", 3, 90, 3, 0.1, 0.05)); return true; }),
            ab("claws_pounce", "Pounce", "Leap onto a target you look at.", 8, 5, 90, s -> { LivingEntity t = Scythe.sight(s, 10); if (t == null) return false; s.fallGuardUntil = s.now() + 40;
                s.p.setVelocity(t.getLocation().toVector().subtract(s.p.getLocation().toVector()).normalize().multiply(1.3).setY(0.4));
                s.every(1, 14, k -> { if (s.p.getLocation().distanceSquared(t.getLocation()) < 6) { s.hit(t, d(s, "claws_pounce", 8), null); Fx.burst(t.getLocation().add(0, 1, 0), 2); return true; } return false; }, null); return true; }),
            ab("claws_shred", "Shred", "Six tearing hits on one target.", 12, 7, 120, s -> { LivingEntity t = Scythe.sight(s, 3.6); if (t == null) return false;
                s.every(2, 12, k -> { if (!s.valid(t)) return true; s.hit(t, d(s, "claws_shred", 2), null); Fx.spark(t.getLocation().add(0, 1, 0), 4, 0.3); return false; }, null);
                t.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 60, 0, true, false)); return true; }),
            ab("claws_feral_leap", "Feral Leap", "Huge backward leap to disengage.", 6, 2, 100, s -> { s.fallGuardUntil = s.now() + 60; s.p.setVelocity(fl(s).multiply(-1.2).setY(0.8)); Fx.burst(s.p.getLocation(), 1.5); return true; }),
            ab("claws_rending_lunge", "Rending Lunge", "Dash that rends (wither).", 10, 6, 100, s -> { if (!dashHit(s, "claws_rending_lunge", 5, 7)) return false;
                for (LivingEntity e : Abilities.radius(s, s.p.getLocation(), 3)) e.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 50, 0, true, false)); return true; }),
            ab("claws_frenzy", "Frenzy", "5s of Speed II and Haste II.", 12, 4, 220, s -> { potion(s, PotionEffectType.SPEED, 100, 1); potion(s, PotionEffectType.HASTE, 100, 1); Fx.ring(s.p.getLocation().add(0, 1, 0), 1.5, 20, Fx.PURPLE); return true; }),
            ab("claws_barrage", "Claw Barrage", "Five rapid sweeps.", 16, 8, 140, s -> { burstTimes(s, 5, 2, () -> melee(s, "claws_barrage", 3.4, 120, 3, 0.1, 0.05)); return true; }),
            ab("claws_apex_maul", "Apex Maul", "Finisher: six savage strikes, bonus on wounded.", 45, 20, 340, s -> { LivingEntity t = Scythe.sight(s, 5); if (t == null) return false;
                s.every(2, 12, k -> { if (!s.valid(t)) return true; s.hit(t, d(s, "claws_apex_maul", 12) / 6, null); Fx.spark(t.getLocation().add(0, 1, 0), 6, 0.4); return false; }, () -> { if (s.valid(t)) execute(s, "claws_apex_maul", t, 0, 0.35, 20); }); return true; })
        ));
    }

    // ================= STAFF =================
    static Forge.Blueprint staff() {
        return new Forge.Blueprint("staff", "Resonance Staff", "Custom Weapons", Material.BLAZE_ROD, 7740,
            List.of(part(7741, 0, 1.6, 0.1, 1.0f), part(7742, 0, 0.6, 0, 1.0f), part(7743, 0, -0.6, 0, 0.8f)), List.of(
            ab("staff_arcane_bolt", "Arcane Bolt", "Slightly homing bolt.", 3, 2, 8, s -> { Abilities.homing(s, s.p.getEyeLocation(), eye(s), Scythe.sight(s, 30), 1.4, d(s, "staff_arcane_bolt", 6), 1.2, 50); return true; }),
            ab("staff_orb", "Resonance Orb", "Slow orb that detonates widely.", 12, 7, 100, s -> { Location f = s.p.getEyeLocation().add(eye(s));
                Abilities.shoot(s, f, eye(s), 0.8, 30, 1.2, 4, false, l -> { Fx.dust(l, Fx.PURPLE, 8, 0.4); Fx.ring(l, 0.8, 12, Fx.WHITE); }, l -> areaHit(s, "staff_orb", l, 4, 10, 0.5)); return true; }),
            ab("staff_chain", "Chain Lightning", "Arcs through up to four enemies.", 14, 8, 120, s -> { LivingEntity cur = Scythe.sight(s, 25); if (cur == null) return false; Set<UUID> seen = new HashSet<>(); Location from = s.p.getEyeLocation(); double dmg = d(s, "staff_chain", 6);
                for (int i = 0; i < 4 && cur != null; i++) { seen.add(cur.getUniqueId()); Fx.line(from, cur.getLocation().add(0, 1, 0), 0.3, Fx.WHITE); s.hit(cur, dmg * (1 - i * 0.15), null); from = cur.getLocation().add(0, 1, 0); LivingEntity nxt = null; double bd = 36;
                    for (LivingEntity e : Abilities.radius(s, from, 6)) if (!seen.contains(e.getUniqueId()) && e.getLocation().distanceSquared(from) < bd) { bd = e.getLocation().distanceSquared(from); nxt = e; } cur = nxt; } return true; }),
            ab("staff_gravity_well", "Gravity Well", "Small well pulls foes together.", 14, 7, 160, s -> { Location c = Abilities.aim(s, 22);
                s.every(2, 40, t -> { Fx.ring(c.clone().add(0, 0.2, 0), 4 - t * 0.07, 24, Fx.PURPLE); for (LivingEntity e : Abilities.radius(s, c, 5)) if (!Session.boss(e)) e.setVelocity(e.getVelocity().multiply(0.5).add(c.toVector().subtract(e.getLocation().toVector()).normalize().multiply(0.3))); return false; }, null); return true; }),
            ab("staff_ward", "Barrier Ward", "4s barrier pool of 30.", 16, 4, 220, s -> { s.barrierUntil = s.now() + 80; s.barrierHp = 30; s.every(4, 80, t -> { Fx.ring(s.p.getLocation().add(0, 1 + Math.sin(t * 0.3) * 0.5, 0), 1.6, 20, Fx.WHITE); return s.barrierHp <= 0; }, () -> { s.barrierUntil = 0; s.barrierHp = 0; }); return true; }),
            ab("staff_meteor", "Meteor", "Marks the ground; a meteor lands after 1.5s.", 22, 12, 220, s -> { Location c = Abilities.aim(s, 30);
                s.every(3, 30, t -> { Fx.ring(c.clone().add(0, 0.1, 0), 4 - t * 0.1, 28, Fx.WHITE); for (double y = 20 - t * 0.6; y < 22 - t * 0.6; y += 1) Fx.dust(c.clone().add(0, y, 0), Fx.PURPLE, 4, 0.5); return false; }, () -> areaHit(s, "staff_meteor", c, 4.5, 16, 0.8)); return true; }),
            ab("staff_restoration", "Restoration", "Regeneration II for 5s and +10 resonance.", 0, 0, 260, s -> { potion(s, PotionEffectType.REGENERATION, 100, 1); s.gain(10); Fx.burst(s.p.getLocation().add(0, 1, 0), 2); return true; }),
            ab("staff_arcane_nova", "Arcane Nova", "Finisher: wide nova that also slows.", 45, 20, 340, s -> { Location c = s.p.getLocation().add(0, 1, 0); Set<UUID> hit = new HashSet<>();
                s.every(1, 12, t -> { double r = 1 + t * 0.8; Fx.ring(c, r, (int) (r * 12), Fx.PURPLE); Fx.ring(c.clone().add(0, 0.5, 0), r * 0.8, (int) (r * 10), Fx.WHITE);
                    for (LivingEntity e : Abilities.radius(s, c, r + 0.8)) if (hit.add(e.getUniqueId())) { s.hit(e, d(s, "staff_arcane_nova", 16), new Vector(0, 0.5, 0)); e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 60, 2, true, false)); } return false; }, null); return true; })
        ));
    }

    // ================= PICKAXE =================
    static Forge.Blueprint pickaxe() {
        return new Forge.Blueprint("pickaxe", "Resonance Pickaxe", "Tools", Material.NETHERITE_PICKAXE, 7750,
            List.of(part(7751, 0, 1.0, 0.1, 1.1f), part(7752, 0, 0.1, 0, 0.9f)), List.of(
            ab("pick_strike", "Pick Strike", "Hard short strike.", 0, 2, 10, s -> melee(s, "pick_strike", 3.2, 60, 7, 0.4, 0.2)),
            ab("pick_tremor_sense", "Tremor Sense", "Glow every living thing within 24 blocks for 3s.", 6, 2, 200, s -> { Fx.ring(s.p.getLocation().add(0, 1, 0), 10, 40, Fx.WHITE);
                for (LivingEntity e : Abilities.radius(s, s.p.getLocation(), 24)) e.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 60, 0, true, false)); return true; }),
            ab("pick_seismic", "Seismic Pick", "Crack of force racing forward.", 10, 5, 100, s -> { Vector f = fl(s); Location o = s.p.getLocation();
                s.every(2, 16, t -> { Location c = o.clone().add(f.clone().multiply(2 + t * 0.7)); Fx.dust(c.clone().add(0, 0.3, 0), Fx.DEEP, 6, 0.4); for (LivingEntity e : Abilities.radius(s, c, 1.6)) s.hit(e, d(s, "pick_seismic", 6), new Vector(0, 0.5, 0)); return false; }, null); return true; }),
            ab("pick_stone_skin", "Stone Skin", "Resistance for 5s.", 10, 3, 240, s -> { potion(s, PotionEffectType.RESISTANCE, 100, 0); Fx.ring(s.p.getLocation().add(0, 1, 0), 1.2, 16, Fx.DEEP); return true; }),
            ab("pick_rock_throw", "Rock Throw", "Hurl a boulder that slows.", 9, 5, 90, s -> { Location f = s.p.getEyeLocation().add(eye(s));
                Abilities.shoot(s, f, eye(s), 1.3, 26, 1.0, d(s, "pick_rock_throw", 9), false, l -> Fx.dust(l, Fx.DEEP, 6, 0.2), l -> { Fx.burst(l, 1.5); for (LivingEntity e : Abilities.radius(s, l, 2)) e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1, true, false)); }); return true; }),
            ab("pick_vein_burst", "Vein Burst", "Three eruptions around your target.", 14, 8, 130, s -> { LivingEntity t = Scythe.sight(s, 18); if (t == null) return false;
                for (int i = 0; i < 3; i++) { double a = i * Math.PI * 2 / 3; areaHit(s, "pick_vein_burst", t.getLocation().add(Math.cos(a) * 2, 0, Math.sin(a) * 2), 2, 7, 0.6); } return true; }),
            ab("pick_cave_in", "Cave-In", "Rubble collapses on an area.", 18, 10, 200, s -> { Location c = Abilities.aim(s, 24);
                s.every(2, 20, t -> { Fx.dust(c.clone().add(0, 6 - t * 0.3, 0), Fx.DEEP, 12, 2); return false; }, () -> { areaHit(s, "pick_cave_in", c, 4, 10, 0.4); for (LivingEntity e : Abilities.radius(s, c, 4)) e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 50, 2, true, false)); }); return true; }),
            ab("pick_motherlode", "Motherlode", "Finisher: three crushing shock rings.", 45, 20, 340, s -> { Location c = s.p.getLocation(); Set<UUID> hit = new HashSet<>();
                s.every(4, 12, t -> { double r = 3 + t; Fx.ring(c.clone().add(0, 0.2, 0), r, (int) (r * 12), Fx.DEEP); for (LivingEntity e : Abilities.radius(s, c, r + 1)) if (hit.add(e.getUniqueId())) s.hit(e, d(s, "pick_motherlode", 18), new Vector(0, 0.9, 0)); return false; }, null); return true; })
        ));
    }

    // ================= DRILL =================
    static Forge.Blueprint drill() {
        return new Forge.Blueprint("drill", "Resonance Drill", "Tools", Material.NETHERITE_SHOVEL, 7760,
            List.of(part(7761, 0, 1.2, 0.2, 1.2f), part(7762, 0, 0.3, 0, 1.0f), part(7763, 0, -0.6, 0, 0.8f)), List.of(
            ab("drill_jab", "Drill Jab", "Sustained boring jab (6 ticks of damage).", 4, 3, 30, s -> { s.every(2, 12, t -> { for (LivingEntity e : Scythe.cone(s, 3.6, 40)) s.hit(e, d(s, "drill_jab", 2), null); Fx.spark(s.p.getEyeLocation().add(eye(s).multiply(2.5)), 3, 0.2); return false; }, null); return true; }),
            ab("drill_bore_thrust", "Bore Thrust", "Dash with the bit forward.", 12, 6, 90, s -> dashHit(s, "drill_bore_thrust", 6, 8)),
            ab("drill_spin_up", "Spin-Up", "Speed burst, then a boring line strike.", 10, 5, 120, s -> { potion(s, PotionEffectType.SPEED, 40, 2); s.every(10, 20, t -> { if (t == 10) Abilities.beam(s, s.p.getEyeLocation(), eye(s), 5, 0.7, d(s, "drill_spin_up", 9), false); return false; }, null); return true; }),
            ab("drill_shatter", "Shatter Shot", "Five-pellet shrapnel.", 10, 6, 90, s -> { for (int i = -2; i <= 2; i++) bolt(s, "drill_shatter", eye(s).rotateAroundY(Math.toRadians(i * 7)), 1.8, 14, 0.6, 3, false, Fx.PURPLE); return true; }),
            ab("drill_burrow_strike", "Burrow Strike", "Leap up and plunge point-first.", 14, 8, 140, s -> { s.fallGuardUntil = s.now() + 60; s.p.setVelocity(new Vector(0, 1.1, 0));
                s.every(1, 30, t -> { if (t == 8) s.p.setVelocity(new Vector(0, -2.0, 0)); if (t > 10 && s.p.isOnGround()) { areaHit(s, "drill_burrow_strike", s.p.getLocation(), 3, 11, 0.7); return true; } return false; }, null); return true; }),
            ab("drill_rotary", "Rotary Sweep", "Full rotary spin.", 14, 8, 150, s -> { spin(s, "drill_rotary", 20, 3.4, 3, 4); return true; }),
            ab("drill_vent", "Overheat Vent", "Vent steam: blasts foes and sheds 20 heat.", 0, 0, 220, s -> { s.heat = Math.max(0, s.heat - 20); areaHit(s, "drill_vent", s.p.getLocation().add(0, 1, 0), 5, 8, 0.5); Fx.sound(s.p.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 1.5f, 0.7f); return true; }),
            ab("drill_core_piercer", "Core Piercer", "Finisher: 1s sustained piercing beam.", 45, 22, 340, s -> {
                s.every(2, 20, t -> { Abilities.beam(s, Armour.reactor(s), eye(s), 20, 1.2, d(s, "drill_core_piercer", 4), false); return false; }, null); return true; })
        ));
    }

    static List<Forge.Blueprint> all() { return List.of(sword(), katana(), axe(), dagger(), crossbow(), shield(), claws(), staff(), pickaxe(), drill()); }
}
