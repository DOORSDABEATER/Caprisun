package com.des.legendary.orison;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.util.Vector;

import java.util.*;

/** MAX TRANSFORMATION — Ascendant Sovereign. Exactly 16 abilities, none shared with other forms. */
final class MaxForm {
    static final List<Ability> ROSTER = new ArrayList<>();
    private static void add(String id, String name, String desc, int cost, int heat, Ability.Cast c) { ROSTER.add(new Ability(id, name, desc, cost, heat, c)); }
    private static Vector look(Session s) { return s.p.getEyeLocation().getDirection(); }

    static {
        add("max_ascendant_burst", "Ascendant Burst", "Extreme-speed flight burst; shockwave trail shreds everything.", 25, 12, s -> {
            Vector dir = look(s).normalize();
            double dmg = Abilities.d(s, "max_ascendant_burst", 12);
            Set<UUID> hit = new HashSet<>();
            s.fallGuardUntil = s.now() + 80;
            Fx.sound(s.p.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 1.5f, 0.5f);
            s.every(1, 12, t -> {
                s.p.setVelocity(dir.clone().multiply(3.0));
                Location l = s.p.getLocation().add(0, 1, 0);
                Fx.discRing(l.clone().subtract(dir), dir, 2.2, 24, Fx.PURPLE); Fx.discRing(l.clone().subtract(dir.clone().multiply(1.6)), dir, 3.0, 30, Fx.WHITE);
                for (LivingEntity e : Abilities.radius(s, l, 3.2)) if (hit.add(e.getUniqueId())) s.hit(e, dmg, dir.clone().multiply(1.4).setY(0.5));
                return false;
            }, null);
            return 120;
        });

        add("max_harmonic_cannon", "Harmonic Cannon", "Massive resonance sphere; detonates in a wide blast.", 35, 20, s -> {
            Location from = Armour.reactor(s);
            Vector dir = Half.aimPoint(s).toVector().subtract(from.toVector());
            double dmg = Abilities.d(s, "max_harmonic_cannon", 18);
            Fx.sound(from, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.5f, 0.7f);
            Abilities.shoot(s, from, dir, 2.4, 60, 2.5, dmg, false,
                    l -> { Fx.dust(l, Fx.PURPLE, 10, 0.5); Fx.dust(l, Fx.WHITE, 4, 0.3); Fx.ring(l, 1.2, 14, Fx.DEEP); },
                    l -> { Fx.burst(l, 5); for (LivingEntity e : Abilities.radius(s, l, 5)) s.hit(e, 8, new Vector(0, 0.7, 0)); });
            return 200;
        });

        add("max_ring_lattice", "Triple Ring Lattice", "Generation, Harmonics and Discord rings fly out as piercing hoops.", 30, 15, s -> {
            Location eye = s.p.getEyeLocation();
            Vector dir = eye.getDirection();
            double dmg = Abilities.d(s, "max_ring_lattice", 9);
            for (int k = 0; k < 3; k++) {
                final int idx = k;
                s.every(6, 6 * (k + 1), t -> {
                    if (t < idx * 6) return false;
                    Fx.sound(eye, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1f, 0.8f + idx * 0.3f);
                    Abilities.shoot(s, s.p.getEyeLocation().add(dir.clone().multiply(1.5)), dir, 1.6, 36, 2.0, dmg, true,
                            l -> Fx.discRing(l, dir, 1.6 + idx * 0.3, 18, idx == 1 ? Fx.WHITE : Fx.PURPLE), l -> Fx.burst(l, 1.8));
                    return true;
                }, null);
            }
            return 180;
        });

        add("max_multi_forge", "Multi-Forge Barrage", "Forge four spectral blades at once and send each at a different target.", 28, 12, s -> {
            List<LivingEntity> tg = Abilities.targets(s, 35, 4);
            double dmg = Abilities.d(s, "max_multi_forge", 9);
            for (int i = 0; i < 4; i++) {
                final int idx = i;
                double a = i * Math.PI / 2;
                Location at = s.p.getLocation().add(Math.cos(a) * 1.8, 2.4, Math.sin(a) * 1.8);
                ItemDisplay pr = Abilities.prop(s, at, Material.NETHERITE_SWORD, 7350, 1.6f);
                Fx.spark(at, 8, 0.3);
                s.every(4, 4 * (i + 1) + 8, t -> {
                    if (t < 8 + idx * 4) return false;
                    if (pr == null) return true;
                    LivingEntity tgt = tg.isEmpty() ? null : tg.get(idx % tg.size());
                    Location from = pr.getLocation();
                    Vector dir = (tgt != null ? tgt.getLocation().add(0, 1, 0) : Abilities.aim(s, 35)).toVector().subtract(from.toVector());
                    Abilities.homing(s, from, dir, tgt, 1.6, dmg, 1.8, 60, l -> pr.teleport(l), () -> Abilities.drop(s, pr));
                    return true;
                }, () -> { /* props removed when their missile ends or the session is destroyed */ });
            }
            return 200;
        });

        add("max_remote_weapon", "Remote Weapon Control", "Plant a hovering blade that auto-slashes enemies for 6s.", 26, 10, s -> {
            if (s.remoteActive) return -1;
            Location at = Abilities.aim(s, 30).add(0, 2, 0);
            ItemDisplay blade = Abilities.prop(s, at, Material.NETHERITE_SWORD, 7351, 2.4f);
            if (blade == null) return -1;
            s.remoteActive = true;
            double dmg = Abilities.d(s, "max_remote_weapon", 6);
            Fx.burst(at, 2);
            s.every(10, 120, t -> {
                Location b = blade.getLocation();
                blade.teleport(b.clone().add(0, Math.sin(t * 0.3) * 0.15, 0).setDirection(new Vector(Math.cos(t * 0.5), 0, Math.sin(t * 0.5))));
                Fx.line(s.p.getLocation().add(0, 1.3, 0), b, 0.6, Fx.DEEP);
                Fx.ring(b, 5, 30, Fx.PURPLE);
                for (LivingEntity e : Abilities.radius(s, b, 5)) { s.hit(e, dmg, new Vector(0, 0.3, 0)); Fx.line(b, e.getLocation().add(0, 1, 0), 0.4, Fx.WHITE); }
                return false;
            }, () -> { s.remoteActive = false; Fx.burst(blade.getLocation(), 2); Abilities.drop(s, blade); });
            return 300;
        });

        add("max_fragment_formation", "Ascendant Formation", "Six upgraded fragments form a hex over the target and converge fire.", 30, 14, s -> {
            for (Location o : s.fragments.override) if (o != null) return -1;
            Location c = Abilities.aim(s, 35);
            double dmg = Abilities.d(s, "max_fragment_formation", 4);
            s.every(2, 40, t -> {
                for (int i = 0; i < 6; i++) {
                    double a = t * 0.15 + i * Math.PI / 3;
                    s.fragments.override[i] = c.clone().add(Math.cos(a) * 4, 6, Math.sin(a) * 4);
                    Fx.line(s.fragments.override[i], c, 0.5, i % 2 == 0 ? Fx.PURPLE : Fx.WHITE);
                }
                Fx.ring(c.clone().add(0, 0.1, 0), 3, 24, Fx.DEEP);
                if (t % 4 == 0) for (LivingEntity e : Abilities.radius(s, c, 3.2)) s.hit(e, dmg, new Vector(0, 0.25, 0));
                return false;
            }, () -> { for (int i = 0; i < 6; i++) s.fragments.override[i] = null; });
            return 260;
        });

        add("max_fragment_cyclone", "Fragment Cyclone", "Fragments become a blender orbiting you at high speed.", 24, 12, s -> {
            for (Location o : s.fragments.override) if (o != null) return -1;
            double dmg = Abilities.d(s, "max_fragment_cyclone", 5);
            s.every(2, 60, t -> {
                Location c = s.p.getLocation().add(0, 1.2, 0);
                for (int i = 0; i < 6; i++) {
                    double a = t * 0.5 + i * Math.PI / 3;
                    s.fragments.override[i] = c.clone().add(Math.cos(a) * 4, Math.sin(t * 0.2 + i) * 0.8, Math.sin(a) * 4);
                    Fx.dust(s.fragments.override[i], Fx.PURPLE, 4, 0.2);
                }
                if (t % 6 == 0) for (LivingEntity e : Abilities.radius(s, c, 4.5)) {
                    s.hit(e, dmg, null);
                    if (!Session.boss(e)) e.setVelocity(e.getVelocity().add(c.toVector().subtract(e.getLocation().toVector()).normalize().multiply(0.25)));
                }
                return false;
            }, () -> { for (int i = 0; i < 6; i++) s.fragments.override[i] = null; });
            return 240;
        });

        add("max_layered_barrier", "Layered Barrier", "Three concentric resonance layers absorb a pool of damage.", 30, 8, s -> {
            s.barrierUntil = s.now() + 100;
            s.barrierHp = s.m.cfg.getDouble("abilities.max_layered_barrier.pool", 60);
            Fx.sound(s.p.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.4f, 0.7f);
            s.every(2, 100, t -> {
                if (s.barrierHp <= 0) { Fx.burst(s.p.getLocation().add(0, 1, 0), 4); return true; }
                Location c = s.p.getLocation().add(0, 1, 0);
                int layers = (int) Math.ceil(s.barrierHp / 20.0);
                for (int l = 0; l < layers; l++) {
                    Fx.ring(c.clone().add(0, Math.sin(t * 0.2 + l) * 0.6, 0), 1.6 + l * 0.7, 24, l == 1 ? Fx.WHITE : Fx.PURPLE);
                    Fx.discRing(c, new Vector(Math.cos(t * 0.1 + l), 0.3, Math.sin(t * 0.1 + l)), 1.6 + l * 0.7, 20, Fx.DEEP);
                }
                return false;
            }, () -> { s.barrierUntil = 0; s.barrierHp = 0; });
            return 360;
        });

        add("max_counterpulse", "Ascendant Counterpulse", "4s: soak 30% of damage and return it doubled in a triple-ring blast.", 12, 5, s -> {
            Abilities.counter(s, 80, 2.0, 10, 60);
            return 360;
        });

        add("max_reactor_lance", "Reactor Lance", "Fifty-block reactor beam. Pierces everything in line.", 40, 28, s -> {
            Fx.sound(s.p.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 1.5f, 0.5f);
            Location end = Abilities.beam(s, Armour.reactor(s), look(s), 50, 1.4, Abilities.d(s, "max_reactor_lance", 20), false);
            Fx.burst(end, 4);
            return 300;
        });

        add("max_gravity_collapse", "Gravity Collapse", "Giant gravity well; collapses in a crushing blast.", 32, 16, s -> {
            Location c = Abilities.aim(s, 30);
            double dmg = Abilities.d(s, "max_gravity_collapse", 12);
            Fx.sound(c, Sound.ENTITY_ENDER_EYE_DEATH, 1.5f, 0.4f);
            s.every(2, 50, t -> {
                Fx.ring(c.clone().add(0, 0.2, 0), 9 - t * 0.12, 40, Fx.PURPLE); Fx.dust(c.clone().add(0, 1.5, 0), Fx.DEEP, 10, 1.0);
                for (LivingEntity e : Abilities.radius(s, c, 9)) if (!Session.boss(e))
                    e.setVelocity(e.getVelocity().multiply(0.4).add(c.toVector().subtract(e.getLocation().toVector()).normalize().multiply(0.5)));
                return false;
            }, () -> { Fx.burst(c.clone().add(0, 0.5, 0), 6); for (LivingEntity e : Abilities.radius(s, c, 6)) s.hit(e, dmg, new Vector(0, 0.9, 0)); });
            return 280;
        });

        add("max_resonance_storm", "Resonance Storm", "Twenty resonance strikes rain across a 12-block field.", 35, 18, s -> {
            Location c = s.p.getLocation();
            double dmg = Abilities.d(s, "max_resonance_storm", 6);
            Random r = new Random();
            Fx.sound(c, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1f, 0.6f);
            s.every(3, 60, t -> {
                double a = r.nextDouble() * Math.PI * 2, d = r.nextDouble() * 12;
                Location p = c.clone().add(Math.cos(a) * d, 0, Math.sin(a) * d);
                p.setY(c.getWorld().getHighestBlockYAt(p) + 1);
                for (double y = 0; y < 14; y += 0.5) Fx.dust(p.clone().add(0, y, 0), y % 1.5 < 0.5 ? Fx.WHITE : Fx.PURPLE, 2, 0.15);
                Fx.burst(p, 2.5);
                for (LivingEntity e : Abilities.radius(s, p, 2.5)) s.hit(e, dmg, new Vector(0, 0.5, 0));
                return false;
            }, null);
            return 320;
        });

        add("max_phase_rush", "Phase Rush", "Twenty-block blink that cuts through everything in the path.", 22, 10, s -> {
            Location start = s.p.getLocation(), last = start.clone();
            Vector dir = s.p.getEyeLocation().getDirection().setY(0).normalize();
            Set<LivingEntity> hit = new LinkedHashSet<>();
            for (double d = 0; d < 20; d += 0.5) {
                Location n = last.clone().add(dir.clone().multiply(0.5));
                if (!n.getBlock().isPassable() || !n.clone().add(0, 1, 0).getBlock().isPassable()) break;
                last = n;
                for (LivingEntity e : n.getWorld().getNearbyLivingEntities(n.clone().add(0, 1, 0), 1.6)) if (s.valid(e)) hit.add(e);
            }
            if (last.distanceSquared(start) < 4) return -1;
            Fx.line(start.clone().add(0, 1, 0), last.clone().add(0, 1, 0), 0.25, Fx.WHITE);
            Fx.line(start.clone().add(0, 0.5, 0), last.clone().add(0, 0.5, 0), 0.25, Fx.PURPLE);
            last.setYaw(start.getYaw()); last.setPitch(start.getPitch());
            s.p.teleport(last);
            for (LivingEntity e : hit) s.hit(e, Abilities.d(s, "max_phase_rush", 12), dir.clone().multiply(0.4).setY(0.3));
            Fx.sound(last, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.5f);
            return 160;
        });

        add("max_missile_swarm", "Ascendant Missile Swarm", "Sixteen homing missiles across up to six threats.", 34, 18, s -> {
            List<LivingEntity> tg = Abilities.targets(s, 40, 6);
            double dmg = Abilities.d(s, "max_missile_swarm", 5);
            int[] n = {0};
            s.every(2, 32, t -> {
                LivingEntity tgt = tg.isEmpty() ? null : tg.get(n[0] % tg.size());
                Location from = Armour.shoulder(s, n[0] % 2 == 0);
                Abilities.homing(s, from, look(s).add(new Vector(n[0] % 2 == 0 ? 0.6 : -0.6, 0.9, 0)).normalize(), tgt, 1.1, dmg, 2.4, 80);
                if (n[0]++ % 4 == 0) Fx.sound(from, Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.8f, 0.8f);
                return false;
            }, null);
            return 240;
        });

        add("max_seismic_slam", "Seismic Slam", "Dive-bomb the ground: crater shockwave.", 28, 14, s -> {
            double dmg = Abilities.d(s, "max_seismic_slam", 18);
            s.fallGuardUntil = s.now() + 80;
            s.p.setVelocity(new Vector(0, s.p.isOnGround() ? 0.9 : -2.2, 0));
            s.every(1, 40, t -> {
                Fx.dust(s.p.getLocation(), Fx.PURPLE, 6, 0.4);
                if (t >= 3 && s.p.isOnGround()) {
                    Location c = s.p.getLocation();
                    Fx.sound(c, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.5f);
                    for (int k = 0; k < 3; k++) Fx.ring(c.clone().add(0, 0.2 * k, 0), 3 + k * 3, 40, k == 1 ? Fx.WHITE : Fx.PURPLE);
                    Fx.burst(c, 6);
                    for (LivingEntity e : Abilities.radius(s, c, 9)) s.hit(e, dmg, new Vector(0, 1.0, 0));
                    return true;
                }
                if (t == 8 && !s.p.isOnGround() && s.p.getVelocity().getY() > -1) s.p.setVelocity(new Vector(0, -2.2, 0));
                return false;
            }, null);
            return 220;
        });

        add("max_ring_boomerang", "Discord Ring Boomerang", "Hurl the Discord ring; it cuts out and cuts back.", 26, 12, s -> {
            Location eye = s.p.getEyeLocation();
            Vector dir = eye.getDirection();
            double dmg = Abilities.d(s, "max_ring_boomerang", 9);
            Location[] last = {eye.clone()};
            Fx.sound(eye, Sound.ITEM_TRIDENT_THROW, 1f, 0.5f);
            Abilities.shoot(s, eye.clone().add(dir.clone().multiply(1.5)), dir, 1.4, 22, 2.0, dmg, true,
                    l -> { last[0] = l.clone(); Fx.discRing(l, dir, 2.0, 22, Fx.DEEP); Fx.discRing(l, dir, 1.4, 16, Fx.PURPLE); }, l -> Fx.burst(l, 1.5),
                    () -> {
                        Vector back = s.p.getEyeLocation().toVector().subtract(last[0].toVector());
                        Abilities.shoot(s, last[0], back, 1.6, 26, 2.0, dmg, true, l -> Fx.discRing(l, back, 2.0, 22, Fx.WHITE), l -> Fx.burst(l, 1.5));
                    });
            return 200;
        });
    }
}
