package com.des.legendary.orison;

import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Projectile;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.*;

/**
 * FULL, MAX and SECRET ultimates. All are real-time (player keeps control, no camera lock) and all damage is
 * server-side via Session.hit (boss-capped). VFX never gates damage.
 */
final class Ultimates {

    /** FULL — THE LAST CHORD: ZERO HOUR. Six anchors -> rings sync -> reactor converges -> sustained steerable beam -> shockwave. */
    static void zeroHour(Session s) {
        Location c = s.p.getLocation().clone();
        double beam = s.m.cfg.getDouble("ultimates.full.beam-damage", 10), shock = s.m.cfg.getDouble("ultimates.full.shockwave-damage", 30);
        double R = 14;
        for (int i = 0; i < 6; i++) { double a = i * Math.PI / 3; s.fragments.override[i] = c.clone().add(Math.cos(a) * R, 4, Math.sin(a) * R); }
        Fx.sound(c, Sound.BLOCK_BEACON_POWER_SELECT, 2f, 0.5f);
        s.every(2, 40, t -> {                                   // phase 1: anchors + expanding rings
            Location core = Armour.reactor(s);
            for (int i = 0; i < 6; i++) { Location a = s.fragments.override[i]; Fx.line(a, core, 0.6, i % 2 == 0 ? Fx.PURPLE : Fx.WHITE); Fx.ring(a, 0.8, 12, Fx.PURPLE); }
            for (int k = 0; k < 3; k++) Fx.ring(core.clone().add(0, (k - 1) * 0.5, 0), 1.0 + k * 0.5 + t * 0.03, 24, k == 1 ? Fx.WHITE : Fx.PURPLE);
            if (t % 8 == 0) Fx.sound(core, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1.5f, 0.5f + t * 0.03f);
            return false;
        }, () -> s.every(2, 60, t -> {                          // phase 2: the chord — beam follows your aim
            Location from = Armour.reactor(s);
            Abilities.beam(s, from, s.p.getEyeLocation().getDirection(), 45, 2.2, t % 6 == 0 ? beam : 0, false);
            for (int i = 0; i < 6; i++) Fx.line(s.fragments.override[i], from, 0.7, Fx.PURPLE);
            if (t % 10 == 0) Fx.sound(from, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.5f, 0.6f);
            return false;
        }, () -> {                                              // phase 3: shockwave, fragments return
            Location d = s.p.getLocation().add(0, 0.2, 0);
            Fx.sound(d, Sound.ENTITY_GENERIC_EXPLODE, 2f, 0.5f);
            for (LivingEntity e : Abilities.radius(s, d, 16)) s.hit(e, Math.max(8, shock * (1 - e.getLocation().distance(d) / 20)), e.getLocation().toVector().subtract(d.toVector()).setY(0).normalize().multiply(1.8).setY(0.6));
            s.every(1, 14, t -> { double r = 1 + t * 1.2; Fx.ring(d, r, (int) (r * 14), Fx.PURPLE); Fx.ring(d.clone().add(0, 0.6, 0), r * 0.8, (int) (r * 10), Fx.WHITE); return false; },
                    () -> { for (int i = 0; i < 6; i++) s.fragments.override[i] = null; });
        }));
    }

    /** MAX — THE SOVEREIGN EXTINCTION. Sky array + six pillars + 22-block layered detonation + collapsing field. Targeted at where you look. */
    static void sovereignExtinction(Session s) {
        Location g = Abilities.aim(s, 40);
        Location sky = g.clone().add(0, 18, 0);
        double dmg = s.m.cfg.getDouble("ultimates.max.damage", 50), rad = s.m.cfg.getDouble("ultimates.max.radius", 22);
        Fx.sound(g, Sound.ENTITY_WITHER_SPAWN, 2f, 0.5f);
        s.every(2, 50, t -> {                                   // phase 1: the array forms overhead
            for (int i = 0; i < 6; i++) {
                double a = t * 0.12 + i * Math.PI / 3;
                s.fragments.override[i] = sky.clone().add(Math.cos(a) * 7, Math.sin(t * 0.3 + i) * 0.5, Math.sin(a) * 7);
                Fx.line(s.fragments.override[i], sky, 0.8, Fx.DEEP);
            }
            for (int k = 0; k < 3; k++) Fx.discRing(sky, new Vector(Math.sin(t * 0.05 + k), 1, Math.cos(t * 0.05 + k * 2)), 5 + k * 2.2 + t * 0.04, 48, k == 1 ? Fx.WHITE : Fx.PURPLE);
            Fx.ring(g.clone().add(0, 0.1, 0), rad * Math.min(1, t / 50.0), 60, Fx.DEEP);
            if (t % 10 == 0) Fx.sound(g, Sound.BLOCK_BEACON_AMBIENT, 2f, 0.5f + t * 0.02f);
            return false;
        }, () -> s.every(2, 20, t -> {                          // phase 2: six pillars drop and sweep
            for (int i = 0; i < 6; i++) {
                double a = i * Math.PI / 3 + t * 0.1;
                Location p = g.clone().add(Math.cos(a) * 7, 0, Math.sin(a) * 7);
                for (double y = 0; y < 18; y += 0.5) Fx.dust(p.clone().add(0, y, 0), y % 2 < 0.5 ? Fx.WHITE : Fx.PURPLE, 2, 0.2);
                if (t % 4 == 0) for (LivingEntity e : Abilities.radius(s, p, 3)) s.hit(e, 10, new Vector(0, 0.6, 0));
            }
            Fx.sound(g, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 0.5f);
            return false;
        }, () -> {                                              // phase 3: extinction
            Fx.sound(g, Sound.ENTITY_GENERIC_EXPLODE, 3f, 0.4f);
            Fx.sound(g, Sound.ENTITY_WARDEN_SONIC_BOOM, 3f, 0.5f);
            for (LivingEntity e : Abilities.radius(s, g, rad)) {
                double d = e.getLocation().distance(g);
                s.hit(e, Math.max(15, dmg * (1 - d / (rad + 6))), e.getLocation().toVector().subtract(g.toVector()).setY(0).normalize().multiply(2.2).setY(0.9));
            }
            s.every(1, 18, t -> {
                double r = 1 + t * (rad / 18.0);
                for (int k = 0; k < 3; k++) Fx.ring(g.clone().add(0, 0.3 + k * 1.2, 0), r * (1 - k * 0.15), (int) (r * 16), k == 1 ? Fx.WHITE : k == 2 ? Fx.DEEP : Fx.PURPLE);
                for (double y = 0; y < 30; y += 2) Fx.dust(g.clone().add(0, y, 0), Fx.PURPLE, 6, Math.max(0.5, 4 - y * 0.1));
                return false;
            }, () -> s.every(10, 60, t -> {                     // lingering collapse field
                Fx.ring(g.clone().add(0, 0.2, 0), 12 - t * 0.12, 40, Fx.DEEP);
                for (LivingEntity e : Abilities.radius(s, g, 12)) {
                    s.hit(e, 4, null);
                    if (!Session.boss(e)) e.setVelocity(e.getVelocity().add(g.toVector().subtract(e.getLocation().toVector()).normalize().multiply(0.3)));
                }
                return false;
            }, () -> { for (int i = 0; i < 6; i++) s.fragments.override[i] = null; }));
        }));
    }

    /**
     * SECRET UNIVERSAL ULTIMATE — THE UNSTRUCK NOTE. Works in every form.
     * Discovery: use each of the four form ultimates once (config secret.required-ultimates). Activation: Discord Overdrive
     * active + Sneak + /orison ultimate (permission orison.secret). Hidden from GUI/help/tab-complete.
     * Mechanic: SILENCE. Everything hostile within 20 blocks loses awareness (mobs) / is rooted (players) and every hostile
     * projectile is erased for 4s. All damage you deal to silenced targets is BANKED, then replayed on them at once x1.5 + 20,
     * while you are fully restored (energy 100, heat 0) and Overdrive is extended. Uses core, rings, six fragments, armour.
     */
    static void unstruckNote(Session s) {
        Location c = s.p.getLocation().clone();
        double R = 20;
        s.silenceBank = 0;
        s.silenced.clear();
        for (LivingEntity e : Abilities.radius(s, c, R)) {
            s.silenced.add(e.getUniqueId());
            if (e instanceof Mob m && !Session.boss(e)) { m.setAware(false); s.unaware.add(m); }
            e.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 90, 6, true, false));
            e.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, 90, 0, true, false));
        }
        for (int i = 0; i < 6; i++) { double a = i * Math.PI / 3; s.fragments.override[i] = c.clone().add(Math.cos(a) * 9, 2.5, Math.sin(a) * 9); }
        Fx.sound(c, Sound.BLOCK_END_PORTAL_SPAWN, 2f, 0.5f);
        s.every(2, 80, t -> {
            Location core = Armour.reactor(s);
            for (int i = 0; i < 6; i++) Fx.line(s.fragments.override[i], core, 0.8, Fx.DEEP);
            for (int k = 0; k < 3; k++) Fx.ring(c.clone().add(0, 0.2 + k * 0.8, 0), R * (1 - t / 100.0) , 60, k == 1 ? Fx.WHITE : Fx.PURPLE);
            for (Projectile pr : c.getWorld().getNearbyEntitiesByType(Projectile.class, c, R)) if (!s.p.equals(pr.getShooter())) { Fx.spark(pr.getLocation(), 4, 0.1); pr.remove(); }
            return false;
        }, () -> {
            Fx.sound(c, Sound.ENTITY_GENERIC_EXPLODE, 3f, 0.3f);
            double bank = s.silenceBank;
            for (UUID id : new ArrayList<>(s.silenced)) {
                org.bukkit.entity.Entity ent = org.bukkit.Bukkit.getEntity(id);
                if (ent instanceof LivingEntity e && s.valid(e)) {
                    Fx.burst(e.getLocation().add(0, 1, 0), 3);
                    s.silenced.remove(id);                      // stop banking before the replay
                    s.hit(e, Math.min(120, bank * 1.5 + 20), new Vector(0, 0.8, 0));
                }
            }
            s.restoreAwareness();
            s.energy = 100; s.heat = 0; s.overloaded = false;
            s.overdriveUntil = Math.max(s.overdriveUntil, s.now() + 100);
            for (int k = 0; k < 4; k++) Fx.ring(c.clone().add(0, 0.2 * k, 0), 4 + k * 5, 60, k % 2 == 0 ? Fx.PURPLE : Fx.WHITE);
            for (int i = 0; i < 6; i++) s.fragments.override[i] = null;
        });
    }
}
