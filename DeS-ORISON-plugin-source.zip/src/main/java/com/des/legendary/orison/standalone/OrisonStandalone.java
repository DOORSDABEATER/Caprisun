package com.des.legendary.orison.standalone;

import com.des.legendary.orison.OrisonModule;
import org.bukkit.plugin.java.JavaPlugin;

/** OPTIONAL test entrypoint. Built only with `mvn -Pstandalone package`. Do NOT ship this inside the DeS plugin. */
public final class OrisonStandalone extends JavaPlugin {
    private OrisonModule orison;
    @Override public void onEnable() { orison = new OrisonModule(this); orison.enable(); }
    @Override public void onDisable() { if (orison != null) orison.disable(); }
}
