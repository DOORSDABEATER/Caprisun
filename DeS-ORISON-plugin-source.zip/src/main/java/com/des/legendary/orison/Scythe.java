package com.des.legendary.orison;

import org.bukkit.*;
import org.bukkit.entity.LivingEntity;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.*;

/** Scythe blueprint + its exactly-eight-ability moveset. Model ids 7301-7303 (blade/shaft/pommel). */
final class Scythe {
    static Forge.Blueprint blueprint() {
        return new Forge.Blueprint("scythe", "Resonance Scythe", "Scythes", Material.NETHERITE_HOE, 7300,
                List.of(new Forge.Part(7301, new Vector(0, 1.0, 0.15), 1.1f),
                        new Forge.Part(7302, new Vector(0, 0.2, 0), 1.0f),
                        new Forge.Part(7303, new Vector(0, -0.7, 0), 0.8f)),
                moveset());
    }

    static List<LivingEntity> cone(Session s, double range, double deg) {
        Location e = s.p.getEyeLocation();
        Vector f = e.getDirection().normalize();
        double cos = Math.cos(Math.toRadians(deg / 2));
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity t : e.getWorld().getNearbyLivingEntities(e, range)) {
            if (!s.valid(t)) continue;
            Vector to = t.getLocation().add(0, t.getHeight() / 2, 0).toVector().subtract(e.toVector());
            if (to.lengthSquared() < 1e-4 || to.normalize().dot(f) >= cos) out.add(t);
        }
        return out;
    }

    static void arc(Session s, Vector f, double from, double to, double r0, double r1) {
        Location o = s.p.getLocation().add(0, 1.2, 0);
        for (double a = from; a < to; a += 5)
            for (double r = r0; r <= r1; r += 0.6)
                Fx.dust(o.clone().add(f.clone().rotateAroundY(Math.toRadians(a)).multiply(r)), r > r1 - 0.5 ? Fx.WHITE : Fx.PURPLE, 1, 0);
    }

    static LivingEntity sight(Session s, double range) {
        Location eye = s.p.getEyeLocation();
        RayTraceResult r = eye.getWorld().rayTraceEntities(eye, eye.getDirection(), range, 0.7, e -> e instanceof LivingEntity le && s.valid(le));
        return r == null ? null : (LivingEntity) r.getHitEntity();
    }

    static List<Ability> moveset() {
        List<Ability> l = new ArrayList<>();

        l.add(new Ability("scythe_reaping_arc", "Reaping Arc", "Wide crescent sweep in front of you.", 0, 3, s -> {
            Vector f = Abilities.flat(s.p.getEyeLocation().getDirection());
            double dmg = Abilities.d(s, "scythe_reaping_arc", 7);
            Fx.sound(s.p.getLocation(), Sound.ITEM_TRIDENT_THROW, 1f, 0.6f);
            s.every(1, 4, t -> { arc(s, f, -80 + t * 40, -40 + t * 40, 2.6, 4.4); return false; }, null);
            for (LivingEntity t : cone(s, 4.6, 160)) s.hit(t, dmg, f.clone().multiply(0.5).setY(0.25));
            return 12;
        }));

        l.add(new Ability("scythe_soul_hook", "Soul Hook", "Chain-hook a target and drag it to you.", 8, 4, s -> {
            LivingEntity t = sight(s, 14);
            if (t == null) return -1;
            Location from = s.p.getEyeLocation();
            s.every(1, 6, k -> { Fx.line(from.clone().add(0, -0.3, 0), t.getLocation().add(0, 1, 0), 0.4, Fx.DEEP); return false; }, null);
            Vector pull = s.p.getLocation().toVector().subtract(t.getLocation().toVector()).normalize().multiply(1.3).setY(0.35);
            s.hit(t, Abilities.d(s, "scythe_soul_hook", 4), Session.boss(t) ? null : pull);
            t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 1, true, false));
            Fx.sound(from, Sound.BLOCK_CHAIN_BREAK, 1f, 0.7f);
            return 140;
        }));

        l.add(new Ability("scythe_crescent_wave", "Crescent Wave", "Piercing crescent of resonance flies forward.", 10, 6, s -> {
            Location e = s.p.getEyeLocation();
            Vector dir = e.getDirection();
            Vector side = dir.clone().crossProduct(new Vector(0, 1, 0));
            if (side.lengthSquared() < 1e-4) side = new Vector(1, 0, 0);
            Vector sd = side.normalize();
            Abilities.shoot(s, e.clone().add(dir.clone().multiply(1.2)), dir, 1.3, 22, 1.4, Abilities.d(s, "scythe_crescent_wave", 8), true, loc -> {
                for (double o = -1.6; o <= 1.6; o += 0.4)
                    Fx.dust(loc.clone().add(sd.clone().multiply(o)).add(0, 0.5 * (1 - Math.abs(o) / 1.6), 0), Math.abs(o) > 1.2 ? Fx.WHITE : Fx.PURPLE, 1, 0);
            }, loc -> Fx.burst(loc, 1.4));
            Fx.sound(e, Sound.ENTITY_PHANTOM_SWOOP, 1f, 0.5f);
            return 80;
        }));

        l.add(new Ability("scythe_harvest_spin", "Harvest Spin", "Sustained spin — hits everything around you.", 14, 8, s -> {
            double dmg = Abilities.d(s, "scythe_harvest_spin", 4);
            Fx.sound(s.p.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_3, 1f, 0.8f);
            s.every(2, 30, t -> {
                Vector f = new Vector(1, 0, 0).rotateAroundY(Math.toRadians(t * 24));
                for (int k = 0; k < 3; k++) arc(s, f.clone().rotateAroundY(Math.toRadians(k * 120)), 0, 30, 2.2, 4.2);
                if (t % 10 == 0) for (LivingEntity e : Abilities.radius(s, s.p.getLocation(), 4.2))
                    s.hit(e, dmg, e.getLocation().toVector().subtract(s.p.getLocation().toVector()).setY(0).normalize().multiply(0.4).setY(0.2));
                return false;
            }, null);
            return 140;
        }));

        l.add(new Ability("scythe_gravetide_slam", "Gravetide Slam", "Leap, then crash down in a shockwave.", 18, 10, s -> {
            s.fallGuardUntil = s.now() + 80;
            s.p.setVelocity(Abilities.flat(s.p.getLocation().getDirection()).multiply(0.7).setY(1.1));
            double dmg = Abilities.d(s, "scythe_gravetide_slam", 10);
            s.every(1, 40, t -> {
                Fx.dust(s.p.getLocation().add(0, 0.3, 0), Fx.PURPLE, 4, 0.25);
                if (t >= 6 && s.p.isOnGround()) {
                    Location c = s.p.getLocation();
                    Fx.burst(c, 5);
                    Fx.sound(c, Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.7f);
                    for (LivingEntity e : Abilities.radius(s, c, 5)) s.hit(e, dmg, new Vector(0, 0.9, 0));
                    return true;
                }
                return false;
            }, null);
            return 200;
        }));

        l.add(new Ability("scythe_phantom_cut", "Phantom Cut", "Blink through enemies, cutting each once.", 12, 6, s -> {
            Location start = s.p.getLocation(), cur = start.clone();
            Vector dir = s.p.getEyeLocation().getDirection().setY(0.0).normalize();
            Set<LivingEntity> hit = new LinkedHashSet<>();
            double dmg = Abilities.d(s, "scythe_phantom_cut", 8);
            Location last = cur.clone();
            for (double dist = 0; dist < 7; dist += 0.5) {
                Location n = cur.clone().add(dir.clone().multiply(0.5));
                if (!n.getBlock().isPassable() || !n.clone().add(0, 1, 0).getBlock().isPassable()) break;
                cur = n; last = n.clone();
                for (LivingEntity e : n.getWorld().getNearbyLivingEntities(n.clone().add(0, 1, 0), 1.2)) if (s.valid(e)) hit.add(e);
            }
            if (last.distanceSquared(start) < 1) return -1;
            Fx.line(start.clone().add(0, 1, 0), last.clone().add(0, 1, 0), 0.3, Fx.WHITE);
            Fx.line(start.clone().add(0, 0.6, 0), last.clone().add(0, 0.6, 0), 0.3, Fx.PURPLE);
            last.setYaw(s.p.getLocation().getYaw()); last.setPitch(s.p.getLocation().getPitch());
            s.p.teleport(last);
            for (LivingEntity e : hit) s.hit(e, dmg, dir.clone().multiply(0.3).setY(0.2));
            Fx.sound(last, Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.5f);
            return 120;
        }));

        l.add(new Ability("scythe_reap_mark", "Reap Mark", "Mark a target; recast within 5s to detonate the mark.", 6, 4, s -> {
            int now = s.now();
            if (s.mark != null && now < s.markUntil) {
                LivingEntity t = (LivingEntity) Bukkit.getEntity(s.mark);
                s.mark = null;
                if (t != null && s.valid(t)) {
                    Location c = t.getLocation().add(0, 1, 0);
                    Fx.burst(c, 3);
                    s.hit(t, Abilities.d(s, "scythe_reap_mark", 14), new Vector(0, 0.5, 0));
                    for (LivingEntity e : Abilities.radius(s, c, 3)) if (e != t) s.hit(e, 5, null);
                    return 20;
                }
            }
            LivingEntity t = sight(s, 24);
            if (t == null) return -1;
            s.mark = t.getUniqueId();
            s.markUntil = now + 100;
            Fx.sound(t.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.8f);
            s.every(5, 100, k -> {
                if (!t.isValid() || s.mark == null || !s.mark.equals(t.getUniqueId())) return true;
                Fx.ring(t.getLocation().add(0, t.getHeight() + 0.5, 0), 0.4, 10, Fx.PURPLE);
                Fx.dust(t.getLocation().add(0, t.getHeight() + 0.9, 0), Fx.WHITE, 2, 0.05);
                return false;
            }, null);
            return 20;
        }));

        l.add(new Ability("scythe_eclipse_harvest", "Eclipse Harvest", "Finisher: triple eclipse arc, bonus damage to the wounded.", 50, 22, s -> {
            Vector f = Abilities.flat(s.p.getEyeLocation().getDirection());
            double dmg = Abilities.d(s, "scythe_eclipse_harvest", 12), cap = s.m.cfg.getDouble("abilities.scythe_eclipse_harvest.missing-health-cap", 20);
            Fx.sound(s.p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.6f, 1.8f);
            s.every(2, 6, t -> {
                arc(s, f, -100, 100, 2 + t * 0.4, 5 + t * 0.4);
                Fx.ring(s.p.getLocation().add(0, 1.2, 0), 3 + t, 28, Fx.DEEP);
                return false;
            }, null);
            for (LivingEntity t : cone(s, 8, 200)) {
                @SuppressWarnings("deprecation") double missing = Math.min(cap, (t.getMaxHealth() - t.getHealth()) * 0.25);
                s.hit(t, dmg + missing, f.clone().multiply(0.9).setY(0.4));
                Fx.burst(t.getLocation().add(0, 1, 0), 1.5);
            }
            return 400;
        }));

        return l;
    }
}
