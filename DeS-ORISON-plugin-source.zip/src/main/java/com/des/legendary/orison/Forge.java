package com.des.legendary.orison;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.*;

/**
 * Matter Manipulation. Forging is FREE: nothing in this class reads or changes energy, heat, cooldowns or inventory.
 * The weapon exists only as display entities (no ItemStack is ever given), so it cannot be duplicated or stolen.
 * A blueprint is only registrable with exactly 8 abilities -> unimplemented weapons are simply not in the catalogue.
 */
final class Forge {
    record Part(int model, Vector off, float scale) {}
    record Blueprint(String id, String name, String category, Material icon, int iconModel, List<Part> parts, List<Ability> moveset) {}

    final Map<String, Blueprint> catalogue = new LinkedHashMap<>();
    private final Random rnd = new Random();

    Forge() { register(Scythe.blueprint()); register(Weapons.hammer()); register(Weapons.spear()); register(Weapons.bow()); for (Blueprint b : Weapons2.all()) register(b); }

    void register(Blueprint b) {
        if (b.moveset().size() != 8) throw new IllegalStateException("Blueprint " + b.id() + " needs exactly 8 abilities");
        catalogue.put(b.id(), b);
    }

    // ---- placement: weapon frame follows the player's right hand ----
    private Location hand(Session s, Part p) {
        Location l = s.p.getLocation();
        double yaw = Math.toRadians(l.getYaw());
        Vector fwd = new Vector(-Math.sin(yaw), 0, Math.cos(yaw)), right = new Vector(-Math.cos(yaw), 0, -Math.sin(yaw));
        Location out = l.clone().add(fwd.clone().multiply(0.5 + p.off().getZ())).add(right.clone().multiply(0.5 + p.off().getX())).add(0, 1.0 + p.off().getY(), 0);
        out.setPitch(0);
        return out;
    }

    boolean forge(Session s, String id) {
        Blueprint b = catalogue.get(id.toLowerCase(Locale.ROOT));
        if (b == null) return false;
        dismiss(s, false);
        s.m.voice.say(s, "forge");
        Location eye = s.p.getEyeLocation();
        List<ItemDisplay> parts = new ArrayList<>();
        List<Location> starts = new ArrayList<>();
        for (Part p : b.parts()) {
            Location st = eye.clone().add(eye.getDirection().multiply(2.2)).add((rnd.nextDouble() - .5) * 2.4, (rnd.nextDouble() - .5) * 1.6, (rnd.nextDouble() - .5) * 2.4);
            starts.add(st);
            parts.add(spawn(st, p));
        }
        s.weaponParts = parts;
        Fx.sound(eye, Sound.BLOCK_ANVIL_USE, 0.6f, 1.9f);
        Fx.sound(eye, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 1f, 1.2f);
        s.every(1, 24, t -> {
            if (s.weaponParts != parts) return true;                 // switched / dismissed mid-forge
            double k = 1 - Math.pow(1 - (t + 1) / 24.0, 3);
            for (int i = 0; i < parts.size(); i++) {
                ItemDisplay d = parts.get(i);
                if (!d.isValid()) continue;
                Location tgt = hand(s, b.parts().get(i));
                Location cur = starts.get(i).clone().add(tgt.clone().subtract(starts.get(i)).toVector().multiply(k));
                cur.setYaw(tgt.getYaw() + (float) ((1 - k) * 360));
                d.teleport(cur);
                Fx.dust(cur, Fx.PURPLE, 2, 0.1);
                if (t % 4 == 0) Fx.spark(cur, 1, 0.1);
            }
            return false;
        }, () -> {
            if (s.weaponParts != parts) return;
            s.weapon = b; s.sel = 0;
            Location h = hand(s, b.parts().get(0));
            Fx.burst(h, 1.5);
            Fx.sound(h, Sound.BLOCK_ANVIL_LAND, 0.7f, 1.6f);
        });
        return true;
    }

    private ItemDisplay spawn(Location at, Part p) {
        ItemStack it = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = it.getItemMeta();
        meta.setCustomModelData(p.model());
        it.setItemMeta(meta);
        return at.getWorld().spawn(at, ItemDisplay.class, d -> {
            d.setItemStack(it);
            d.setPersistent(false);
            d.setTeleportDuration(1);
            d.setBrightness(new Display.Brightness(15, 15));
            d.setViewRange(1.2f);
            d.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(p.scale(), p.scale(), p.scale()), new AxisAngle4f()));
        });
    }

    /** Weapon follows the hand while idle. */
    void follow(Session s) {
        if (s.weapon == null) return;
        for (int i = 0; i < s.weaponParts.size(); i++) {
            ItemDisplay d = s.weaponParts.get(i);
            if (d.isValid()) d.teleport(hand(s, s.weapon.parts().get(i)));
        }
        if (s.ticks % 6 == 0) Fx.dust(hand(s, s.weapon.parts().get(0)), Fx.PURPLE, 1, 0.15);
    }

    void dismiss(Session s, boolean announce) {
        boolean had = s.weapon != null || !s.weaponParts.isEmpty();
        clearParts(s);
        s.weapon = null;
        s.sel = 0;
        if (had && announce) s.m.voice.say(s, "dismiss");
    }

    void clearParts(Session s) {
        for (ItemDisplay d : s.weaponParts) if (d.isValid()) { Fx.spark(d.getLocation(), 6, 0.2); Fx.dust(d.getLocation(), Fx.PURPLE, 8, 0.3); d.remove(); }
        s.weaponParts = new ArrayList<>();
    }

    // ---- GUI ----
    static final class Gui implements InventoryHolder {
        final int page; final String category; Inventory inv; final List<String> ids = new ArrayList<>(); final List<String> cats = new ArrayList<>();
        Gui(int page, String category) { this.page = page; this.category = category; }
        @Override public Inventory getInventory() { return inv; }
    }

    void openGui(Player p, int page, String category) {
        Gui g = new Gui(page, category);
        Inventory inv = org.bukkit.Bukkit.createInventory(g, 54, Component.text("ORISON — Matter Forge", NamedTextColor.DARK_PURPLE));
        g.inv = inv;
        List<String> cats = g.cats;
        for (Blueprint b : catalogue.values()) if (!cats.contains(b.category())) cats.add(b.category());
        inv.setItem(0, button(Material.NETHER_STAR, "All", category == null));
        for (int i = 0; i < cats.size() && i < 8; i++) inv.setItem(i + 1, button(Material.AMETHYST_SHARD, cats.get(i), cats.get(i).equals(category)));
        List<Blueprint> list = new ArrayList<>();
        for (Blueprint b : catalogue.values()) if (category == null || b.category().equals(category)) list.add(b);
        for (Blueprint b : list) g.ids.add(b.id());
        for (int i = 0; i < 36; i++) {
            int idx = page * 36 + i;
            if (idx >= list.size()) break;
            Blueprint b = list.get(idx);
            ItemStack it = new ItemStack(b.icon());
            ItemMeta meta = it.getItemMeta();
            meta.setCustomModelData(b.iconModel());
            meta.addItemFlags(ItemFlag.values());
            meta.displayName(Component.text(b.name(), NamedTextColor.LIGHT_PURPLE).decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(Component.text("Free. No materials, no energy.", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false),
                    Component.text("Left-click: forge   Right-click: favourite", NamedTextColor.DARK_GRAY).decoration(TextDecoration.ITALIC, false)));
            it.setItemMeta(meta);
            inv.setItem(9 + i, it);
        }
        inv.setItem(45, button(Material.ARROW, "Previous", false));
        inv.setItem(49, button(Material.BARRIER, "Dismiss weapon", false));
        inv.setItem(53, button(Material.ARROW, "Next", false));
        p.openInventory(inv);
    }

    private ItemStack button(Material m, String name, boolean on) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Component.text(name, on ? NamedTextColor.WHITE : NamedTextColor.LIGHT_PURPLE).decoration(TextDecoration.ITALIC, false));
        it.setItemMeta(meta);
        return it;
    }
}
