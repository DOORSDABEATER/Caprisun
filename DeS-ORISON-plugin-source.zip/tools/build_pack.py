#!/usr/bin/env python3
"""Generates the ORISON resource pack (models, textures, items, HUD font, sounds) straight from the plugin source,
so every custom_model_data id the code uses is guaranteed to have a model. Re-run after adding weapons/pieces."""
import json, os, re, struct, zlib, random, shutil, glob, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'src/main/java/com/des/legendary/orison')
OUT = os.path.join(ROOT, 'resourcepack')
shutil.rmtree(OUT, ignore_errors=True)
def W(path, data, binary=False):
    p = os.path.join(OUT, path); os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'wb' if binary else 'w').write(data if binary else (json.dumps(data, indent=1) if not isinstance(data, str) else data))

# ---------------- PNG writer (no dependencies) ----------------
def png(w, h, px):  # px: list of rows of (r,g,b,a)
    raw = b''.join(b'\x00' + b''.join(bytes(p) for p in row) for row in px)
    def ch(t, d): c = struct.pack('>I', len(d)) + t + d; return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)) + ch(b'IDAT', zlib.compress(raw, 9)) + ch(b'IEND', b'')

random.seed(7)
def tex_black():
    rows = []
    for y in range(16):
        r = []
        for x in range(16):
            n = random.randint(-4, 4)
            c = (22 + n, 16 + n, 34 + n, 255)
            if x in (0, 15) or y in (0, 15): c = (120, 45, 215, 255)       # purple seam
            elif x in (7, 8) and y % 5 == 0: c = (60, 30, 110, 255)
            r.append(c)
        rows.append(r)
    return png(16, 16, rows)
def tex_purple():
    rows = []
    for y in range(16):
        r = []
        for x in range(16):
            t = (x + y) / 30
            c = (int(105 + 85 * t), int(35 + 85 * t), int(215 + 40 * t), 255)
            if random.random() < 0.06: c = (255, 255, 255, 255)
            if x in (0, 15) or y in (0, 15): c = (70, 20, 150, 255)
            r.append(c)
        rows.append(r)
    return png(16, 16, rows)
def tex_white():
    rows = []
    for y in range(16):
        r = []
        for x in range(16):
            n = random.randint(-6, 0)
            c = (245 + n, 240 + n, 255, 255)
            if x in (0, 15) or y in (0, 15): c = (200, 170, 255, 255)
            r.append(c)
        rows.append(r)
    return png(16, 16, rows)
for n, f in (('black', tex_black), ('purple', tex_purple), ('white', tex_white)):
    W(f'assets/des/textures/item/orison/{n}.png', f(), True)
TEX = {'b': '#0', 'p': '#1', 'w': '#2'}

# ---------------- geometry DSL ----------------
def E(w, h, d, dx, dy, dz, t):
    f = [8 + dx - w / 2, 8 + dy - h / 2, 8 + dz - d / 2]; to = [f[0] + w, f[1] + h, f[2] + d]
    face = {'uv': [0, 0, 16, 16], 'texture': TEX[t]}
    return {'from': [round(v, 3) for v in f], 'to': [round(v, 3) for v in to], 'faces': {k: dict(face) for k in ('north', 'east', 'south', 'west', 'up', 'down')}}
def ringXZ(r, th, dy, t, hh=1): return [E(2*r, hh, th, 0, dy, -(r-th/2), t), E(2*r, hh, th, 0, dy, r-th/2, t), E(th, hh, 2*r-2*th, -(r-th/2), dy, 0, t), E(th, hh, 2*r-2*th, r-th/2, dy, 0, t)]
def ringXY(r, th, dz, t, dd=1): return [E(2*r, th, dd, 0, -(r-th/2), dz, t), E(2*r, th, dd, 0, r-th/2, dz, t), E(th, 2*r-2*th, dd, -(r-th/2), 0, dz, t), E(th, 2*r-2*th, dd, r-th/2, 0, dz, t)]
def ringYZ(r, th, dx, t, dw=1): return [E(dw, th, 2*r, dx, -(r-th/2), 0, t), E(dw, th, 2*r, dx, r-th/2, 0, t), E(dw, 2*r-2*th, th, dx, 0, -(r-th/2), t), E(dw, 2*r-2*th, th, dx, 0, r-th/2, t)]
def blade(h, w, t=1.0, y0=0, core='p', edge='w'):
    out = []; n = 5
    for i in range(n):
        ww = max(0.6, w * (1 - i * 0.17)); seg = h / n
        out += [E(ww, seg, t, 0, y0 - h / 2 + seg * (i + .5), 0, edge), E(ww * .45, seg, t + .4, 0, y0 - h / 2 + seg * (i + .5), 0, core)]
    return out
def shaft(h=15, t=1.6, y0=0): return [E(t, h, t, 0, y0, 0, 'b'), E(t + .15, 1, t + .15, 0, y0 + h / 2 - 2, 0, 'p'), E(t + .15, 1, t + .15, 0, y0 - h / 2 + 2, 0, 'p')]
def guard(w=6, y0=0): return [E(w, 1.2, 1.8, 0, y0, 0, 'b'), E(w - 1, .6, 2.1, 0, y0, 0, 'p')]
def pommel(y0=0, s=2.6): return [E(s, s, s, 0, y0, 0, 'b'), E(s - 1, s - 1, s - 1, 0, y0, 0, 'p')]

S = {}
# core + fragments
S[7100] = [E(5, 5, 5, 0, 0, 0, 'p'), E(3, 3, 3, 0, 0, 0, 'w'), E(9, 1.5, 9, 0, -5, 0, 'b'), E(9, 1.5, 9, 0, 5, 0, 'b')] + ringXZ(6.5, 1, 0, 'b') + ringXY(7, 1, 0, 'p') + ringYZ(7.5, 1, 0, 'w') + \
    [E(1.5, 1.5, 1.5, x, y, z, 'w') for x, y, z in ((7, 0, 0), (-7, 0, 0), (0, 0, 7), (0, 0, -7), (0, 7, 0), (0, -7, 0))]
FR = [
 [E(7, 7, 1.5, 0, 0, 0, 'b'), E(5, 5, 2, 0, 0, 0, 'p'), E(2, 2, 2.6, 0, 0, 0, 'w')],
 [E(2, 2, 8, 0, 0, 0, 'b'), E(6, 1, 4, 0, 0, -2, 'p'), E(1, 3, 3, 0, 1.5, -3, 'w')],
 [E(1.5, 1.5, 12, 0, 0, 0, 'w'), E(2.5, 2.5, 5, 0, 0, -2, 'b'), E(1, 1, 3, 0, 0, 6, 'p')],
 [E(5, 5, 5, 0, 0, 0, 'b'), E(3, 3, 1, 0, 0, 2.6, 'w'), E(1.5, 1.5, 1, 0, 0, 3.3, 'p')],
 [E(8, 2, 2, 0, 0, 0, 'p'), E(2, 8, 2, 0, 0, 0, 'p'), E(2, 2, 8, 0, 0, 0, 'p'), E(3, 3, 3, 0, 0, 0, 'w')],
 [E(4, 4, 4, 0, 0, 0, 'b'), E(7, 1.5, 1.5, 0, 0, 0, 'w'), E(1.5, 7, 1.5, 0, 0, 0, 'w'), E(2, 2, 2, 0, 0, 0, 'p')]]
for i in range(6):
    S[7201 + i] = FR[i]
    S[7211 + i] = FR[i] + ringXZ(5, .8, 0, 'w', .8) + ringXY(5.5, .8, 0, 'p', .8) + [E(1, 1, 1, 0, 6, 0, 'w'), E(1, 1, 1, 0, -6, 0, 'w')]
# props
S[7350] = blade(14, 3.2) + guard(6, -7.5) + shaft(4, 1.4, -10)
S[7351] = blade(15, 5) + guard(9, -8) + shaft(2, 2, -9.5)
# weapon parts (cmd -> elements), keyed by cmd
def scythe_blade():
    out = []
    for z in (-6, -3, 0, 3, 6):
        a = abs(z); out += [E(1.2, 3 - a / 4, 3.2, 0, 3.5 - (a / 6) ** 2 * 3.5, z, 'w'), E(1.6, 1.4, 3.2, 0, 5.2 - (a / 6) ** 2 * 3.5, z, 'b')]
    return out
S[7301] = scythe_blade(); S[7302] = shaft(15); S[7303] = pommel()
S[7321] = [E(9, 5, 5, 0, 0, 0, 'b'), E(1.6, 6, 6, 4.6, 0, 0, 'p'), E(1.6, 6, 6, -4.6, 0, 0, 'p'), E(5, 1, 5.4, 0, 2.8, 0, 'w')]; S[7322] = shaft(16, 1.8)
S[7331] = blade(9, 3.2, .9) + [E(1.2, 2, 1.2, 0, -5, 0, 'b')]; S[7332] = shaft(16, 1.4); S[7333] = pommel(0, 2.2)
S[7341] = [E(1.4, 2.5, 1.6, 0, 6.2 - abs(y) * .45, 0, 'b') if False else E(1.4, 2.2, 1.6, (abs(y) / 7) ** 2 * 2.5, y, 0, 'b') for y in (-6, -3, 0, 3, 6)] + [E(1, 1, 1, 3, 6.5, 0, 'p'), E(1, 1, 1, 3, -6.5, 0, 'p')]; S[7342] = [E(.4, 14, .4, 0, 0, 0, 'w')]
S[7361] = blade(14, 3.2); S[7362] = guard(6, 2) + shaft(5, 1.5, -1) + pommel(-4.5, 2.2)
S[7371] = blade(15, 2.2, .8); S[7372] = [E(2.6, .8, 3, 0, 4, 0, 'b'), E(1.6, 7, 1.6, 0, -.5, 0, 'b'), E(1.8, 1, 1.8, 0, 1.5, 0, 'p'), E(1.8, 1, 1.8, 0, -2, 0, 'p'), E(2, 1.6, 2, 0, -4.5, 0, 'p')]
S[7381] = [E(1.6, 7, 3.5, 0, 3, 3, 'b'), E(1.2, 8.5, 1.2, 0, 3, 5.2, 'w'), E(1.4, 2, 2, 0, 0, 1.2, 'p')]; S[7382] = shaft(15, 1.7)
S[7391] = blade(7, 2.4) + guard(4.5, -3.8) + shaft(3, 1.4, -5.8) + pommel(-7.5, 1.8)
S[7711] = [E(2.2, 2.4, 13, 0, 0, 0, 'b'), E(1.2, 1.2, 5, 0, 1.6, -2, 'p'), E(1.6, 3, 2.5, 0, -2.6, -4, 'b')]; S[7712] = [E(14, 1.4, 1.6, 0, 0, 5, 'b'), E(1, 1, 1.8, -7, 0, 5, 'p'), E(1, 1, 1.8, 7, 0, 5, 'p'), E(12, .4, .4, 0, 0, 3.4, 'w')]
S[7721] = [E(12, 14, 1.6, 0, 0, 0, 'b'), E(10, 12, .8, 0, 0, .9, 'p'), E(3, 3, 1.4, 0, 0, 1.4, 'w')]; S[7722] = [E(2, 12, 2, 0, 0, 0, 'b'), E(2.4, 2.4, 2.4, 0, 0, 0, 'p')]
S[7731] = [E(1.4, 1.4, 9, -1.8, 0, 3, 'w'), E(1.4, 1.4, 9.5, 0, 0, 3.2, 'w'), E(1.4, 1.4, 9, 1.8, 0, 3, 'w'), E(6, 3, 3, 0, 0, -2, 'b'), E(4, 1, 3.2, 0, 1.8, -2, 'p')]; S[7732] = S[7731]
S[7741] = [E(3.4, 3.4, 3.4, 0, 3, 0, 'p'), E(1.8, 1.8, 1.8, 0, 3, 0, 'w'), E(1, 5, 1, 2.6, 3, 0, 'b'), E(1, 5, 1, -2.6, 3, 0, 'b'), E(1, 1, 5, 0, 3, 2.6, 'b'), E(1, 1, 5, 0, 3, -2.6, 'b')]; S[7742] = shaft(14, 1.4); S[7743] = pommel(0, 2.2)
S[7751] = [E(1.6, 2.4, 2, 0, 0, z, 'b') if False else E(2, 2.4, 1.8, 0, (abs(z) / 6) ** 2 * -3, z, 'b') for z in (-6, -3, 0, 3, 6)] + [E(1, 1, 2, 0, -3.6, 6.6, 'w'), E(1, 1, 2, 0, -3.6, -6.6, 'w'), E(2.4, 1, 3, 0, 1.4, 0, 'p')]; S[7752] = shaft(15, 1.7)
S[7761] = [E(4 - i * .7, 2.4, 4 - i * .7, 0, 5 - i * 2.4, 0, 'w' if i % 2 else 'p') for i in range(5)]; S[7762] = [E(5, 6, 5, 0, 0, 0, 'b'), E(5.4, 1, 5.4, 0, 2, 0, 'p'), E(5.4, 1, 5.4, 0, -2, 0, 'p'), E(2, 2, 2, 3.2, 0, 0, 'w')]; S[7763] = shaft(8, 1.8)
# armour pieces (names from Armour.java)
def armour(name, mx):
    k = 1.3 if mx else 1.0
    def has(*w): return any(x in name for x in w)
    if has('ring_generation'): return ringXZ(7, 1.5, 0, 'b', 2) + [E(1.4, 2.4, 1.4, x, 0, z, 'p') for x, z in ((7, 0), (-7, 0), (0, 7), (0, -7))] + ringXZ(5.5, .6, 0, 'w', 1)
    if has('ring_harmonics'): return ringXY(7, 1.5, 0, 'p', 2) + [E(1.4, 1.4, 2.4, x, y, 0, 'w') for x, y in ((7, 0), (-7, 0), (0, 7), (0, -7))] + ringXY(5.5, .6, 0, 'b', 1)
    if has('ring_discord'): return ringYZ(7, 1.5, 0, 'w', 2) + [E(2.4, 1.4, 1.4, 0, y, z, 'p') for y, z in ((7, 0), (-7, 0), (0, 7), (0, -7))] + ringYZ(5.5, .6, 0, 'p', 1)
    if has('boot'): return [E(4 * k, 3 * k, 6.5 * k, 0, 0, 1, 'b'), E(3 * k, 1, 2, 0, -.6, -2.6, 'p'), E(2, 2, 1, 0, 0, -3.2, 'w')] + ([E(1, 1, 2, 1.4, 1.6, -2, 'w'), E(1, 1, 2, -1.4, 1.6, -2, 'w')] if mx else [])
    if has('leg'): return [E(4.2 * k, 10 * k, 4.2 * k, 0, 0, 0, 'b'), E(4.5 * k, 1, 4.5 * k, 0, 1, 0, 'p'), E(1, 8, 1, 0, 0, 2.3 * k, 'w')] + ([E(5.4, 2, 5.4, 0, 3, 0, 'b')] if mx else [])
    if has('chest'): return [E(10 * k, 9 * k, 5 * k, 0, 0, 0, 'b'), E(4, 4, 1.2, 0, 0, 2.8 * k, 'p'), E(2, 2, 1.4, 0, 0, 3.0 * k, 'w'), E(9 * k, .6, 5.2 * k, 0, 3, 0, 'w'), E(1, 8 * k, 5.2 * k, 3.5, 0, 0, 'p'), E(1, 8 * k, 5.2 * k, -3.5, 0, 0, 'p')]
    if has('reactor'): return [E(5 * k, 5 * k, 2, 0, 0, 0, 'w'), E(3, 3, 2.6, 0, 0, 0, 'p')] + ringXY(4.4 * k, .8, 0, 'b', 1.6) + ([E(1.2, 8, 1.2, 0, 0, 0, 'w')] if mx else [])
    if has('back_plate', 'back_arch'): return [E(8 * k, 9 * k, 2.6, 0, 0, 0, 'b'), E(2, 3, 3, -2.2, -4.2, -1.2, 'p'), E(2, 3, 3, 2.2, -4.2, -1.2, 'p'), E(1, 7, 2.8, 0, 0, .4, 'w')]
    if has('array_l'): return [E(1.5, 12, 7, 0, 0, -2, 'b'), E(1, 12, 1, 0, 0, -6, 'p'), E(1.2, 6, 4, -.8, 3, -1, 'w'), E(1.2, 3, 8, -.4, -4, -3, 'p')]
    if has('array_r'): return [E(1.5, 12, 7, 0, 0, -2, 'b'), E(1, 12, 1, 0, 0, -6, 'p'), E(1.2, 6, 4, .8, 3, -1, 'w'), E(1.2, 3, 8, .4, -4, -3, 'p')]
    if has('array_c'): return [E(6, 12, 2, 0, 0, 0, 'b'), E(2, 14, 2.4, 0, 1, 0, 'p'), E(8, 1, 3, 0, 5, 0, 'w'), E(1, 1, 8, 0, 6, -3, 'p')]
    if has('spine'): return [E(2, 6, 2.4, 0, 0, 0, 'b'), E(1, 7, 1, 0, 0, -1.4, 'p'), E(3, 1, 3, 0, 3, 0, 'w')]
    if has('shoulder_weapon'): return [E(6, 4, 7, 0, 0, 0, 'b'), E(2, 2, 8, 0, 1.4, 4.5, 'w'), E(2, 2, 8, 0, -1.4, 4.5, 'w'), E(4, 1, 5, 0, 2.5, 0, 'p'), E(1.4, 1.4, 1, 0, 0, 8.6, 'p')]
    if has('shoulder_shooter'): return [E(5, 3, 6, 0, 0, 0, 'b'), E(5.2, .8, 6.2, 0, 1.8, 0, 'p'), E(1.6, 1.6, 5, 0, 0, 3.5, 'w'), E(1, 1, 1, 0, 0, 6.2, 'p')]
    if has('shoulder'): return [E(5.5, 3.4, 6.5, 0, 0, 0, 'b'), E(5.7, .8, 6.7, 0, 2, 0, 'p'), E(1, 3, 5, 3, 0, 0, 'w')]
    if has('gauntlet'): return [E(4.5 * k, 5.5 * k, 4.5 * k, 0, 0, 0, 'b'), E(3, 3, 1.2, 0, 0, 2.8 * k, 'p'), E(1.6, 1.6, 1.4, 0, 0, 3.1 * k, 'w'), E(4.8 * k, .8, 4.8 * k, 0, 2.2, 0, 'p')]
    if has('visor'): return [E(8, 5, 7, 0, 0, 0, 'b'), E(7, 1.8, 1, 0, .6, 3.8, 'w'), E(2, 1.6, 1.2, -1.8, .6, 4.2, 'p'), E(2, 1.6, 1.2, 1.8, .6, 4.2, 'p')]
    if has('helmet'): return [E(8 * k, 8 * k, 8 * k, 0, 0, 0, 'b'), E(8.4 * k, 1, 8.4 * k, 0, 3.6 * k, 0, 'p'), E(1, 6 * k, 6 * k, 0, .6, 0, 'w')] + ([E(1.2, 5, 1.2, 0, 7, -2, 'w'), E(1.2, 3, 1.2, 2.6, 5.5, -2, 'p'), E(1.2, 3, 1.2, -2.6, 5.5, -2, 'p')] if mx else [])
    if has('faceplate'): return [E(6.6 * k, 6 * k, 1, 0, 0, 0, 'w'), E(5.6 * k, 1.2, 1.2, 0, .8, .6, 'p'), E(5.6 * k, 1.2, 1.2, 0, -1.2, .6, 'b')]
    return [E(4, 4, 4, 0, 0, 0, 'b')]

# ---------------- read plugin source: which cmd ids exist, on which base item ----------------
src = {os.path.basename(f): open(f).read() for f in glob.glob(SRC + '/*.java')}
allsrc = '\n'.join(src.values())
MAT = {}                           # cmd -> material
icons = []                         # (icon cmd, [(part cmd, x,y,z)])
for chunk in re.split(r'(?=Blueprint\(")', allsrc)[1:]:
    m = re.match(r'Blueprint\("(\w+)",\s*"[^"]*",\s*"[^"]*",\s*Material\.(\w+),\s*(\d+)', chunk)
    if not m: continue
    cut = chunk.split('List.of(\n')[0] if False else chunk[:3000]
    nxt = re.search(r'Blueprint\("', cut[10:]); cut = cut[:nxt.start() + 10] if nxt else cut
    parts = [(int(a), float(b), float(c), float(d)) for a, b, c, d in re.findall(r'Forge\.Part\((\d+),\s*new Vector\(([-\d.]+),\s*([-\d.]+),\s*([-\d.]+)\)', cut)]
    parts += [(int(a), float(b), float(c), float(d)) for a, b, c, d in re.findall(r'\bpart\((\d+),\s*([-\d.]+),\s*([-\d.]+),\s*([-\d.]+),', cut)]
    ic = int(m.group(3)); MAT[ic] = m.group(2).lower(); icons.append((ic, parts))
    for p in parts: MAT[p[0]] = 'netherite_sword'
for n, c in re.findall(r'new Piece\("(\w+)", (\d+)', allsrc):
    MAT[int(c)] = 'netherite_ingot'
for c in list(range(7201, 7207)) + list(range(7211, 7217)): MAT[c] = 'amethyst_shard'
MAT[7100] = 'leather_chestplate'; MAT[7350] = MAT[7351] = 'netherite_sword'
names = {int(c): n for n, c in re.findall(r'new Piece\("(\w+)", (\d+)', allsrc)}
for c, n in names.items(): S[c] = armour(n, c >= 7600)
for ic, parts in icons:                           # weapon icon = all parts assembled
    els = []
    for pc, x, y, z in parts:
        for e in S[pc]:
            e2 = json.loads(json.dumps(e))
            for i, off in enumerate((x * 8, y * 8 - 8, z * 8)):
                e2['from'][i] = round(e2['from'][i] + off, 3); e2['to'][i] = round(e2['to'][i] + off, 3)
            els.append(e2)
    S[ic] = els
missing = sorted(set(MAT) - set(S))
assert not missing, f'no shape defined for cmd ids {missing}'

# ---------------- write models + item definitions ----------------
GUI = {'rotation': [30, 45, 0], 'translation': [0, 0, 0], 'scale': [.55, .55, .55]}
for cmd, els in S.items():
    W(f'assets/des/models/item/orison/m{cmd}.json', {
        'textures': {'0': 'des:item/orison/black', '1': 'des:item/orison/purple', '2': 'des:item/orison/white', 'particle': 'des:item/orison/black'},
        'elements': els,
        'display': {'gui': GUI, 'fixed': {'scale': [.5, .5, .5]}, 'thirdperson_righthand': {'scale': [.5, .5, .5]}, 'firstperson_righthand': {'scale': [.5, .5, .5]}, 'ground': {'scale': [.4, .4, .4]}}})
bymat = {}
for cmd, mat in MAT.items(): bymat.setdefault(mat, []).append(cmd)
for mat, cmds in bymat.items():
    fb = {'type': 'minecraft:model', 'model': f'minecraft:item/{mat}'}
    if mat == 'leather_chestplate': fb['tints'] = [{'type': 'minecraft:dye', 'default': -6265536}]
    W(f'assets/minecraft/items/{mat}.json', {'model': {'type': 'minecraft:range_dispatch', 'property': 'minecraft:custom_model_data', 'index': 0,
        'entries': [{'threshold': c, 'model': {'type': 'minecraft:model', 'model': f'des:item/orison/m{c}'}} for c in sorted(cmds)], 'fallback': fb}})

# ---------------- HUD font ----------------
G = {  # 8x8 glyphs, '#' = pixel
 0xE000: ['........', '..####..', '.######.', '.######.', '.######.', '.######.', '..####..', '........'],
 0xE001: ['........', '..####..', '.#....#.', '.#....#.', '.#....#.', '.#....#.', '..####..', '........'],
 0xE002: ['...#....', '..##....', '..###...', '.####.#.', '.#####..', '.######.', '..####..', '...##...'],
 0xE003: ['#......#', '##....##', '###..###', '########', '.######.', '..####..', '...##...', '........'],
 0xE004: ['....##..', '...##...', '..##....', '.######.', '....##..', '...##...', '..##....', '.#......']}
rows = [[(255, 255, 255, 255) if G[0xE000 + g][y][x] == '#' else (0, 0, 0, 0) for g in range(5) for x in range(8)] for y in range(8)]
W('assets/des/textures/font/orison_hud.png', png(40, 8, rows), True)
W('assets/des/font/orison_hud.json', {'providers': [{'type': 'bitmap', 'file': 'des:font/orison_hud.png', 'ascent': 7, 'height': 8, 'chars': ['\ue000\ue001\ue002\ue003\ue004']}]})

# ---------------- sounds: voice events fall back to vanilla events until real .ogg voice lines exist ----------------
VOICE = {'online': 'block.beacon.activate', 'forge': 'block.anvil.use', 'dismiss': 'block.beacon.deactivate', 'lowenergy': 'block.note_block.bass',
         'overload': 'block.respawn_anchor.charge', 'ultimate': 'entity.warden.sonic_charge', 'intercept': 'block.amethyst_block.break', 'hostile': 'block.sculk_sensor.clicking',
         'half': 'block.conduit.activate', 'retract': 'block.beacon.deactivate', 'full': 'block.beacon.power_select', 'max': 'entity.wither.spawn', 'overdrive': 'entity.warden.sonic_boom', 'secret': 'block.end_portal.spawn'}
W('assets/des/sounds.json', {f'orison.voice.{k}': {'subtitle': f'orison.voice.{k}', 'sounds': [{'name': v, 'type': 'event', 'pitch': 0.6}]} for k, v in VOICE.items()})
W('assets/des/lang/en_us.json', {f'orison.voice.{k}': f'ORISON: {k}' for k in VOICE})
W('pack.mcmeta', {'pack': {'pack_format': 46, 'supported_formats': [46, 99], 'description': '§5Dragon Empire SMP §7— §dORISON'}})
print(f'models: {len(S)}  item definitions: {len(bymat)}  materials: {sorted(bymat)}')
